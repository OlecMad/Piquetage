/* Tests de la logique de session (www/session.js) — exécution : node tools/test-session.js */
const Sess = require('../www/session.js');

let fails = 0, n = 0;
function ok(c, label, detail) { n++; console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : '')); if (!c) fails++; }
const near = (a, b, t) => a !== null && b !== null && Math.abs(a - b) <= t;

const sp = (x, y, hs, ha) => ({ x93: x, y93: y, hNgfGround: hs === undefined ? null : hs, hNgfAntenna: ha === undefined ? null : ha, lat: 47, lon: 1, hEll: 100, t: 'T' });

console.log('\n── Tracé : intervalle et altitude ──');
{
  const s = Sess.create();
  ok(s.addEpoch(sp(0, 0, 50, 52)) === 'inactive', 'aucun sommet sans tracé démarré');
  ok(s.startTrack() && !s.startTrack(), 'un seul tracé actif à la fois');
  ok(s.addEpoch(sp(0, 0, 50, 52)) === 'added', 'premier sommet toujours enregistré');
  ok(s.addEpoch(sp(0.4, 0, 50, 52)) === 'skipped', '0,4 m < intervalle de 1 m : ignoré');
  ok(s.addEpoch(sp(1.0, 0, 50.2, 52.2)) === 'added', '1,0 m = intervalle : enregistré');
  s.setMeta({ interval: 2 });
  ok(s.addEpoch(sp(2.5, 0, 50.4, 52.4)) === 'skipped' && s.addEpoch(sp(3.0, 0, 50.4, 52.4)) === 'added', 'intervalle porté à 2 m');
  s.setMeta({ interval: 3 });
  ok(s.data.interval === 2, 'intervalle hors liste refusé');
  const v = s.data.tracks[0].v;
  ok(v[0].h === 50 && v[0].k === 'S', 'altitude sol utilisée quand elle existe');
  ok(s.addEpoch(sp(10, 0, null, 60)) === 'added' && s.data.tracks[0].v[3].h === 60 && s.data.tracks[0].v[3].k === 'A', 'sinon altitude antenne, marquée « A »');
  ok(s.addEpoch(sp(20, 0, null, null)) === 'added' && s.data.tracks[0].v[4].h === null && s.data.tracks[0].v[4].k === null, 'sans altitude : null, jamais estimée');
  ok(s.addEpoch({ x93: NaN, y93: 1 }) === 'invalid', 'position invalide refusée');
  const st = s.stats();
  ok(near(st.length, 20, 1e-9) && st.vertices === 5 && st.tracking, 'longueur sur le plan et nombre de sommets', st.length.toFixed(3) + ' m');
}

console.log('\n── Profil et dénivelé ──');
{
  const s = Sess.create(); s.startTrack();
  [[0, 100, 'S'], [10, 101, 'S'], [20, 100.5, 'S'], [30, 103, 'A'], [40, 104, 'A']].forEach(([x, h, k]) =>
    s.addEpoch(k === 'S' ? sp(x, 0, h, h + 2) : sp(x, 0, null, h)));
  const pr = s.profile();
  ok(pr.length === 5 && near(pr[4].d, 40, 1e-9) && pr[2].h === 100.5, 'profil : distance cumulée et altitude par sommet');
  const st = s.stats();
  ok(near(st.up, 1 + 1, 1e-9) && near(st.down, 0.5, 1e-9), 'dénivelé cumulé calculé dans chaque nature d’altitude', 'D+ ' + st.up + ' / D− ' + st.down);
  ok(!(st.up > 4), 'aucun dénivelé entre altitude sol et altitude antenne (natures différentes)');
}

console.log('\n── Points levés ──');
{
  const s = Sess.create();
  const p1 = s.addPoint({ x93: 5, y93: 6, hNgfGround: 40, hNgfAntenna: 42, qualityLabel: 'RTK FIX', acc: 0.012, epochs: 5, t: 'T1', lat: 47, lon: 1, hEll: 99 });
  const p2 = s.addPoint({ x93: 7, y93: 8, hNgfGround: null, hNgfAntenna: 43 });
  ok(p1.n === 1 && p2.n === 2 && p1.h === 40 && p2.h === 43 && p2.k === 'A', 'numérotation P1, P2 et altitude retenue');
  ok(p1.q === 'RTK FIX' && p1.acc === 0.012 && p1.epochs === 5 && p1.hEll === 99, 'qualité, précision, époques et hauteur ellipsoïdale conservées');
  ok(s.addPoint({ x93: 'a', y93: 1 }) === null && s.data.points.length === 2, 'point invalide refusé');
}

console.log('\n── Emprise, arrêt, effacement ──');
{
  const s = Sess.create();
  ok(s.bounds() === null, 'emprise vide sans donnée');
  s.startTrack(); s.addEpoch(sp(10, 20, 1, 2)); s.addEpoch(sp(15, 25, 1, 2));
  s.addPoint({ x93: 30, y93: 5 });
  const b = s.bounds([{ x: -4, y: 40 }, null]);
  ok(b.minX === -4 && b.maxX === 30 && b.minY === 5 && b.maxY === 40, 'emprise = tracés + points + position en direct');
  s.stopTrack();
  ok(!s.isTracking() && s.data.tracks.length === 1, 'arrêt du tracé');
  s.startTrack(); s.stopTrack();
  ok(s.data.tracks.length === 1, 'tracé vide ignoré à l’arrêt');
  s.clearTracks();
  ok(s.data.tracks.length === 0 && s.data.points.length === 1, 'effacement des tracés sans toucher aux points');
  s.reset({ project: 'Chantier', place: 'Genillé' });
  ok(s.data.points.length === 0 && s.data.nextPoint === 1 && s.data.project === 'Chantier', 'nouveau projet : tout est remis à zéro');
}

console.log('\n── Sauvegarde et relecture ──');
{
  const s = Sess.create(); s.setMeta({ project: ' Berges ', place: 'Genillé', display: 'les deux', interval: 0.5 });
  s.startTrack(); s.addEpoch(sp(1, 2, 3, 4)); s.addPoint({ x93: 9, y93: 9, hNgfAntenna: 7 });
  const back = Sess.create(Sess.parse(s.serialize()));
  ok(back.data.project === 'Berges' && back.data.display === 'les deux' && back.data.interval === 0.5, 'métadonnées relues');
  ok(back.isTracking() && back.data.tracks[0].v.length === 1 && back.data.points[0].n === 1, 'tracé en cours et points relus');
  ok(Sess.parse('{pas du json') === null && Sess.parse('{"v":99}') === null && Sess.parse('null') === null, 'données corrompues ou d’une autre version refusées');
  ok(Sess.parse(JSON.stringify({ v: 1, tracks: [{ v: [{ x: 'a' }] }], points: [] })) === null, 'sommet non numérique refusé');
  ok(Sess.create(null).data.tracks.length === 0, 'session vide si rien à relire');
  const odd = Sess.parse(JSON.stringify({ v: 1, tracks: [], points: [], interval: 7, display: 'x', active: 5 }));
  ok(odd.interval === 1 && odd.display === 'ligne' && odd.active === -1 && odd.nextPoint === 1, 'valeurs hors liste ramenées aux valeurs sûres');
}

console.log('\n── Cap de marche ──');
{
  const r = (pts) => pts.map(([x, y]) => ({ x, y }));
  ok(near(Sess.heading(r([[0, 0], [0, 4]]), 3), 0, 1e-9), 'vers le nord du plan : 0°');
  ok(near(Sess.heading(r([[0, 0], [4, 0]]), 3), 90, 1e-9), 'vers l’est : 90°');
  ok(near(Sess.heading(r([[0, 0], [0, -4]]), 3), 180, 1e-9), 'vers le sud : 180°');
  ok(near(Sess.heading(r([[0, 0], [-4, 0]]), 3), 270, 1e-9), 'vers l’ouest : 270°');
  ok(near(Sess.heading(r([[0, 0], [3, 3]]), 3), 45, 1e-9), 'nord-est : 45°');
  ok(Sess.heading(r([[0, 0], [0, 1], [0, 2]]), 3) === null, 'moins de 3 m parcourus : pas de cap');
  ok(Sess.heading(r([[0, 0]]), 3) === null && Sess.heading([], 3) === null, 'une seule position : pas de cap');
  ok(near(Sess.heading(r([[0, 0], [0, 10], [0.1, 10.1]]), 3), Math.atan2(0.1, 10.1) * 180 / Math.PI, 1e-9), 'cap pris sur la plus récente position éloignée d’au moins 3 m');
  ok(Sess.cardinal(0) === 'N' && Sess.cardinal(44) === 'NE' && Sess.cardinal(181) === 'S' && Sess.cardinal(359) === 'N' && Sess.cardinal(270) === 'O', 'points cardinaux');
}

console.log('\n── Barre d’échelle ──');
{
  ok(Sess.niceLength(130) === 100 && Sess.niceLength(210) === 200 && Sess.niceLength(7) === 5 && Sess.niceLength(0.9) === 0.5, 'longueurs rondes (1, 2, 5 × 10ⁿ)');
  ok(Sess.niceLength(10) === 10 && Sess.niceLength(0) === 0 && Sess.niceLength(-3) === 0, 'cas limites');
}

console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
process.exit(fails ? 1 : 0);
