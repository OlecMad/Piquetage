# Piquetage — relevé et implantation RTK

Application Android (Capacitor 8) de relevé et d'implantation, reliée à la canne RTK
(ArduSimple Calibrated Surveyor, ZED-F9P, Bluetooth Classic) et au réseau Centipede.
Calculs en **Lambert-93 (EPSG:2154)**, altitudes **NGF-IGN69** par la grille **RAF20**.

Version **0.2.0 — étape 2** : écran principal (disposition C) avec tracé et profil en direct,
points levés numérotés, projet enregistré sur l'appareil. Le code RTK est repris de Diagnostic
Fluvial 1.6 (validé sur le terrain avec la canne) ; il est ici séparé de toute interface.

## Écran principal

Bandeau (projet, lieu, date, heure) · pastille de qualité RTK et précisions · un instrument en
gros chiffres (**Alt.** altitude NGF, **Points** levés, **Cap** de marche) · tracé en direct ·
profil altimétrique · barre **Point / Tracé / Impl. / Canne / Projet**. Sur tablette en paysage,
instruments à gauche, tracé et profil à droite.

| Choix | Détail |
|---|---|
| Repère | RGF93 / Lambert-93 (EPSG:2154), nord **du plan** en haut ; altitudes NGF-IGN69 (grille RAF20) |
| Altitude | « sol » si hauteur de canne et centre de phase sont saisis, sinon « antenne » ; jamais estimée |
| Distances | sur le plan Lambert-93 (distance de grille, pas de terrain) |
| Tracé | un sommet tous les 0,5 / 1 / 2 / 5 m (réglable, 1 m par défaut) ; seulement en RTK FIX si « FIX uniquement » |
| Cap de marche | calculé sur la marche récente (≥ 3 m), par rapport au nord du plan — pas le nord géographique ni une boussole |
| Écran | maintenu allumé pendant l'utilisation (FLAG_KEEP_SCREEN_ON) |
| Session | enregistrée dans le stockage local de l'appareil, relue au lancement |

Pas encore là : export CSV / DXF (étape 3), import `.gpkg` (4), implantation (5), fond IGN (6),
boussole par capteur et météo (7).

## Contenu

| Élément | Rôle | Origine |
|---|---|---|
| `android/…/GnssBridgePlugin.java` | Bluetooth Classic SPP, client NTRIP v1 | repris tel quel (package renommé) |
| `android/…/MainActivity`, `PiqApp`, `CrashReporter`, `CrashActivity` | pont Capacitor, rapport de plantage, écran allumé | repris et adapté |
| `www/geo.js`, `www/raf20.js` | NMEA, Lambert-93, altitude NGF | repris tels quels |
| `www/rtk-core.js` | liaison, NTRIP, époques, levé moyenné — sans interface | extrait de `rtk.js` |
| `www/session.js` | tracés, points, statistiques, cap | nouveau |
| `www/views.js` | dessin du tracé et du profil (canvas) | nouveau |
| `www/diag.js`, `www/app.js`, `www/index.html` | panneau Canne, écran principal | nouveau |
| `tools/make_icons.py` | logo et icônes Android | nouveau |

Permissions : Internet (NTRIP), Bluetooth, stockage pour les exports. Plus de micro, de
caméra ni de localisation : la position vient uniquement de la canne.

## Vérifications

| Commande | Ce qu'elle contrôle |
|---|---|
| `node tools/test-geo.js` | Lambert-93, RAF20, NMEA (32 assertions) |
| `node tools/test-rtk-core.js` | noyau RTK avec faux plugin et horloge simulée (43) |
| `node tools/test-session.js` | tracés, points, profil, cap, relecture (41) |
| `node tools/verify-screen.js` | écran principal dans Chromium : marche simulée, téléphone et tablette (45) |
| `python3 tools/check-android.py .` | cohérence du projet Android avant Gradle |
| `tools/java-test/run.sh` | plugin GnssBridge contre un faux caster NTRIP (17) |

Ces vérifications ne remplacent pas l'essai avec la vraie canne sur chaque appareil.

## Compilation

Voir `PROCEDURE_INSTALLATION.md` : dépôt GitHub, workflow `android.yml`, artefact
`piquetage-debug`.
