/* ==================================================================
   Piquetage — session de relevé (sans interface)

   Une session regroupe : le projet (nom, lieu), des tracés (suites de
   sommets en Lambert-93 + altitude NGF), des points levés numérotés P1, P2…
   Toutes les coordonnées sont en mètres, RGF93 / Lambert-93 (EPSG:2154) ;
   l'altitude est NGF-IGN69 (« sol » si hauteur de canne et centre de phase
   sont saisis, sinon « antenne »). Jamais d'altitude estimée : null si absente.

   Distances et caps sont calculés sur le plan Lambert-93 : le nord est celui
   de la grille (nord du plan), pas le nord géographique.

   Fonctionne dans la WebView (window.Session) et sous Node (tests).
   ================================================================== */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiqSession = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = 1;
  var STORAGE_KEY = 'piquetage.session';
  var INTERVALS = [0.5, 1, 2, 5];
  var DISPLAYS = ['ligne', 'points', 'les deux'];

  function newData(meta) {
    meta = meta || {};
    return {
      v: VERSION,
      project: String(meta.project || ''), place: String(meta.place || ''),
      created: new Date().toISOString(),
      interval: 1, display: 'ligne',
      tracks: [], active: -1,
      points: [], nextPoint: 1
    };
  }

  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function dist(a, b) { var dx = a.x - b.x, dy = a.y - b.y; return Math.sqrt(dx * dx + dy * dy); }

  /** Valide une session relue du stockage ; null si inexploitable. */
  function validate(d) {
    if (!d || typeof d !== 'object' || d.v !== VERSION) return null;
    if (!Array.isArray(d.tracks) || !Array.isArray(d.points)) return null;
    var ok = d.tracks.every(function (t) {
      return t && Array.isArray(t.v) && t.v.every(function (p) { return p && isNum(p.x) && isNum(p.y); });
    }) && d.points.every(function (p) { return p && isNum(p.x) && isNum(p.y) && isNum(p.n); });
    if (!ok) return null;
    if (INTERVALS.indexOf(d.interval) < 0) d.interval = 1;
    if (DISPLAYS.indexOf(d.display) < 0) d.display = 'ligne';
    if (!(d.active >= -1 && d.active < d.tracks.length)) d.active = -1;
    d.project = String(d.project || ''); d.place = String(d.place || '');
    d.nextPoint = isNum(d.nextPoint) && d.nextPoint >= 1 ? d.nextPoint
      : d.points.reduce(function (m, p) { return Math.max(m, p.n); }, 0) + 1;
    return d;
  }

  function parse(text) {
    try { return validate(JSON.parse(text)); } catch (e) { return null; }
  }

  /** Sommet à partir d'un point levé (geo.surveyPoint) : altitude sol si connue, sinon antenne. */
  function toVertex(sp) {
    var ground = isNum(sp.hNgfGround), ant = isNum(sp.hNgfAntenna);
    return {
      x: sp.x93, y: sp.y93,
      h: ground ? sp.hNgfGround : (ant ? sp.hNgfAntenna : null),
      k: ground ? 'S' : (ant ? 'A' : null),          // S = sol, A = antenne
      t: sp.t || null
    };
  }

  function create(data) {
    var D = validate(data) || newData();

    function active() { return D.active >= 0 ? D.tracks[D.active] : null; }
    function last() {
      if (D.active >= 0) return D.tracks[D.active];
      for (var i = D.tracks.length - 1; i >= 0; i--) if (D.tracks[i].v.length) return D.tracks[i];
      return null;
    }

    function startTrack(when) {
      if (D.active >= 0) return false;
      D.tracks.push({ id: D.tracks.length + 1, t0: when || new Date().toISOString(), v: [] });
      D.active = D.tracks.length - 1;
      return true;
    }
    function stopTrack() {
      if (D.active < 0) return false;
      if (!D.tracks[D.active].v.length) D.tracks.splice(D.active, 1);   // tracé vide : ignoré
      D.active = -1;
      return true;
    }

    /** Ajoute un sommet au tracé actif si l'on s'est déplacé d'au moins l'intervalle. */
    function addEpoch(sp) {
      var tr = active();
      if (!tr) return 'inactive';
      if (!sp || !isNum(sp.x93) || !isNum(sp.y93)) return 'invalid';
      var v = toVertex(sp);
      if (tr.v.length && dist(tr.v[tr.v.length - 1], v) < D.interval) return 'skipped';
      tr.v.push(v);
      return 'added';
    }

    function addPoint(sp) {
      if (!sp || !isNum(sp.x93) || !isNum(sp.y93)) return null;
      var v = toVertex(sp);
      var p = {
        n: D.nextPoint++, x: v.x, y: v.y, h: v.h, k: v.k, t: sp.t || null,
        lat: sp.lat, lon: sp.lon, hEll: sp.hEll,
        q: sp.qualityLabel || null, acc: isNum(sp.acc) ? sp.acc : null,
        epochs: sp.epochs || null, sats: sp.sats || null,
        mount: sp.mountpoint || null, receiver: sp.receiver || null
      };
      D.points.push(p);
      return p;
    }

    function length(tr) {
      var s = 0;
      if (!tr) return 0;
      for (var i = 1; i < tr.v.length; i++) s += dist(tr.v[i - 1], tr.v[i]);
      return s;
    }

    /** Profil : [{d, h, k}] — d = distance cumulée sur le plan (m) depuis le premier sommet. */
    function profile(tr) {
      tr = tr || last();
      var out = [], acc = 0;
      if (!tr) return out;
      for (var i = 0; i < tr.v.length; i++) {
        if (i) acc += dist(tr.v[i - 1], tr.v[i]);
        out.push({ d: acc, h: tr.v[i].h, k: tr.v[i].k });
      }
      return out;
    }

    function stats() {
      var tr = last(), vs = tr ? tr.v : [];
      var hs = vs.filter(function (p) { return p.h !== null; });
      var up = 0, down = 0;
      for (var i = 1; i < hs.length; i++) {
        if (hs[i].k !== hs[i - 1].k) continue;           // pas de dénivelé entre altitudes de nature différente
        var dz = hs[i].h - hs[i - 1].h;
        if (dz > 0) up += dz; else down -= dz;
      }
      return {
        tracks: D.tracks.length, vertices: vs.length, length: length(tr),
        points: D.points.length, up: up, down: down,
        tracking: D.active >= 0
      };
    }

    /** Emprise des tracés, des points et des positions supplémentaires. */
    function bounds(extra) {
      var xs = [], ys = [];
      D.tracks.forEach(function (t) { t.v.forEach(function (p) { xs.push(p.x); ys.push(p.y); }); });
      D.points.forEach(function (p) { xs.push(p.x); ys.push(p.y); });
      (extra || []).forEach(function (p) { if (p && isNum(p.x) && isNum(p.y)) { xs.push(p.x); ys.push(p.y); } });
      if (!xs.length) return null;
      return {
        minX: Math.min.apply(null, xs), maxX: Math.max.apply(null, xs),
        minY: Math.min.apply(null, ys), maxY: Math.max.apply(null, ys)
      };
    }

    function setMeta(m) {
      if (m.project !== undefined) D.project = String(m.project).trim();
      if (m.place !== undefined) D.place = String(m.place).trim();
      if (m.interval !== undefined) { var iv = +m.interval; if (INTERVALS.indexOf(iv) >= 0) D.interval = iv; }
      if (m.display !== undefined && DISPLAYS.indexOf(m.display) >= 0) D.display = m.display;
    }

    function clearTracks() { D.tracks = []; D.active = -1; }
    function reset(meta) { var n = newData(meta); Object.keys(D).forEach(function (k) { delete D[k]; }); Object.assign(D, n); }

    return {
      data: D,
      isTracking: function () { return D.active >= 0; },
      startTrack: startTrack, stopTrack: stopTrack,
      addEpoch: addEpoch, addPoint: addPoint,
      activeTrack: active, lastTrack: last,
      length: length, profile: profile, stats: stats, bounds: bounds,
      setMeta: setMeta, clearTracks: clearTracks, reset: reset,
      serialize: function () { return JSON.stringify(D); }
    };
  }

  /**
   * Cap de marche (degrés, 0–360 dans le sens horaire depuis le nord du plan) entre la
   * position la plus récente et la plus récente position située à au moins minDist mètres.
   * recent : [{x, y}] du plus ancien au plus récent. null si l'on n'a pas assez bougé.
   */
  function heading(recent, minDist) {
    if (!recent || recent.length < 2) return null;
    var cur = recent[recent.length - 1];
    for (var i = recent.length - 2; i >= 0; i--) {
      if (dist(recent[i], cur) >= minDist) {
        var dx = cur.x - recent[i].x, dy = cur.y - recent[i].y;
        var a = Math.atan2(dx, dy) * 180 / Math.PI;
        return (a + 360) % 360;
      }
    }
    return null;
  }

  var CARD = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
  function cardinal(deg) { return CARD[Math.round(deg / 45) % 8]; }

  /** Distance « ronde » (1, 2, 5 × 10ⁿ) la plus grande ne dépassant pas maxMeters, pour la barre d'échelle. */
  function niceLength(maxMeters) {
    if (!(maxMeters > 0)) return 0;
    var p = Math.pow(10, Math.floor(Math.log(maxMeters) / Math.LN10));
    var best = p;
    [1, 2, 5, 10].forEach(function (m) { if (m * p <= maxMeters) best = m * p; });
    return best;
  }

  return {
    create: create, parse: parse, heading: heading, cardinal: cardinal, niceLength: niceLength,
    KEY: STORAGE_KEY, INTERVALS: INTERVALS, DISPLAYS: DISPLAYS, VERSION: VERSION, dist: dist
  };
});
