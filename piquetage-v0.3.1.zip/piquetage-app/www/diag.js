/* Piquetage — panneau « Canne » : liaison Bluetooth, corrections NTRIP, hauteurs.
   Crée l'instance RtkCore unique de la page (window.PIQUETAGE.rtk) que l'écran
   principal (app.js) réutilise. Aucun innerHTML : tout passe par textContent. */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var CAP = window.Capacitor || null;
  var P = null;
  if (CAP && CAP.Plugins && CAP.Plugins.GnssBridge &&
      (typeof CAP.isPluginAvailable !== 'function' || CAP.isPluginAvailable('GnssBridge'))) {
    P = CAP.Plugins.GnssBridge;
  }

  var storage = null;
  try { storage = window.localStorage; } catch (e) { /* stockage indisponible */ }

  var rtk = window.RtkCore.create({ geo: window.GEO, plugin: P, storage: storage });
  var S = rtk.settings;

  function fmt(v, d, unit) { return (v === null || v === undefined || !isFinite(v)) ? '—' : v.toFixed(d) + (unit || ''); }

  /* ---------------- Messages ---------------- */

  var logEl = $('log');
  function log(text) {
    var li = document.createElement('li');
    var t = new Date();
    li.textContent = t.toTimeString().slice(0, 8) + '  ' + text;
    logEl.insertBefore(li, logEl.firstChild);
    while (logEl.children.length > 40) logEl.removeChild(logEl.lastChild);
  }
  rtk.on('message', log);

  /* ---------------- Affichage ---------------- */

  var NT = { stopped: 'Arrêté', connecting: 'Connexion…', connected: null, reconnecting: 'Nouvel essai', error: 'Erreur' };

  function paint(st) {
    var fix = $('fix');
    fix.className = 'fix q-' + st.code;
    fix.textContent = st.label;

    $('sats').textContent = st.fresh ? fmt(st.sats, 0) : '—';
    $('hdop').textContent = st.fresh ? fmt(st.hdop, 2) : '—';
    $('age').textContent = st.fresh && st.diffAge !== null ? fmt(st.diffAge, 1, ' s') : '—';
    $('sdh').textContent = st.gstAvailable ? (rtk.cm(st.sdH) || 'n.d.') : (st.fresh ? 'n.d.' : '—');
    $('sdv').textContent = st.gstAvailable ? (rtk.cm(st.sdV) || 'n.d.') : (st.fresh ? 'n.d.' : '—');

    var n = st.ntrip, nts;
    if (!n.enabled) nts = 'Désactivé';
    else if (n.state === 'connected') nts = 'Reçu ' + (n.bytes / 1024).toFixed(0) + ' Ko';
    else nts = NT[n.state] || n.state;
    $('ntrip').textContent = nts;
    $('ntrip').title = n.message || '';

    var c = $('coords');
    c.textContent = '';
    var p = st.point;
    function line(text, muted) {
      var s = document.createElement('span');
      s.textContent = text;
      if (muted) s.className = 'muted';
      c.appendChild(s);
      c.appendChild(document.createElement('br'));
    }
    if (p) {
      line('X ' + fmt(p.x93, 2) + ' m   Y ' + fmt(p.y93, 2) + ' m');
      line(p.hNgfGround !== null ? 'H sol ' + fmt(p.hNgfGround, 3, ' m') : 'H antenne ' + fmt(p.hNgfAntenna, 3, ' m'));
      if (p.hEll === null) line('séparation géoïdale absente de la GGA', true);
    } else {
      line('X —   Y —'); line('H —');
    }

    var hn = $('hnote');
    if (st.heights.complete) {
      hn.className = 'note';
      hn.textContent = 'H sol = h ellipsoïdale − N (RAF20) − ' + (+S.pole).toFixed(3) + ' m (canne) − ' + (+S.apc).toFixed(4) + ' m (centre de phase).';
    } else {
      hn.className = 'warn';
      hn.textContent = 'Altitude au sol non calculée tant que ' + st.heights.missing.join(' et ') +
        (st.heights.missing.length > 1 ? ' ne sont pas saisis' : ' n’est pas saisi') +
        ' : seule l’altitude de l’antenne est affichée. Le décalage du centre de phase est à relever dans le fichier de calibration NGS ANTCAL (saisir 0 en connaissance de cause).';
    }

    $('connect').textContent = (st.connected || st.wantConnected) ? 'Déconnecter' : 'Connecter';
    $('noplugin').hidden = st.available;
    ['refresh', 'dev', 'connect'].forEach(function (id) { $(id).disabled = !st.available; });
  }
  rtk.on('change', paint);

  /* ---------------- Liste des appareils ---------------- */

  function fillDevices(devs) {
    var sel = $('dev');
    sel.textContent = '';
    var o0 = document.createElement('option');
    o0.value = ''; o0.textContent = '— choisir —';
    sel.appendChild(o0);
    devs.forEach(function (d) {
      var o = document.createElement('option');
      o.value = d.address;
      o.textContent = d.name.replace(/[<>&"]/g, '') + ' — ' + d.address + (d.ble ? ' (BLE, non compatible)' : '');
      sel.appendChild(o);
    });
    sel.value = S.address || '';
  }

  $('refresh').addEventListener('click', function () { rtk.refreshDevices().then(fillDevices); });
  $('dev').addEventListener('change', function () { S.address = $('dev').value; });
  $('connect').addEventListener('click', function () {
    var st = rtk.status();
    if (st.connected || st.wantConnected) rtk.disconnect();
    else rtk.connect($('dev').value || S.address).catch(function (e) { log(e.message); });
  });

  /* ---------------- Réglages ---------------- */

  function bind(id, key, read) {
    var el = $(id);
    var fn = function () { rtk.set(key, read(el)); };
    el.addEventListener('input', fn);
    el.addEventListener('change', fn);
  }
  var val = function (el) { return el.value; };
  var chk = function (el) { return el.checked; };

  $('pole').value = S.pole;
  $('apc').value = S.apc;
  $('avg').value = String(S.avg);
  $('fixonly').checked = !!S.requireFix;
  $('nt-enabled').checked = !!S.ntrip.enabled;
  ['host', 'port', 'mount', 'gga', 'user', 'pass'].forEach(function (k) { $('nt-' + k).value = S.ntrip[k]; });

  bind('pole', 'pole', val); bind('apc', 'apc', val); bind('avg', 'avg', val);
  bind('fixonly', 'requireFix', chk); bind('nt-enabled', 'ntrip.enabled', chk);
  ['host', 'port', 'mount', 'gga', 'user', 'pass'].forEach(function (k) { bind('nt-' + k, 'ntrip.' + k, val); });

  /* ---------------- Démarrage ---------------- */

  paint(rtk.status());
  if (P) rtk.refreshDevices().then(fillDevices);
  window.PIQUETAGE = { rtk: rtk };   // inspection et tests
})();
