/* ==================================================================
   Piquetage — export CSV et DXF (sans interface)

   Produit, à partir des données de session (session.data) :
     · <projet>_<date>_points.csv   un point levé par ligne
     · <projet>_<date>_traces.csv   un sommet de tracé par ligne
     · <projet>_<date>.dxf          points, numéros, altitudes et tracés (DXF R12, ASCII)

   Repère : RGF93 / Lambert-93 (EPSG:2154), mètres ; altitude NGF-IGN69 (m).
   Un DXF ne porte ni système de coordonnées ni nature d'altitude : celle-ci
   est donc inscrite dans le nom des calques (SOL, ANTENNE, SANS_Z) et dans un
   cartouche. Une altitude absente n'est jamais remplacée par une valeur
   estimée : colonne vide en CSV ; en DXF, Z vaut 0 (obligatoire dans le format)
   et l'objet est placé dans un calque « SANS_Z » pour le repérer.

   Fonctionne dans la WebView (window.PiqExport) et sous Node (tests).
   ================================================================== */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiqExport = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var NL = '\r\n';
  var BOM = '\uFEFF';
  var TEXT_H_LABEL = 0.5, TEXT_H_ALT = 0.35, MARK_R = 0.15;         // hauteurs de texte DXF (m, unités du dessin)

  function isNum(v) { return typeof v === 'number' && isFinite(v); }

  /** Texte ASCII sans accent (noms de fichier, textes DXF). */
  function ascii(s) {
    return String(s === null || s === undefined ? '' : s)
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/œ/g, 'oe').replace(/Œ/g, 'OE').replace(/æ/g, 'ae').replace(/Æ/g, 'AE')
      .replace(/[^\x20-\x7e]/g, '?');
  }
  function slug(s) {
    var t = ascii(s).replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    return t || 'piquetage';
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function stamp(d) {
    return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes());
  }

  /* ---------------- CSV ---------------- */

  function makeFormatter(decimal) {
    var comma = decimal === 'virgule';
    function n(v, d) {
      if (!isNum(v)) return '';
      var s = v.toFixed(d);
      return comma ? s.replace('.', ',') : s;
    }
    function txt(v) {
      var s = v === null || v === undefined ? '' : String(v);
      // une cellule qui commence par = + - @ serait lue comme une formule par un tableur
      if (/^[=+\-@]/.test(s)) s = "'" + s;
      if (/[";\r\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
      return s;
    }
    return { n: n, txt: txt };
  }

  var KIND = { S: 'sol', A: 'antenne' };

  function csvPoints(D, decimal) {
    var f = makeFormatter(decimal);
    var head = ['projet', 'lieu', 'point', 'date_utc', 'x_l93_m', 'y_l93_m', 'h_ngf_m', 'h_type', 'h_ellipsoidale_m',
      'hauteur_canne_m', 'decalage_apc_m', 'qualite', 'precision_h_m', 'epoques', 'satellites', 'point_montage', 'recepteur',
      'latitude_rgf93', 'longitude_rgf93'];
    var rows = [head.join(';')];
    D.points.forEach(function (p) {
      rows.push([
        f.txt(D.project), f.txt(D.place), 'P' + p.n, f.txt(p.t || ''),
        f.n(p.x, 3), f.n(p.y, 3), f.n(p.h, 3), KIND[p.k] || '', f.n(p.hEll, 3),
        f.n(p.pole, 3), f.n(p.apc, 4), f.txt(p.q || ''), f.n(p.acc, 3),
        isNum(p.epochs) ? String(p.epochs) : '', isNum(p.sats) ? String(p.sats) : '',
        f.txt(p.mount || ''), f.txt(p.receiver || ''), f.n(p.lat, 9), f.n(p.lon, 9)
      ].join(';'));
    });
    return BOM + rows.join(NL) + NL;
  }

  function csvTracks(D, decimal) {
    var f = makeFormatter(decimal);
    var head = ['projet', 'lieu', 'trace', 'sommet', 'date_utc', 'x_l93_m', 'y_l93_m', 'h_ngf_m', 'h_type', 'distance_cumulee_m'];
    var rows = [head.join(';')];
    D.tracks.forEach(function (tr, ti) {
      var acc = 0;
      tr.v.forEach(function (v, i) {
        if (i) { var dx = v.x - tr.v[i - 1].x, dy = v.y - tr.v[i - 1].y; acc += Math.sqrt(dx * dx + dy * dy); }
        rows.push([
          f.txt(D.project), f.txt(D.place), 'T' + (ti + 1), String(i + 1), f.txt(v.t || ''),
          f.n(v.x, 3), f.n(v.y, 3), f.n(v.h, 3), KIND[v.k] || '', f.n(acc, 3)
        ].join(';'));
      });
    });
    return BOM + rows.join(NL) + NL;
  }

  /* ---------------- DXF R12 ---------------- */

  var LAYERS = [
    ['PIQ_PT_SOL', 3], ['PIQ_PT_ANTENNE', 30], ['PIQ_PT_SANS_Z', 8],
    ['PIQ_NUM', 7], ['PIQ_ALT', 5],
    ['PIQ_TRACE_SOL', 3], ['PIQ_TRACE_ANTENNE', 30], ['PIQ_TRACE_2D', 8],
    ['PIQ_INFO', 7]
  ];

  function layerOfPoint(p) { return p.k === 'S' ? 'PIQ_PT_SOL' : (p.k === 'A' ? 'PIQ_PT_ANTENNE' : 'PIQ_PT_SANS_Z'); }

  /** Calque d'un tracé : toutes altitudes « sol » → SOL ; toutes « antenne » → ANTENNE ; sinon 2D (Z non fiable). */
  function trackKind(tr) {
    if (!tr.v.length) return '2D';
    var k = tr.v[0].k;
    if (!k || !isNum(tr.v[0].h)) return '2D';
    var same = tr.v.every(function (v) { return v.k === k && isNum(v.h); });
    return same ? (k === 'S' ? 'SOL' : 'ANTENNE') : '2D';
  }

  function dxf(D, info) {
    var out = [];
    function g(code, value) { out.push(String(code)); out.push(String(value)); }
    function c3(v) { return (isNum(v) ? v : 0).toFixed(3); }

    // emprise
    var xs = [], ys = [], zs = [];
    D.points.forEach(function (p) { xs.push(p.x); ys.push(p.y); zs.push(isNum(p.h) ? p.h : 0); });
    D.tracks.forEach(function (t) { t.v.forEach(function (v) { xs.push(v.x); ys.push(v.y); zs.push(isNum(v.h) ? v.h : 0); }); });
    var minX = Math.min.apply(null, xs), maxX = Math.max.apply(null, xs);
    var minY = Math.min.apply(null, ys), maxY = Math.max.apply(null, ys);
    var minZ = Math.min.apply(null, zs), maxZ = Math.max.apply(null, zs);

    // Repère local (option) : on retranche une origine arrondie au 100 m inférieur ; la valeur est inscrite au cartouche.
    var local = !!(info && info.origin === 'local');
    var ox = local ? Math.floor(minX / 100) * 100 : 0, oy = local ? Math.floor(minY / 100) * 100 : 0;

    g(0, 'SECTION'); g(2, 'HEADER');
    g(9, '$ACADVER'); g(1, 'AC1009');
    g(9, '$INSBASE'); g(10, '0.0'); g(20, '0.0'); g(30, '0.0');
    g(9, '$EXTMIN'); g(10, c3(minX - ox)); g(20, c3(minY - 3 - oy)); g(30, c3(minZ));
    g(9, '$EXTMAX'); g(10, c3(maxX - ox)); g(20, c3(maxY - oy)); g(30, c3(maxZ));
    g(0, 'ENDSEC');

    g(0, 'SECTION'); g(2, 'TABLES');
    g(0, 'TABLE'); g(2, 'LTYPE'); g(70, 1);
    g(0, 'LTYPE'); g(2, 'CONTINUOUS'); g(70, 0); g(3, 'Solid line'); g(72, 65); g(73, 0); g(40, '0.0');
    g(0, 'ENDTAB');
    g(0, 'TABLE'); g(2, 'LAYER'); g(70, LAYERS.length);
    LAYERS.forEach(function (l) { g(0, 'LAYER'); g(2, l[0]); g(70, 0); g(62, l[1]); g(6, 'CONTINUOUS'); });
    g(0, 'ENDTAB');
    g(0, 'TABLE'); g(2, 'STYLE'); g(70, 1);
    g(0, 'STYLE'); g(2, 'STANDARD'); g(70, 0); g(40, '0.0'); g(41, '1.0'); g(50, '0.0'); g(71, 0); g(42, '0.2'); g(3, 'txt'); g(4, '');
    g(0, 'ENDTAB');
    g(0, 'ENDSEC');

    g(0, 'SECTION'); g(2, 'ENTITIES');

    function text(layer, x, y, z, h, s) {
      g(0, 'TEXT'); g(8, layer); g(10, c3(x - ox)); g(20, c3(y - oy)); g(30, c3(z)); g(40, h.toFixed(3)); g(1, ascii(s));
    }

    // cartouche : le DXF ne porte pas de système de coordonnées
    var title = 'PIQUETAGE' + (D.project ? ' - ' + D.project : '') + (D.place ? ' - ' + D.place : '');
    text('PIQ_INFO', minX, minY - 1, 0, TEXT_H_LABEL, title);
    text('PIQ_INFO', minX, minY - 2, 0, TEXT_H_ALT, 'RGF93 / Lambert-93 (EPSG:2154), metres - Z : NGF-IGN69 (m) si calque SOL ou ANTENNE, sinon sans altitude (Z=0)');
    if (local) text('PIQ_INFO', minX, minY - 4, 0, TEXT_H_ALT, 'REPERE LOCAL : X Lambert-93 = X dessin + ' + ox.toFixed(0) + ' ; Y Lambert-93 = Y dessin + ' + oy.toFixed(0) + ' (metres)');
    text('PIQ_INFO', minX, minY - 3, 0, TEXT_H_ALT, 'Calques PIQ_PT_SOL / PIQ_PT_ANTENNE / PIQ_PT_SANS_Z : nature de l\'altitude. Export du ' + (info && info.date ? info.date : ''));

    D.points.forEach(function (p) {
      var z = isNum(p.h) ? p.h : 0;
      g(0, 'POINT'); g(8, layerOfPoint(p)); g(10, c3(p.x - ox)); g(20, c3(p.y - oy)); g(30, c3(z));
      // cercle visible : selon le logiciel, un POINT s'importe comme un repère non imprimé
      g(0, 'CIRCLE'); g(8, layerOfPoint(p)); g(10, c3(p.x - ox)); g(20, c3(p.y - oy)); g(30, c3(z)); g(40, MARK_R.toFixed(3));
      text('PIQ_NUM', p.x + 0.4, p.y + 0.4, z, TEXT_H_LABEL, 'P' + p.n);
      if (isNum(p.h)) text('PIQ_ALT', p.x + 0.4, p.y - 0.2, z, TEXT_H_ALT, p.h.toFixed(2));
    });

    D.tracks.forEach(function (tr) {
      if (tr.v.length < 2) return;
      var kind = trackKind(tr), layer = 'PIQ_TRACE_' + kind, is3d = kind !== '2D';
      g(0, 'POLYLINE'); g(8, layer); g(66, 1); g(10, '0.0'); g(20, '0.0'); g(30, '0.0'); g(70, is3d ? 8 : 0);
      tr.v.forEach(function (v) {
        g(0, 'VERTEX'); g(8, layer); g(10, c3(v.x - ox)); g(20, c3(v.y - oy)); g(30, is3d ? c3(v.h) : '0.000'); g(70, is3d ? 32 : 0);
      });
      g(0, 'SEQEND'); g(8, layer);
    });

    g(0, 'ENDSEC'); g(0, 'EOF');
    return out.join(NL) + NL;
  }

  /* ---------------- Ensemble ---------------- */

  /**
   * D : session.data ; opts : { decimal: 'virgule'|'point', now: Date }
   * Renvoie { files: [{name, mime, content}], summary, warnings } ou { error } si rien à exporter.
   */
  function build(D, opts) {
    opts = opts || {};
    var now = opts.now || new Date();
    var decimal = opts.decimal === 'virgule' ? 'virgule' : 'point';
    var origin = opts.origin === 'local' ? 'local' : 'l93';
    var nPts = D.points.length;
    var tracks = D.tracks.filter(function (t) { return t.v.length > 0; });
    var nVert = tracks.reduce(function (s, t) { return s + t.v.length; }, 0);
    if (!nPts && !nVert) return { error: 'Rien à exporter : aucun point ni tracé.' };

    var base = slug(D.project) + '_' + stamp(now);
    var iso = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) + ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes());
    var dd = { project: D.project, place: D.place, points: D.points, tracks: tracks };

    var files = [];
    if (nPts) files.push({ name: base + '_points.csv', mime: 'text/csv', content: csvPoints(dd, decimal) });
    if (nVert) files.push({ name: base + '_traces.csv', mime: 'text/csv', content: csvTracks(dd, decimal) });
    files.push({ name: base + (origin === 'local' ? '_local' : '') + '.dxf', mime: 'application/dxf', content: dxf(dd, { date: iso, origin: origin }) });

    var noZ = D.points.filter(function (p) { return !isNum(p.h); }).length;
    var ant = D.points.filter(function (p) { return p.k === 'A'; }).length;
    var vNoZ = tracks.reduce(function (s, t) { return s + t.v.filter(function (v) { return !isNum(v.h); }).length; }, 0);
    var mixed = tracks.filter(function (t) { return trackKind(t) === '2D' && t.v.some(function (v) { return isNum(v.h); }); }).length;
    var warnings = [];
    if (ant) warnings.push(ant + ' point' + (ant > 1 ? 's' : '') + ' avec altitude d’antenne (hauteur de canne ou centre de phase non saisis)');
    if (noZ) warnings.push(noZ + ' point' + (noZ > 1 ? 's' : '') + ' sans altitude (colonne vide en CSV, Z = 0 en DXF, calque PIQ_PT_SANS_Z)');
    if (vNoZ) warnings.push(vNoZ + ' sommet' + (vNoZ > 1 ? 's' : '') + ' de tracé sans altitude');
    if (mixed) warnings.push(mixed + ' tracé' + (mixed > 1 ? 's' : '') + ' aux altitudes de natures différentes : exporté' + (mixed > 1 ? 's' : '') + ' en 2D dans le DXF');

    return {
      files: files, warnings: warnings,
      summary: { points: nPts, tracks: tracks.length, vertices: nVert, decimal: decimal, origin: origin, base: base }
    };
  }

  return { build: build, csvPoints: csvPoints, csvTracks: csvTracks, dxf: dxf, slug: slug, ascii: ascii, trackKind: trackKind, LAYERS: LAYERS };
});
