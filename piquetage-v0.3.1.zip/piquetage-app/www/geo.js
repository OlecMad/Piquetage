/* ==================================================================
   Diagnostic Fluvial — module géodésique et NMEA

   Fonctionne à l'identique dans l'application (window.GEO) et sous Node
   (module.exports), ce qui permet de le valider contre PROJ/pyproj.

   Chaîne de calcul d'un point levé à la canne RTK :

     trame GGA  →  φ, λ (RGF93), altitude « MSL » A, séparation S
                   h_ell = A + S          hauteur ellipsoïdale de l'antenne
     RAF20      →  N(φ, λ)                 ondulation, interpolation bilinéaire
                   H_ant = h_ell − N       altitude NGF-IGN69 de l'antenne
                   H_sol = H_ant − (hauteur de canne + décalage centre de phase)
     Lambert-93 →  X, Y (EPSG:2154)

   Référentiel : les bases Centipede sont saisies en RGF93 (docs.centipede.fr,
   « Paramétrage du positionnement dans la base »). Une position RTK étant
   relative à la base, le rover restitue des coordonnées RGF93 : Lambert-93 et
   RAF20 (« From RGF93 v2b to NGF-IGN69 ») s'appliquent sans transformation.

   Sources des formules :
   · Lambert conique conforme sécant — IGN, notice NTG_71 ; Snyder J.P. (1987)
     Map Projections: A Working Manual, USGS PP 1395, §15.
   · Paramètres Lambert-93 : arrêté du 3 mars 2000 (JORF), EPSG:2154.
   · NMEA 0183 : trames GGA, GST, RMC.
   ================================================================== */

(function (root) {
  'use strict';

  /* ---------------- Ellipsoïde GRS80 et Lambert-93 ---------------- */

  var A = 6378137.0;
  var F = 1 / 298.257222101;
  var E2 = F * (2 - F);
  var E = Math.sqrt(E2);
  var D2R = Math.PI / 180;

  function mFn(phi) { var s = Math.sin(phi); return Math.cos(phi) / Math.sqrt(1 - E2 * s * s); }
  function tFn(phi) {
    var s = Math.sin(phi);
    return Math.tan(Math.PI / 4 - phi / 2) / Math.pow((1 - E * s) / (1 + E * s), E / 2);
  }

  var L93 = (function () {
    var p1 = 44 * D2R, p2 = 49 * D2R, p0 = 46.5 * D2R;
    var m1 = mFn(p1), m2 = mFn(p2);
    var t1 = tFn(p1), t2 = tFn(p2), t0 = tFn(p0);
    var n = (Math.log(m1) - Math.log(m2)) / (Math.log(t1) - Math.log(t2));
    var Fc = m1 / (n * Math.pow(t1, n));
    return { n: n, F: Fc, rho0: A * Fc * Math.pow(t0, n), lam0: 3 * D2R, X0: 700000, Y0: 6600000 };
  })();

  /** RGF93 géographique (degrés) → Lambert-93 (mètres). */
  function toLambert93(latDeg, lonDeg) {
    var phi = latDeg * D2R, lam = lonDeg * D2R;
    var rho = A * L93.F * Math.pow(tFn(phi), L93.n);
    var th = L93.n * (lam - L93.lam0);
    return {
      x: L93.X0 + rho * Math.sin(th),
      y: L93.Y0 + L93.rho0 - rho * Math.cos(th)
    };
  }

  /* ---------------- Grille RAF20 ---------------- */

  var grid = null;

  function b64ToBytes(b64) {
    if (typeof Buffer !== 'undefined') return new Uint8Array(Buffer.from(b64, 'base64'));
    var bin = atob(b64), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function loadGeoid(def) {
    if (!def || !def.data) return false;
    var bytes = b64ToBytes(def.data);
    var dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    var n = def.ncols * def.nrows, v = new Uint16Array(n);
    for (var i = 0; i < n; i++) v[i] = dv.getUint16(i * 2, true);   // petit-boutiste
    grid = { def: def, v: v };
    return true;
  }

  /**
   * Ondulation RAF20 N (m) en (lat, lon) RGF93, par interpolation bilinéaire
   * des quatre nœuds voisins — méthode de PROJ (vgridshift). null hors grille.
   */
  function geoidN(latDeg, lonDeg) {
    if (!grid && typeof root.RAF20 !== 'undefined') loadGeoid(root.RAF20);
    if (!grid) return null;
    var d = grid.def;
    var cx = (lonDeg - d.lon0) / d.dlon;
    var cy = (d.lat0 - latDeg) / d.dlat;
    if (!(cx >= 0 && cy >= 0 && cx <= d.ncols - 1 && cy <= d.nrows - 1)) return null;
    var i = Math.min(Math.floor(cx), d.ncols - 2);
    var j = Math.min(Math.floor(cy), d.nrows - 2);
    var fx = cx - i, fy = cy - j;
    function node(r, c) {
      var q = grid.v[r * d.ncols + c];
      return q === d.nodata ? NaN : d.offset + q * d.scale;
    }
    var v00 = node(j, i), v01 = node(j, i + 1), v10 = node(j + 1, i), v11 = node(j + 1, i + 1);
    var N = (1 - fy) * ((1 - fx) * v00 + fx * v01) + fy * ((1 - fx) * v10 + fx * v11);
    return isFinite(N) ? N : null;
  }

  /* ---------------- NMEA 0183 ---------------- */

  function checksumOk(line) {
    var star = line.lastIndexOf('*');
    if (line.charAt(0) !== '$' || star < 0 || star + 3 > line.length) return false;
    var cs = 0;
    for (var i = 1; i < star; i++) cs ^= line.charCodeAt(i);
    return cs === parseInt(line.substr(star + 1, 2), 16);
  }

  function num(s) { if (s === undefined || s === '') return null; var v = parseFloat(s); return isFinite(v) ? v : null; }

  function dm2deg(v, hemi, degDigits) {
    if (!v) return null;
    var d = parseInt(v.substr(0, degDigits), 10), m = parseFloat(v.substr(degDigits));
    if (!isFinite(d) || !isFinite(m)) return null;
    var x = d + m / 60;
    return (hemi === 'S' || hemi === 'W') ? -x : x;
  }

  var QUALITY = {
    0: { code: 'NONE',  label: 'Pas de position', rank: 0 },
    1: { code: 'GPS',   label: 'GNSS autonome',   rank: 1 },
    2: { code: 'DGPS',  label: 'DGNSS',           rank: 2 },
    3: { code: 'PPS',   label: 'PPS',             rank: 2 },
    4: { code: 'FIX',   label: 'RTK FIX',         rank: 4 },
    5: { code: 'FLOAT', label: 'RTK FLOAT',       rank: 3 },
    6: { code: 'DR',    label: 'Estimée',         rank: 0 },
    7: { code: 'MAN',   label: 'Manuelle',        rank: 0 },
    8: { code: 'SIM',   label: 'Simulation',      rank: 0 }
  };

  /**
   * Analyse une trame NMEA. Renvoie null si la somme de contrôle est fausse
   * ou le type non géré. Types gérés : GGA, GST, RMC (tout identifiant
   * d'émetteur : GP, GN, GL, GA, GB…).
   */
  function parseNmea(line) {
    line = String(line || '').trim();
    if (!checksumOk(line)) return null;
    var body = line.substring(1, line.lastIndexOf('*'));
    var f = body.split(',');
    var type = f[0].substr(2);

    if (type === 'GGA') {
      var q = parseInt(f[6], 10);
      var alt = num(f[9]), sep = num(f[11]);
      return {
        type: 'GGA',
        time: f[1] || null,
        lat: dm2deg(f[2], f[3], 2),
        lon: dm2deg(f[4], f[5], 3),
        quality: isFinite(q) ? q : 0,
        sats: num(f[7]),
        hdop: num(f[8]),
        altMsl: alt,
        sep: sep,
        hEll: (alt !== null && sep !== null) ? alt + sep : null,
        diffAge: num(f[13]),
        diffStation: f[14] || null
      };
    }
    if (type === 'GST') {
      return {
        type: 'GST',
        time: f[1] || null,
        rms: num(f[2]),
        sdLat: num(f[6]),
        sdLon: num(f[7]),
        sdAlt: num(f[8])
      };
    }
    if (type === 'RMC') {
      return { type: 'RMC', time: f[1] || null, status: f[2] || null, date: f[9] || null };
    }
    return null;
  }

  function qualityInfo(q) { return QUALITY[q] || { code: 'UNK', label: 'Inconnue (' + q + ')', rank: 0 }; }

  /* ---------------- Calcul d'un point levé ---------------- */

  /**
   * Agrège des époques GGA (+ GST associée) en un point levé.
   *
   * @param epochs  [{gga, gst}] — époques retenues, déjà filtrées par qualité
   * @param opts    { poleHeight, apcOffset } en mètres
   */
  function surveyPoint(epochs, opts) {
    opts = opts || {};
    var n = epochs.length;
    if (!n) return null;
    var sLat = 0, sLon = 0, sH = 0, nH = 0, minQ = 99;
    var gstN = 0, gLat = 0, gLon = 0, gAlt = 0, sats = 0, hdop = 0, nHd = 0, age = null;
    epochs.forEach(function (e) {
      var g = e.gga;
      sLat += g.lat; sLon += g.lon;
      if (g.hEll !== null) { sH += g.hEll; nH++; }
      if (qualityInfo(g.quality).rank < minQ) minQ = qualityInfo(g.quality).rank;
      if (g.sats !== null) sats = Math.max(sats, g.sats);
      if (g.hdop !== null) { hdop += g.hdop; nHd++; }
      if (g.diffAge !== null) age = g.diffAge;
      if (e.gst && e.gst.sdLat !== null && e.gst.sdLon !== null) {
        gstN++; gLat += e.gst.sdLat; gLon += e.gst.sdLon; gAlt += (e.gst.sdAlt || 0);
      }
    });
    var lat = sLat / n, lon = sLon / n;
    var hEll = nH === n ? sH / n : null;   // toutes les époques doivent porter la séparation

    // Dispersion empirique des époques (écart-type horizontal, m),
    // plan local tangent : 1° lat ≈ rayon méridien, 1° lon ≈ rayon parallèle.
    var sp = null;
    if (n > 1) {
      var phi = lat * D2R, s = Math.sin(phi), w = Math.sqrt(1 - E2 * s * s);
      var Mr = A * (1 - E2) / (w * w * w), Nr = A / w;
      var acc = 0;
      epochs.forEach(function (e) {
        var dy = (e.gga.lat - lat) * D2R * Mr;
        var dx = (e.gga.lon - lon) * D2R * Nr * Math.cos(phi);
        acc += dx * dx + dy * dy;
      });
      sp = Math.sqrt(acc / (n - 1));
    }

    var worst = epochs.map(function (e) { return e.gga.quality; })
      .sort(function (a, b) { return qualityInfo(a).rank - qualityInfo(b).rank; })[0];

    var N = geoidN(lat, lon);
    // Hauteur de canne et décalage du centre de phase : jamais de valeur par
    // défaut. Absent → altitude au sol non calculée (0 saisi explicitement = accepté).
    function given(v) { return !(v === null || v === undefined || v === '') && isFinite(+v); }
    var pole = given(opts.poleHeight) ? +opts.poleHeight : null;
    var apc = given(opts.apcOffset) ? +opts.apcOffset : null;
    var hAnt = (hEll !== null && N !== null) ? hEll - N : null;
    var l93 = toLambert93(lat, lon);

    return {
      lat: lat, lon: lon,
      x93: l93.x, y93: l93.y,
      hEll: hEll,
      geoidN: N,
      hNgfAntenna: hAnt,
      hNgfGround: (hAnt !== null && pole !== null && apc !== null) ? hAnt - pole - apc : null,
      poleHeight: pole, apcOffset: apc,
      quality: worst, qualityLabel: qualityInfo(worst).label,
      epochs: n,
      sats: sats || null,
      hdop: nHd ? hdop / nHd : null,
      sdLat: gstN ? gLat / gstN : null,
      sdLon: gstN ? gLon / gstN : null,
      sdAlt: gstN ? gAlt / gstN : null,
      spreadH: sp,
      diffAge: age,
      source: 'RTK'
    };
  }

  var api = {
    toLambert93: toLambert93,
    loadGeoid: loadGeoid,
    geoidN: geoidN,
    parseNmea: parseNmea,
    checksumOk: checksumOk,
    qualityInfo: qualityInfo,
    surveyPoint: surveyPoint,
    QUALITY: QUALITY,
    _L93: L93
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.GEO = api;
})(typeof window !== 'undefined' ? window : globalThis);
