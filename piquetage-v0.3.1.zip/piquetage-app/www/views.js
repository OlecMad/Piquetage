/* ==================================================================
   Piquetage — dessin du tracé (plan Lambert-93, nord en haut) et du
   profil altimétrique (distance sur le plan × altitude NGF).

   Fonctions pures de dessin : elles reçoivent un canvas, la session et la
   position en direct, et ne touchent à rien d'autre. Les couleurs viennent
   des variables CSS de la page (thème clair / sombre).
   ================================================================== */

(function (root) {
  'use strict';

  var Sess = root.PiqSession;

  function css(name, fallback) {
    var v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }

  function colors() {
    return {
      text: css('--text', '#1d2420'), muted: css('--muted', '#5d6a62'), border: css('--border', '#d5dcd6'),
      accent: css('--accent', '#2f6b4f'), orange: css('--orange', '#d9551a'), live: css('--live', '#1c6fd1'),
      card: css('--card', '#fff')
    };
  }

  /** Prépare le canvas à la densité de pixels de l'écran ; renvoie le contexte en pixels CSS. */
  function prepare(canvas) {
    var dpr = window.devicePixelRatio || 1;
    var w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return null;
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    }
    var ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx: ctx, w: w, h: h };
  }

  function fr(v, d) { return v.toFixed(d).replace('.', ','); }

  function emptyText(ctx, w, h, text, c) {
    ctx.fillStyle = c.muted; ctx.font = '500 14px system-ui, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(text, w / 2, h / 2);
  }

  /* ---------------- Tracé ---------------- */

  /**
   * data  : session.data ; live : {x, y, fix} ou null
   * Renvoie la transformation utilisée (pour les tests) ou null si rien n'est dessiné.
   */
  function drawTrack(canvas, session, live) {
    var P = prepare(canvas);
    if (!P) return null;
    var ctx = P.ctx, w = P.w, h = P.h, c = colors(), D = session.data;
    var b = session.bounds(live ? [live] : []);
    if (!b) { emptyText(ctx, w, h, 'Aucune position', c); return null; }

    var pad = 22;
    var spanX = Math.max(b.maxX - b.minX, 10), spanY = Math.max(b.maxY - b.minY, 10);   // au moins 10 m
    var cx = (b.minX + b.maxX) / 2, cy = (b.minY + b.maxY) / 2;
    var scale = Math.min((w - 2 * pad) / spanX, (h - 2 * pad) / spanY);                   // px par mètre
    var tx = function (x) { return w / 2 + (x - cx) * scale; };
    var ty = function (y) { return h / 2 - (y - cy) * scale; };

    var showLine = D.display === 'ligne' || D.display === 'les deux';
    var showDots = D.display === 'points' || D.display === 'les deux';

    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    D.tracks.forEach(function (tr, i) {
      if (!tr.v.length) return;
      if (showLine && tr.v.length > 1) {
        ctx.strokeStyle = c.accent; ctx.lineWidth = 3;
        ctx.beginPath();
        tr.v.forEach(function (p, k) { if (k) ctx.lineTo(tx(p.x), ty(p.y)); else ctx.moveTo(tx(p.x), ty(p.y)); });
        ctx.stroke();
      }
      if (showDots || tr.v.length === 1) {
        ctx.fillStyle = c.accent;
        tr.v.forEach(function (p) { ctx.beginPath(); ctx.arc(tx(p.x), ty(p.y), 3.5, 0, 6.2832); ctx.fill(); });
      }
      // départ du tracé
      ctx.strokeStyle = c.text; ctx.lineWidth = 2; ctx.fillStyle = c.card;
      ctx.beginPath(); ctx.arc(tx(tr.v[0].x), ty(tr.v[0].y), 5, 0, 6.2832); ctx.fill(); ctx.stroke();
    });

    // points levés, numérotés
    ctx.font = '700 12px system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    D.points.forEach(function (p) {
      var x = tx(p.x), y = ty(p.y);
      ctx.fillStyle = c.orange; ctx.strokeStyle = c.card; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, 6.5, 0, 6.2832); ctx.fill(); ctx.stroke();
      var label = 'P' + p.n;
      var tw = ctx.measureText(label).width;
      var lx = x + 10 + tw > w - 4 ? x - 10 - tw : x + 10;      // reste dans le cadre
      ctx.fillStyle = c.card; ctx.globalAlpha = 0.8; ctx.fillRect(lx - 2, y - 8, tw + 4, 16); ctx.globalAlpha = 1;
      ctx.fillStyle = c.text; ctx.fillText(label, lx, y);
    });

    // position en direct
    if (live) {
      var lx2 = tx(live.x), ly2 = ty(live.y);
      ctx.fillStyle = live.fix ? c.live : c.muted; ctx.strokeStyle = c.card; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(lx2, ly2, 7, 0, 6.2832); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = live.fix ? c.live : c.muted; ctx.lineWidth = 1.5; ctx.globalAlpha = 0.45;
      ctx.beginPath(); ctx.arc(lx2, ly2, 13, 0, 6.2832); ctx.stroke(); ctx.globalAlpha = 1;
    }

    // barre d'échelle (longueur ronde) et flèche du nord du plan
    var nice = Sess.niceLength(Math.min(120 / scale, spanX));
    if (nice > 0) {
      var len = nice * scale, x0 = 12, y0 = h - 14;
      ctx.strokeStyle = c.text; ctx.lineWidth = 2.5; ctx.lineCap = 'butt';
      ctx.beginPath(); ctx.moveTo(x0, y0 - 5); ctx.lineTo(x0, y0); ctx.lineTo(x0 + len, y0); ctx.lineTo(x0 + len, y0 - 5); ctx.stroke();
      ctx.fillStyle = c.text; ctx.font = '600 12px system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom';
      ctx.fillText(nice >= 1 ? nice + ' m' : fr(nice, 1) + ' m', x0 + 2, y0 - 7);
    }
    ctx.fillStyle = c.text; ctx.strokeStyle = c.text; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(w - 20, 40); ctx.lineTo(w - 20, 14); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(w - 20, 10); ctx.lineTo(w - 25, 19); ctx.lineTo(w - 15, 19); ctx.closePath(); ctx.fill();
    ctx.font = '700 11px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText('N', w - 20, 43);

    return { scale: scale, cx: cx, cy: cy, w: w, h: h };
  }

  /* ---------------- Profil ---------------- */

  function drawProfile(canvas, session) {
    var P = prepare(canvas);
    if (!P) return null;
    var ctx = P.ctx, w = P.w, h = P.h, c = colors();
    var tr = session.lastTrack();
    var pr = session.profile(tr);
    var withH = pr.filter(function (p) { return p.h !== null; });

    if (!pr.length) { emptyText(ctx, w, h, 'Démarrer un tracé pour voir le profil', c); return null; }
    if (!withH.length) { emptyText(ctx, w, h, 'Altitude indisponible', c); return null; }

    var left = 46, right = 12, top = 28, bottom = 20;
    var dMax = Math.max(pr[pr.length - 1].d, 10);                      // au moins 10 m de long
    var hMin = Math.min.apply(null, withH.map(function (p) { return p.h; }));
    var hMax = Math.max.apply(null, withH.map(function (p) { return p.h; }));
    var span = Math.max(hMax - hMin, 1);                               // au moins 1 m de haut
    var mid = (hMin + hMax) / 2;
    var y0 = mid - span / 2 - span * 0.08, y1 = mid + span / 2 + span * 0.08;
    var X = function (d) { return left + (d / dMax) * (w - left - right); };
    var Y = function (v) { return top + (1 - (v - y0) / (y1 - y0)) * (h - top - bottom); };

    // repères
    ctx.strokeStyle = c.border; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(left, top); ctx.lineTo(left, h - bottom); ctx.lineTo(w - right, h - bottom); ctx.stroke();
    ctx.fillStyle = c.muted; ctx.font = '500 11px system-ui, sans-serif'; ctx.textBaseline = 'middle'; ctx.textAlign = 'right';
    ctx.fillText(fr(hMax, 1), left - 5, Y(hMax)); ctx.fillText(fr(hMin, 1), left - 5, Y(hMin));
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText('0', left, h - bottom + 4);
    ctx.textAlign = 'right';
    ctx.fillText(fr(dMax, dMax < 100 ? 1 : 0) + ' m', w - right, h - bottom + 4);
    var kind = pr[pr.length - 1].k === 'S' ? 'H sol' : (pr[pr.length - 1].k === 'A' ? 'H antenne' : 'H');
    ctx.textAlign = 'center'; ctx.fillText(kind + ' NGF (m)', (left + w - right) / 2, h - bottom + 4);

    // courbe : interrompue quand la nature de l'altitude change ou qu'elle manque
    ctx.strokeStyle = c.accent; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    var prev = null;
    ctx.beginPath();
    pr.forEach(function (p) {
      if (p.h === null) { prev = null; return; }
      if (prev && prev.k === p.k) ctx.lineTo(X(p.d), Y(p.h)); else ctx.moveTo(X(p.d), Y(p.h));
      prev = p;
    });
    ctx.stroke();

    // position actuelle (dernier sommet avec altitude)
    var end = withH[withH.length - 1];
    ctx.fillStyle = c.live; ctx.strokeStyle = c.card; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(X(end.d), Y(end.h), 5, 0, 6.2832); ctx.fill(); ctx.stroke();

    return { dMax: dMax, hMin: hMin, hMax: hMax, n: pr.length };
  }

  root.PiqViews = { drawTrack: drawTrack, drawProfile: drawProfile };
})(window);
