/* ==================================================================
   Piquetage — noyau RTK (sans interface)

   Logique de la canne GNSS RTK extraite de rtk.js (Diagnostic Fluvial 1.6) :
   réglages persistés, liaison Bluetooth Classic SPP et reconnexion
   automatique, client NTRIP, association des trames GGA/GST en époques,
   état de qualité, levé d'un point moyenné (Lambert-93, NGF-IGN69 via geo.js).

   Aucun accès au DOM : l'interface s'abonne aux événements.
     'change'  — l'état a changé (liaison, trame reçue, vieillissement 1 s)
     'epoch'   — nouvelle époque {gga, gst, at}
     'message' — texte court à signaler à l'opérateur (ancien « toast »)

   Fonctionne dans la WebView (window.RtkCore) et sous Node (module.exports),
   pour les tests : tools/test-rtk-core.js.

   Matériel de référence : ArduSimple RTK Calibrated Surveyor Kit (ZED-F9P),
   Bluetooth Classic « RTK_GNSS_*** », NMEA 1 Hz, réseau Centipede
   (crtk.net:2101, NTRIP v1). Comportement repris tel quel de rtk.js, validé
   sur le terrain avec Diagnostic Fluvial.
   ================================================================== */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.RtkCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var STORAGE_KEY = 'piquetage.rtk';
  var FRESH_MS = 3000;          // au-delà, la dernière position n'est plus « fraîche »
  var EPOCH_BUFFER = 120;
  var RECONNECT_MS = 5000;

  var DEF = {
    address: '', name: '',
    ntrip: { enabled: true, host: 'crtk.net', port: 2101, mount: 'NEAR', user: 'centipede', pass: 'centipede', gga: 10 },
    pole: '', apc: '',            // aucune valeur par défaut : à mesurer / à relever
    requireFix: true,
    avg: 5
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  // Virgule décimale acceptée : « 1,800 » vaut 1,8 m, quelle que soit la langue du système.
  function dec(v) { return String(v).trim().replace(',', '.'); }
  function errMsg(e) { return (e && (e.message || e.errorMessage)) || 'Erreur Bluetooth'; }
  function cm(m) { return (m === null || m === undefined || !isFinite(m)) ? null : (m * 100).toFixed(1).replace('.', ',') + ' cm'; }

  var DEFAULT_TIMERS = {
    now: function () { return Date.now(); },
    setTimeout: function (f, ms) { return setTimeout(f, ms); },
    clearTimeout: function (h) { clearTimeout(h); },
    setInterval: function (f, ms) { return setInterval(f, ms); },
    clearInterval: function (h) { clearInterval(h); }
  };

  /**
   * opts.geo      module geo.js (obligatoire)
   * opts.plugin   plugin Capacitor GnssBridge (absent : navigateur, lecture seule)
   * opts.storage  objet {getItem, setItem} (localStorage) — facultatif
   * opts.timers   horloge injectable (tests)
   */
  function create(opts) {
    opts = opts || {};
    var GEO = opts.geo;
    if (!GEO) throw new Error('rtk-core : geo.js est requis');
    var P = opts.plugin || null;
    var store = opts.storage || null;
    var T = opts.timers || DEFAULT_TIMERS;

    /* ---------------- Réglages (persistés) ---------------- */

    var S = clone(DEF);
    try {
      var saved = store ? JSON.parse(store.getItem(STORAGE_KEY) || 'null') : null;
      if (saved && typeof saved === 'object') {
        Object.keys(DEF).forEach(function (k) { if (saved[k] !== undefined) S[k] = saved[k]; });
        S.ntrip = Object.assign({}, DEF.ntrip, saved.ntrip || {});
      }
    } catch (e) { /* stockage indisponible : réglages par défaut */ }
    function persist() { try { if (store) store.setItem(STORAGE_KEY, JSON.stringify(S)); } catch (e) {} }

    /* ---------------- État en direct ---------------- */

    var L = {
      bt: 'disconnected', btMsg: '', wantConnected: false,
      ntrip: 'stopped', ntripMsg: '', ntripBytes: 0,
      gga: null, ggaAt: 0, gst: null,
      epochs: [],                   // [{gga, gst, at}] — 120 dernières époques
      devices: [],
      capturing: false
    };

    /* ---------------- Événements ---------------- */

    var handlers = { change: [], epoch: [], message: [] };
    function on(name, fn) {
      if (!handlers[name]) throw new Error('événement inconnu : ' + name);
      handlers[name].push(fn);
      return function off() { var i = handlers[name].indexOf(fn); if (i >= 0) handlers[name].splice(i, 1); };
    }
    function emit(name, arg) { handlers[name].slice().forEach(function (fn) { try { fn(arg); } catch (e) { /* un abonné défaillant ne bloque pas les autres */ } }); }
    function changed() { emit('change', status()); }
    function say(m) { emit('message', m); }

    /* ---------------- Réglages : modification ---------------- */

    var NTRIP_KEYS = ['enabled', 'host', 'port', 'mount', 'gga', 'user', 'pass'];

    function set(key, value) {
      if (key === 'pole' || key === 'apc') { S[key] = dec(value); }
      else if (key === 'avg') { S.avg = parseInt(value, 10) || 1; }
      else if (key === 'requireFix') { S.requireFix = !!value; }
      else if (key.indexOf('ntrip.') === 0) {
        var k = key.slice(6);
        if (NTRIP_KEYS.indexOf(k) < 0) throw new Error('réglage inconnu : ' + key);
        if (k === 'enabled') {
          S.ntrip.enabled = !!value;
          persist();
          if (L.bt === 'connected') { if (S.ntrip.enabled) startNtrip(); else stopNtrip(); }
          changed();
          return;
        }
        S.ntrip[k] = (k === 'port' || k === 'gga') ? (parseInt(value, 10) || DEF.ntrip[k]) : String(value).trim();
      } else throw new Error('réglage inconnu : ' + key);
      persist();
      changed();
    }

    /** Hauteurs nécessaires à l'altitude au sol : jamais de valeur par défaut. */
    function heightNote() {
      var missing = [];
      if (S.pole === '' || !isFinite(+S.pole)) missing.push('la hauteur de canne');
      if (S.apc === '' || !isFinite(+S.apc)) missing.push('le décalage du centre de phase');
      return { complete: missing.length === 0, missing: missing };
    }

    /* ---------------- État dérivé ---------------- */

    function status() {
      var now = T.now();
      var fresh = !!(L.gga && (now - L.ggaAt < FRESH_MS));
      var code, label;
      if (L.bt === 'connecting') { code = 'OFF'; label = 'Connexion…'; }
      else if (L.bt !== 'connected') { code = 'OFF'; label = L.wantConnected ? 'Reconnexion…' : 'Non reliée'; }
      else if (!fresh) { code = 'NONE'; label = 'Aucune trame'; }
      else { var qi = GEO.qualityInfo(L.gga.quality); code = qi.code; label = qi.label; }

      var g = fresh ? L.gga : null;
      var gst = (g && L.gst && L.gst.time === g.time) ? L.gst : null;
      var sdH = (gst && gst.sdLat !== null && gst.sdLon !== null) ? Math.sqrt(gst.sdLat * gst.sdLat + gst.sdLon * gst.sdLon) : null;
      var point = null;
      if (g && g.lat !== null) point = GEO.surveyPoint([{ gga: g, gst: gst }], { poleHeight: S.pole, apcOffset: S.apc });

      return {
        available: !!P,
        code: code, label: label,
        connected: L.bt === 'connected', connecting: L.bt === 'connecting', wantConnected: L.wantConnected,
        fresh: fresh,
        quality: g ? g.quality : null,
        sats: g ? g.sats : null, hdop: g ? g.hdop : null, diffAge: g ? g.diffAge : null,
        sdH: sdH, sdV: (gst && gst.sdAlt !== null) ? gst.sdAlt : null, gstAvailable: !!gst,
        point: point,
        heights: heightNote(),
        ntrip: { state: L.ntrip, message: L.ntripMsg, bytes: L.ntripBytes, enabled: !!S.ntrip.enabled },
        btMessage: L.btMsg
      };
    }

    /* ---------------- Trames NMEA ---------------- */

    function onNmea(ev) {
      var m = GEO.parseNmea(ev && ev.line);
      if (!m) return;
      var now = T.now();
      if (m.type === 'GGA') {
        L.gga = m; L.ggaAt = now;
        if (m.lat !== null && m.lon !== null) {
          var ep = { gga: m, gst: null, at: now };
          L.epochs.push(ep);
          if (L.epochs.length > EPOCH_BUFFER) L.epochs.shift();
          emit('epoch', ep);
        }
        changed();
      } else if (m.type === 'GST') {
        L.gst = m;
        // la GST suit la GGA dans l'époque u-blox : on l'associe par l'heure
        for (var i = L.epochs.length - 1; i >= 0 && i >= L.epochs.length - 3; i--) {
          if (L.epochs[i].gga.time === m.time) { L.epochs[i].gst = m; break; }
        }
        changed();   // la GST arrive après la GGA de la même époque
      }
    }

    /* ---------------- Bluetooth ---------------- */

    function refreshDevices() {
      if (!P) return Promise.resolve([]);
      return P.listDevices().then(function (r) {
        var devs = (r && r.devices) || [];
        L.devices = devs.map(function (d) { return { name: String(d.name), address: d.address, ble: d.type === 2 }; });
        if (!S.address) {
          var guess = L.devices.filter(function (d) { return /^RTK_GNSS/i.test(d.name); })[0];
          if (guess) { S.address = guess.address; S.name = guess.name; persist(); }
        }
        if (!devs.length) say('Aucun appareil appairé — appairer la canne dans les paramètres Bluetooth d’Android (PIN 1234)');
        changed();
        return L.devices;
      }).catch(function (e) { say(errMsg(e)); return []; });
    }

    var reconnectTimer = null;
    function scheduleReconnect() {
      if (!L.wantConnected || reconnectTimer) return;
      reconnectTimer = T.setTimeout(function () {
        reconnectTimer = null;
        if (L.wantConnected && L.bt !== 'connected' && L.bt !== 'connecting') connect();
      }, RECONNECT_MS);
    }

    function connect(address) {
      if (!P) return Promise.reject(new Error('La canne se relie depuis l’application Android'));
      var addr = address || S.address;
      if (!addr) { say('Choisir le récepteur dans la liste'); return Promise.resolve(false); }
      S.address = addr;
      var dev = L.devices.filter(function (d) { return d.address === addr; })[0];
      S.name = dev ? dev.name : (S.name || addr);
      persist();
      L.wantConnected = true;
      L.bt = 'connecting'; changed();
      return P.connect({ address: addr }).then(function () {
        L.bt = 'connected'; changed();
        say('Canne reliée : ' + S.name);
        if (S.ntrip.enabled) startNtrip();
        return true;
      }).catch(function (e) {
        L.bt = 'disconnected'; changed();
        say(errMsg(e));
        scheduleReconnect();
        return false;
      });
    }

    function disconnect() {
      L.wantConnected = false;
      if (reconnectTimer) { T.clearTimeout(reconnectTimer); reconnectTimer = null; }
      stopNtrip();
      if (P) P.disconnect().catch(function () {});
      L.bt = 'disconnected'; L.gga = null; changed();
    }

    function onBt(ev) {
      if (!ev) return;
      if (ev.state === 'disconnected' || ev.state === 'error') {
        var was = L.bt === 'connected';
        L.bt = 'disconnected'; L.btMsg = ev.message || '';
        if (was) { say('Liaison avec la canne perdue — reconnexion automatique'); stopNtrip(); }
        changed();
        scheduleReconnect();
      } else if (ev.state === 'connected') { L.bt = 'connected'; changed(); }
      else if (ev.state === 'connecting') { L.bt = 'connecting'; changed(); }
    }

    /* ---------------- NTRIP ---------------- */

    function startNtrip() {
      if (!P || !S.ntrip.enabled) return;
      if (!S.ntrip.mount) { say('Point de montage NTRIP manquant'); return; }
      P.startNtrip({
        host: S.ntrip.host, port: +S.ntrip.port, mountpoint: S.ntrip.mount,
        user: S.ntrip.user, password: S.ntrip.pass, ggaInterval: +S.ntrip.gga
      }).catch(function (e) { say('NTRIP : ' + errMsg(e)); });
    }
    function stopNtrip() {
      if (P) P.stopNtrip().catch(function () {});
      L.ntrip = 'stopped'; L.ntripMsg = '';
      changed();   // affichage immédiat, sans attendre l'événement du plugin
    }

    function onNtrip(ev) {
      if (!ev) return;
      if (ev.state) {
        var prev = L.ntrip;
        L.ntrip = ev.state;
        if (ev.message !== undefined) L.ntripMsg = ev.message;
        if (ev.state === 'error' && prev !== 'error') say('NTRIP : ' + (ev.message || 'erreur'));
      }
      if (typeof ev.bytes === 'number') L.ntripBytes = ev.bytes;
      changed();
    }

    /* ---------------- Levé d'un point ---------------- */

    /** Promesse : le point levé, ou une erreur dont le message est destiné à l'opérateur. */
    function capture() {
      return new Promise(function (resolve, reject) {
        if (L.bt !== 'connected') return reject(new Error('Canne non reliée'));
        if (L.capturing) return reject(new Error('Mesure RTK déjà en cours'));
        if (!L.gga || T.now() - L.ggaAt > FRESH_MS) return reject(new Error('Canne reliée mais aucune position reçue — vérifier l’antenne et le ciel'));
        if (S.requireFix && L.gga.quality !== 4) {
          return reject(new Error('Point refusé : ' + GEO.qualityInfo(L.gga.quality).label + ' — RTK FIX exigé'));
        }
        var target = Math.max(1, S.avg | 0);
        var maxWait = target === 1 ? 3000 : Math.max(target * 2000, (target + 5) * 1000);
        var start = T.now();
        L.capturing = true;

        function eligible() {
          return L.epochs.filter(function (e) {
            return e.at >= start - (target === 1 ? 1100 : 0) &&
              e.gga.lat !== null && (!S.requireFix || e.gga.quality === 4);
          });
        }

        var timer = T.setInterval(function () {
          var got = eligible();
          var elapsed = T.now() - start;
          if (target > 1) say('Mesure RTK… ' + Math.min(got.length, target) + ' / ' + target + ' époques');
          if (got.length >= target || elapsed >= maxWait) {
            T.clearInterval(timer);
            // laisser arriver la GST de la dernière époque
            T.setTimeout(function () {
              L.capturing = false;
              var eps = eligible().slice(0, target);
              if (!eps.length) {
                return reject(new Error(S.requireFix ? 'Aucune époque RTK FIX pendant la mesure — point refusé' : 'Aucune position pendant la mesure'));
              }
              var rejected = L.epochs.filter(function (e) { return e.at >= start && S.requireFix && e.gga.quality !== 4; }).length;
              var p = GEO.surveyPoint(eps, { poleHeight: S.pole, apcOffset: S.apc });
              p.t = new Date(T.now()).toISOString();
              p.epochsRequested = target;
              p.epochsRejected = rejected;
              p.receiver = S.name || S.address;
              p.mountpoint = S.ntrip.enabled ? S.ntrip.mount : 'radio / hors NTRIP';
              p.acc = (p.sdLat !== null && p.sdLon !== null) ? Math.sqrt(p.sdLat * p.sdLat + p.sdLon * p.sdLon) : null;
              say(p.qualityLabel + ' · ' + eps.length + ' époque' + (eps.length > 1 ? 's' : '') +
                (p.acc !== null ? ' · ±' + cm(p.acc) : '') + (eps.length < target ? ' (sur ' + target + ' demandées)' : ''));
              resolve(p);
            }, 350);
          }
        }, 250);
      });
    }

    /* ---------------- Démarrage / arrêt ---------------- */

    var handles = [];
    var heartbeat = T.setInterval(changed, 1000);   // fait vieillir l'état si les trames cessent
    if (P) {
      [['nmea', onNmea], ['bluetooth', onBt], ['ntrip', onNtrip]].forEach(function (pair) {
        var h = P.addListener(pair[0], pair[1]);
        handles.push(h);
      });
    }

    function dispose() {
      T.clearInterval(heartbeat);
      if (reconnectTimer) { T.clearTimeout(reconnectTimer); reconnectTimer = null; }
      handles.forEach(function (h) {
        Promise.resolve(h).then(function (x) { if (x && typeof x.remove === 'function') x.remove(); }).catch(function () {});
      });
      handles = [];
    }

    return {
      settings: S, live: L,
      on: on, set: set, status: status, heightNote: heightNote,
      refreshDevices: refreshDevices, connect: connect, disconnect: disconnect,
      startNtrip: startNtrip, stopNtrip: stopNtrip,
      capture: capture, dispose: dispose,
      cm: cm
    };
  }

  return { create: create, DEF: DEF, STORAGE_KEY: STORAGE_KEY };
});
