package fr.lileauvert.piquetage;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Build;
import android.util.Base64;
import android.view.WindowManager;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pont entre l'application et la canne GNSS RTK.
 *
 * Matériel visé : ArduSimple RTK Calibrated Surveyor Kit (u-blox ZED-F9P),
 * Bluetooth 2.0 Classic, profil série SPP, NMEA à 1 Hz. Fonctionne avec tout
 * récepteur exposant du NMEA sur un port série Bluetooth Classic.
 *
 * Deux flux indépendants :
 *   1. Bluetooth : lecture des trames NMEA du récepteur, transmises à la page
 *      (événement « nmea », trames GGA, GST et RMC uniquement) ;
 *   2. NTRIP (facultatif) : client NTRIP v1 vers le caster Centipede
 *      (crtk.net:2101). Les corrections RTCM3 sont écrites directement sur la
 *      liaison Bluetooth, sans passer par la page. La dernière GGA reçue est
 *      renvoyée au caster toutes les N secondes, ce que le guide de terrain
 *      exige (« activer l'envoi de la position GGA »).
 *
 * Le client NTRIP se désactive quand les corrections arrivent autrement,
 * par exemple par la radio LR de la base transportable.
 */
@CapacitorPlugin(
    name = "GnssBridge",
    permissions = {
        @Permission(alias = "bluetooth", strings = { Manifest.permission.BLUETOOTH_CONNECT })
    }
)
public class GnssBridgePlugin extends Plugin {

    /** UUID normalisé du profil série Bluetooth (SPP). */
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final ExecutorService exec = Executors.newCachedThreadPool();
    private final Object btWriteLock = new Object();

    // --- Bluetooth ---
    private volatile BluetoothSocket btSocket;
    private volatile OutputStream btOut;
    private volatile String btName = "";
    private volatile String btAddress = "";
    private volatile String lastGga = null;
    private volatile long nmeaLines = 0;

    // --- NTRIP ---
    private volatile boolean ntripWanted = false;
    private volatile Socket ntripSocket;
    private volatile String ntripState = "stopped";
    private volatile long ntripBytes = 0;
    private volatile long lastRtcmAt = 0;
    private Thread ntripThread;

    /* ================================================================
       Permissions — BLUETOOTH_CONNECT n'existe qu'à partir d'Android 12
       (API 31). En deçà, les permissions BLUETOOTH / BLUETOOTH_ADMIN sont
       accordées à l'installation : aucune demande à faire.
       ================================================================ */

    private boolean needsBtPermission() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            && getPermissionState("bluetooth") != PermissionState.GRANTED;
    }

    private BluetoothAdapter adapter() {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        return bm != null ? bm.getAdapter() : null;
    }

    /* ================================================================
       Liste des appareils appairés
       L'appairage se fait dans les paramètres Android (guide, étape A.03) :
       on ne liste que les appareils déjà appairés, sans recherche.
       ================================================================ */

    @PluginMethod
    public void listDevices(PluginCall call) {
        if (needsBtPermission()) {
            requestPermissionForAlias("bluetooth", call, "listDevicesPermission");
            return;
        }
        doListDevices(call);
    }

    @PermissionCallback
    private void listDevicesPermission(PluginCall call) {
        if (getPermissionState("bluetooth") == PermissionState.GRANTED) doListDevices(call);
        else call.reject("Permission Bluetooth refusée", "PERMISSION_DENIED");
    }

    @SuppressLint("MissingPermission")
    private void doListDevices(PluginCall call) {
        BluetoothAdapter ad = adapter();
        if (ad == null) { call.reject("Aucun Bluetooth sur cet appareil", "NO_BLUETOOTH"); return; }
        if (!ad.isEnabled()) { call.reject("Le Bluetooth est désactivé", "BLUETOOTH_OFF"); return; }
        JSArray list = new JSArray();
        Set<BluetoothDevice> bonded = ad.getBondedDevices();
        if (bonded != null) {
            for (BluetoothDevice d : bonded) {
                JSObject o = new JSObject();
                String name = d.getName();
                o.put("name", name != null ? name : "(sans nom)");
                o.put("address", d.getAddress());
                o.put("type", d.getType());   // 1 Classic, 2 LE, 3 double
                list.put(o);
            }
        }
        JSObject res = new JSObject();
        res.put("devices", list);
        call.resolve(res);
    }

    /* ================================================================
       Connexion Bluetooth SPP
       ================================================================ */

    @PluginMethod
    public void connect(PluginCall call) {
        if (needsBtPermission()) {
            requestPermissionForAlias("bluetooth", call, "connectPermission");
            return;
        }
        doConnect(call);
    }

    @PermissionCallback
    private void connectPermission(PluginCall call) {
        if (getPermissionState("bluetooth") == PermissionState.GRANTED) doConnect(call);
        else call.reject("Permission Bluetooth refusée", "PERMISSION_DENIED");
    }

    @SuppressLint("MissingPermission")
    private void doConnect(final PluginCall call) {
        final String address = call.getString("address");
        if (address == null || address.isEmpty()) { call.reject("Adresse Bluetooth manquante", "BAD_ARGUMENT"); return; }
        final BluetoothAdapter ad = adapter();
        if (ad == null) { call.reject("Aucun Bluetooth sur cet appareil", "NO_BLUETOOTH"); return; }
        if (!ad.isEnabled()) { call.reject("Le Bluetooth est désactivé", "BLUETOOTH_OFF"); return; }

        closeBluetooth(false);
        emitBt("connecting", address);

        exec.execute(() -> {
            BluetoothDevice dev;
            try {
                dev = ad.getRemoteDevice(address);
            } catch (IllegalArgumentException e) {
                emitBt("error", "Adresse invalide");
                call.reject("Adresse Bluetooth invalide : " + address, "BAD_ARGUMENT");
                return;
            }
            try { ad.cancelDiscovery(); } catch (SecurityException ignored) { }

            BluetoothSocket s = null;
            String lastError = "";
            // 1. socket sécurisé standard ; 2. socket non sécurisé (modules HC-05 et
            // certains ponts série) ; 3. canal RFCOMM 1 par réflexion, contournement
            // connu pour les piles Bluetooth qui ne publient pas l'enregistrement SDP.
            for (int attempt = 0; attempt < 3 && s == null; attempt++) {
                BluetoothSocket candidate = null;
                try {
                    if (attempt == 0) candidate = dev.createRfcommSocketToServiceRecord(SPP_UUID);
                    else if (attempt == 1) candidate = dev.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    else {
                        Method m = dev.getClass().getMethod("createRfcommSocket", int.class);
                        candidate = (BluetoothSocket) m.invoke(dev, 1);
                    }
                    candidate.connect();
                    s = candidate;
                } catch (Exception e) {
                    lastError = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                    closeQuietly(candidate);
                }
            }

            if (s == null) {
                emitBt("error", "Connexion impossible : " + lastError);
                call.reject("Connexion impossible à " + address + " : " + lastError, "CONNECT_FAILED");
                return;
            }

            final BluetoothSocket sock = s;
            try {
                synchronized (btWriteLock) { btOut = sock.getOutputStream(); }
            } catch (IOException e) {
                closeQuietly(sock);
                emitBt("error", "Flux de sortie indisponible");
                call.reject("Flux Bluetooth indisponible", "CONNECT_FAILED");
                return;
            }
            btSocket = sock;
            String n = dev.getName();
            btName = n != null ? n : address;
            btAddress = address;
            nmeaLines = 0;
            keepScreenOn(true);
            exec.execute(() -> readLoop(sock));

            emitBt("connected", btName);
            JSObject res = new JSObject();
            res.put("name", btName);
            res.put("address", btAddress);
            call.resolve(res);
        });
    }

    /** Lit le flux du récepteur, découpe en lignes et transmet GGA / GST / RMC. */
    private void readLoop(BluetoothSocket sock) {
        byte[] buf = new byte[4096];
        StringBuilder line = new StringBuilder(128);
        try {
            InputStream in = sock.getInputStream();
            while (btSocket == sock) {
                int n = in.read(buf);
                if (n < 0) break;
                for (int i = 0; i < n; i++) {
                    char c = (char) (buf[i] & 0xFF);
                    if (c == '\n') {
                        handleLine(line.toString().trim());
                        line.setLength(0);
                    } else if (c != '\r') {
                        // une ligne NMEA fait au plus 82 caractères ; au-delà c'est du binaire (UBX)
                        if (line.length() < 256) line.append(c); else line.setLength(0);
                    }
                }
            }
        } catch (IOException ignored) {
            // liaison coupée : traitée ci-dessous
        }
        if (btSocket == sock) {
            closeBluetooth(false);
            emitBt("disconnected", "Liaison perdue avec " + btName);
        }
    }

    private void handleLine(String l) {
        if (l.length() < 7 || l.charAt(0) != '$') return;
        String type = l.substring(3, 6);
        if ("GGA".equals(type)) lastGga = l;
        if ("GGA".equals(type) || "GST".equals(type) || "RMC".equals(type)) {
            nmeaLines++;
            JSObject o = new JSObject();
            o.put("line", l);
            o.put("t", System.currentTimeMillis());
            notifyListeners("nmea", o);
        }
    }

    /** Écrit des octets vers le récepteur (corrections RTCM3). */
    private void writeToReceiver(byte[] data, int len) {
        synchronized (btWriteLock) {
            if (btOut == null) return;
            try {
                btOut.write(data, 0, len);
                btOut.flush();
            } catch (IOException ignored) {
                // la boucle de lecture détectera la coupure
            }
        }
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        closeBluetooth(true);
        call.resolve();
    }

    private void closeBluetooth(boolean notify) {
        BluetoothSocket s = btSocket;
        btSocket = null;
        synchronized (btWriteLock) { btOut = null; }
        closeQuietly(s);
        keepScreenOn(false);
        if (notify && s != null) emitBt("disconnected", "Déconnecté");
    }

    /* ================================================================
       Client NTRIP v1
       ================================================================ */

    @PluginMethod
    public void startNtrip(PluginCall call) {
        final String host = call.getString("host", "crtk.net");
        final int port = call.getInt("port", 2101);
        final String mount = call.getString("mountpoint", "").trim();
        final String user = call.getString("user", "");
        final String pass = call.getString("password", "");
        final int ggaInterval = Math.max(1, call.getInt("ggaInterval", 10));

        if (mount.isEmpty()) { call.reject("Point de montage manquant", "BAD_ARGUMENT"); return; }

        stopNtripInternal();
        ntripWanted = true;
        ntripBytes = 0;
        lastRtcmAt = 0;
        ntripThread = new Thread(() -> ntripLoop(host, port, mount, user, pass, ggaInterval), "ntrip");
        ntripThread.start();
        call.resolve();
    }

    private void ntripLoop(String host, int port, String mount, String user, String pass, int ggaIntervalS) {
        while (ntripWanted) {
            Socket sock = new Socket();
            try {
                emitNtrip("connecting", host + ":" + port + "/" + mount);
                sock.connect(new InetSocketAddress(host, port), 10000);
                sock.setSoTimeout(2000);
                ntripSocket = sock;
                OutputStream out = sock.getOutputStream();
                InputStream in = sock.getInputStream();

                StringBuilder req = new StringBuilder();
                req.append("GET /").append(mount).append(" HTTP/1.0\r\n");
                req.append("User-Agent: NTRIP Piquetage/0.1\r\n");
                req.append("Accept: */*\r\n");
                req.append("Connection: close\r\n");
                if (user != null && !user.isEmpty()) {
                    String auth = Base64.encodeToString(
                        (user + ":" + (pass != null ? pass : "")).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                    req.append("Authorization: Basic ").append(auth).append("\r\n");
                }
                req.append("\r\n");
                out.write(req.toString().getBytes(StandardCharsets.US_ASCII));
                out.flush();

                String status = readHeaderLine(in);
                if (status.startsWith("ICY 200")) {
                    // NTRIP v1 : les données suivent immédiatement
                } else if (status.startsWith("HTTP/1.") && status.contains(" 200")) {
                    // Réponse de type HTTP : lire les en-têtes jusqu'à la ligne vide
                    String h;
                    while (!(h = readHeaderLine(in)).isEmpty()) {
                        if (h.toLowerCase(Locale.ROOT).startsWith("transfer-encoding:") && h.toLowerCase(Locale.ROOT).contains("chunked")) {
                            throw new FatalNtrip("Le caster répond en NTRIP v2 (chunked), non géré");
                        }
                    }
                } else if (status.startsWith("SOURCETABLE")) {
                    throw new FatalNtrip("Point de montage « " + mount + " » inconnu du caster");
                } else if (status.contains("401")) {
                    throw new FatalNtrip("Identifiants refusés par le caster");
                } else {
                    throw new IOException("Réponse inattendue du caster : " + (status.isEmpty() ? "(vide)" : status));
                }

                emitNtrip("connected", mount);

                long nextGga = 0;
                long lastStat = 0;
                int silentPeriods = 0;
                byte[] buf = new byte[4096];
                while (ntripWanted) {
                    long now = System.currentTimeMillis();
                    String gga = lastGga;
                    if (gga != null && now >= nextGga) {
                        out.write((gga + "\r\n").getBytes(StandardCharsets.US_ASCII));
                        out.flush();
                        nextGga = now + ggaIntervalS * 1000L;
                    }
                    int n;
                    try {
                        n = in.read(buf);
                    } catch (SocketTimeoutException te) {
                        // 15 × 2 s sans octet : le flux est considéré comme mort
                        if (++silentPeriods >= 15) throw new IOException("Aucune correction reçue depuis 30 s");
                        continue;
                    }
                    if (n < 0) throw new IOException("Le caster a fermé la connexion");
                    silentPeriods = 0;
                    ntripBytes += n;
                    lastRtcmAt = System.currentTimeMillis();
                    writeToReceiver(buf, n);
                    if (lastRtcmAt - lastStat >= 2000) {
                        lastStat = lastRtcmAt;
                        JSObject o = new JSObject();
                        o.put("state", "connected");
                        o.put("bytes", ntripBytes);
                        o.put("mountpoint", mount);
                        notifyListeners("ntrip", o);
                    }
                }
            } catch (FatalNtrip e) {
                ntripWanted = false;
                emitNtrip("error", e.getMessage());
            } catch (IOException e) {
                if (ntripWanted) emitNtrip("error", e.getMessage() != null ? e.getMessage() : "Erreur réseau");
            } finally {
                closeQuietly(sock);
                if (ntripSocket == sock) ntripSocket = null;
            }
            if (ntripWanted) {
                emitNtrip("reconnecting", "Nouvel essai dans 5 s");
                try { Thread.sleep(5000); } catch (InterruptedException ie) { break; }
            }
        }
        emitNtrip("stopped", "");
    }

    /** Lit une ligne d'en-tête (jusqu'à \n, 1 024 octets au plus). */
    private static String readHeaderLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        long deadline = System.currentTimeMillis() + 10000;
        while (sb.length() < 1024) {
            int c;
            try {
                c = in.read();
            } catch (SocketTimeoutException te) {
                if (System.currentTimeMillis() > deadline) throw new IOException("Pas de réponse du caster");
                continue;
            }
            if (c < 0) break;
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        return sb.toString().trim();
    }

    @PluginMethod
    public void stopNtrip(PluginCall call) {
        stopNtripInternal();
        call.resolve();
    }

    private void stopNtripInternal() {
        ntripWanted = false;
        Socket s = ntripSocket;
        ntripSocket = null;
        closeQuietly(s);
        Thread t = ntripThread;
        ntripThread = null;
        if (t != null) t.interrupt();
    }

    /* ================================================================
       État et utilitaires
       ================================================================ */

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject o = new JSObject();
        o.put("bluetooth", btSocket != null ? "connected" : "disconnected");
        o.put("name", btName);
        o.put("address", btAddress);
        o.put("nmeaLines", nmeaLines);
        o.put("ntrip", ntripState);
        o.put("ntripBytes", ntripBytes);
        o.put("rtcmAgeMs", lastRtcmAt > 0 ? System.currentTimeMillis() - lastRtcmAt : -1);
        call.resolve(o);
    }

    private void emitBt(String state, String message) {
        JSObject o = new JSObject();
        o.put("state", state);
        o.put("message", message);
        notifyListeners("bluetooth", o);
    }

    private void emitNtrip(String state, String message) {
        ntripState = state;
        JSObject o = new JSObject();
        o.put("state", state);
        o.put("message", message);
        o.put("bytes", ntripBytes);
        notifyListeners("ntrip", o);
    }

    /** Écran allumé tant que la canne est reliée : un levé ne doit pas s'interrompre en veille. */
    private void keepScreenOn(final boolean on) {
        if (getActivity() == null) return;
        getActivity().runOnUiThread(() -> {
            if (on) getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    private static void closeQuietly(BluetoothSocket s) {
        if (s == null) return;
        try { s.close(); } catch (IOException ignored) { }
    }

    private static void closeQuietly(Socket s) {
        if (s == null) return;
        try { s.close(); } catch (IOException ignored) { }
    }

    @Override
    protected void handleOnDestroy() {
        stopNtripInternal();
        closeBluetooth(false);
        exec.shutdownNow();
    }

    /** Erreur NTRIP qui ne doit pas déclencher de nouvel essai (mauvais réglage). */
    private static final class FatalNtrip extends IOException {
        private static final long serialVersionUID = 1L;
        FatalNtrip(String m) { super(m); }
    }
}
