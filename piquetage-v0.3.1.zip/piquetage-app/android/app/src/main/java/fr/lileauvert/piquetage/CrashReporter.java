package fr.lileauvert.piquetage;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.WebView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Rapport de plantage embarqué : l'application consigne elle-même la cause
 * exacte d'un arrêt, sans PC ni câble.
 *
 * <ul>
 *   <li>toute exception Java non interceptée, y compris au démarrage ;</li>
 *   <li>l'arrêt du moteur d'affichage WebView (signalé par {@link MainActivity}).</li>
 * </ul>
 *
 * Le rapport est enregistré dans la mémoire de l'application et, à partir
 * d'Android 10, copié dans Téléchargements/Piquetage ; il est ensuite affiché
 * par {@link CrashActivity}, qui tourne dans un processus séparé et ne dépend ni
 * de Capacitor ni de la WebView.
 */
final class CrashReporter {

    static final String EXTRA_REPORT = "fr.lileauvert.piquetage.RAPPORT";
    private static final String LAST_FILE = "dernier-plantage.txt";
    private static final String REPORT_PROCESS_SUFFIX = ":rapport";

    private CrashReporter() {}

    /** À appeler depuis Application.attachBaseContext(), avant les fournisseurs de contenu. */
    static void install(final Context app) {
        if (processName().endsWith(REPORT_PROCESS_SUFFIX)) return;   // pas de boucle depuis l'écran de rapport
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                String report = build(app, "Exception Java non interceptée", thread, error);
                save(app, report);
                show(app, report);
            } catch (Throwable secondary) {
                if (previous != null) {
                    previous.uncaughtException(thread, error);
                    return;
                }
            }
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(10);
        });
    }

    /** Ouvre l'écran de rapport (processus séparé). */
    static void show(Context ctx, String report) {
        Intent i = new Intent(ctx, CrashActivity.class);
        i.putExtra(EXTRA_REPORT, report);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        ctx.startActivity(i);
    }

    /** Texte du rapport : contexte de l'appareil puis pile d'appels complète. */
    static String build(Context ctx, String cause, Thread thread, Throwable error) {
        StringBuilder sb = new StringBuilder(4096);
        sb.append("Piquetage — rapport de plantage\n");
        sb.append("Cause       : ").append(cause).append('\n');
        sb.append("Date        : ")
          .append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.FRANCE).format(new Date())).append('\n');
        sb.append("Application : ").append(appVersion(ctx)).append('\n');
        sb.append("Android     : ").append(Build.VERSION.RELEASE)
          .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        sb.append("Appareil    : ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
          .append(" · ").append(Arrays.toString(Build.SUPPORTED_ABIS)).append('\n');
        sb.append("WebView     : ").append(webViewVersion()).append('\n');
        if (thread != null) sb.append("Fil         : ").append(thread.getName()).append('\n');
        sb.append("Mémoire     : ").append(memory(ctx)).append('\n');
        if (error != null) {
            StringWriter sw = new StringWriter();
            error.printStackTrace(new PrintWriter(sw));
            sb.append('\n').append(sw);
        }
        appendExitReasons(ctx, sb);
        appendOwnLog(sb);
        return sb.toString();
    }

    /** Mémoire vive de l'appareil (ActivityManager.MemoryInfo). */
    private static String memory(Context ctx) {
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return "inconnue";
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return (mi.availMem >> 20) + " Mo libres / " + (mi.totalMem >> 20) + " Mo"
            + (mi.lowMemory ? " (MÉMOIRE BASSE)" : "");
    }

    /** Causes des 5 derniers arrêts de l'application enregistrées par Android (API 30+). */
    private static void appendExitReasons(Context ctx, StringBuilder sb) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return;
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) return;
        List<ApplicationExitInfo> list = am.getHistoricalProcessExitReasons(ctx.getPackageName(), 0, 5);
        if (list == null || list.isEmpty()) return;
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.FRANCE);
        sb.append("\n----- Arrêts précédents (Android) -----\n");
        for (ApplicationExitInfo e : list) {
            sb.append(f.format(new Date(e.getTimestamp()))).append("  ").append(e.getProcessName())
              .append("  raison=").append(e.getReason()).append(" statut=").append(e.getStatus())
              .append(" importance=").append(e.getImportance());
            if (e.getDescription() != null) sb.append("  « ").append(e.getDescription()).append(" »");
            sb.append('\n');
        }
    }

    /**
     * 300 dernières lignes du journal Android de ce processus (une application lit
     * son propre journal sans permission). On y trouve les messages de la console
     * JavaScript relayés par Capacitor et ceux de Chromium côté application.
     */
    private static void appendOwnLog(StringBuilder sb) {
        java.lang.Process p = null;
        try {
            p = new ProcessBuilder("logcat", "-d", "-t", "300", "-v", "time",
                "--pid", String.valueOf(android.os.Process.myPid())).redirectErrorStream(true).start();
            sb.append("\n----- Journal de l'application (300 dernières lignes) -----\n");
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                int n = 0;
                while ((line = r.readLine()) != null && n++ < 400) sb.append(line).append('\n');
            }
        } catch (IOException e) {
            sb.append("(journal illisible : ").append(e.getMessage()).append(")\n");
        } finally {
            if (p != null) p.destroy();
        }
    }

    /** Dernier rapport enregistré dans la mémoire de l'application, ou null. */
    static String readLast(Context ctx) {
        File f = new File(ctx.getFilesDir(), LAST_FILE);
        if (!f.exists()) return null;
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[(int) Math.min(f.length(), 1_000_000)];
            int n = 0, r;
            while (n < buf.length && (r = in.read(buf, n, buf.length - n)) > 0) n += r;
            return new String(buf, 0, n, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return null;
        }
    }

    static void save(Context ctx, String report) {
        byte[] data = report.getBytes(StandardCharsets.UTF_8);
        try (OutputStream out = new FileOutputStream(new File(ctx.getFilesDir(), LAST_FILE))) {
            out.write(data);
        } catch (IOException ignored) {
            // la copie publique reste tentée
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.FRANCE).format(new Date());
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, "plantage-" + stamp + ".txt");
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Piquetage");
            ContentResolver cr = ctx.getContentResolver();
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri != null) {
                try (OutputStream out = cr.openOutputStream(uri)) {
                    if (out != null) out.write(data);
                } catch (IOException ignored) {
                    // copie interne déjà faite
                }
            }
        }
    }

    @SuppressWarnings("deprecation")
    private static String appVersion(Context ctx) {
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            long code = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? pi.getLongVersionCode() : pi.versionCode;
            return ctx.getPackageName() + " " + pi.versionName + " (code " + code + ")";
        } catch (PackageManager.NameNotFoundException e) {
            return ctx.getPackageName();
        }
    }

    private static String webViewVersion() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return "non déterminée (Android < 8)";
        PackageInfo wv = WebView.getCurrentWebViewPackage();
        return wv == null ? "AUCUNE WebView active" : wv.packageName + " " + wv.versionName;
    }

    private static String processName() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            String n = android.app.Application.getProcessName();
            return n != null ? n : "";
        }
        try (InputStream in = new FileInputStream("/proc/self/cmdline")) {
            byte[] b = new byte[256];
            int n = in.read(b);
            int end = 0;
            while (end < Math.max(n, 0) && b[end] != 0) end++;
            return new String(b, 0, end, StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }
}
