package fr.lileauvert.piquetage;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Écran de rapport de plantage. Volontairement minimal : Activity du système,
 * interface construite en code, aucune ressource de l'application, aucun
 * Capacitor, aucune WebView — il doit s'afficher même quand tout le reste échoue.
 * Déclaré dans le manifeste avec android:process=":rapport".
 */
public class CrashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String r = getIntent() != null ? getIntent().getStringExtra(CrashReporter.EXTRA_REPORT) : null;
        if (r == null) r = CrashReporter.readLast(this);
        if (r == null) r = "Aucun rapport enregistré.";
        final String report = r;

        int pad = dp(16);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);
        col.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Piquetage s'est arrêté");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.rgb(0x8B, 0x1A, 0x1A));
        col.addView(title);

        TextView info = new TextView(this);
        info.setText("Le détail ci-dessous indique la cause exacte. Touchez « Copier » puis collez-le "
            + "dans la conversation, ou « Partager » pour l'envoyer. Une copie est enregistrée dans "
            + "Téléchargements › Piquetage (Android 10 et suivants).");
        info.setTextSize(15);
        info.setTextColor(Color.rgb(0x22, 0x22, 0x22));
        info.setPadding(0, dp(8), 0, dp(12));
        col.addView(info);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(button("Copier", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Rapport Piquetage", report));
            Toast.makeText(this, "Rapport copié", Toast.LENGTH_SHORT).show();
        }));
        row.addView(button("Partager", v -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, "Piquetage — rapport de plantage");
            send.putExtra(Intent.EXTRA_TEXT, report);
            startActivity(Intent.createChooser(send, "Partager le rapport"));
        }));
        row.addView(button("Relancer", v -> {
            Intent main = new Intent(this, MainActivity.class);
            main.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(main);
            finish();
        }));
        col.addView(row);

        TextView body = new TextView(this);
        body.setText(report);
        body.setTextSize(12);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextColor(Color.BLACK);
        body.setTextIsSelectable(true);
        body.setPadding(0, dp(12), 0, 0);
        col.addView(body);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.WHITE);
        scroll.addView(col, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private Button button(String label, android.view.View.OnClickListener onClick) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(onClick);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
