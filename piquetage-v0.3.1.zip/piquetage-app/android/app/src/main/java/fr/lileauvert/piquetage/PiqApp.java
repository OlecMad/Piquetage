package fr.lileauvert.piquetage;

import android.app.Application;
import android.content.Context;

/**
 * Application : installe le rapport de plantage le plus tôt possible.
 * attachBaseContext() précède l'initialisation des fournisseurs de contenu
 * (FileProvider, androidx.startup) : un plantage à ce stade est aussi consigné.
 */
public class PiqApp extends Application {

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        CrashReporter.install(this);
    }
}
