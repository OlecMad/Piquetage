package fr.lileauvert.piquetage;

import android.os.Build;
import android.os.Bundle;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;

import androidx.activity.OnBackPressedCallback;

import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.WebViewListener;

public class MainActivity extends BridgeActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Les plugins locaux doivent être enregistrés AVANT super.onCreate() :
        // c'est BridgeActivity.onCreate() qui construit le pont (load()).
        registerPlugin(GnssBridgePlugin.class);
        super.onCreate(savedInstanceState);

        // Relevé de terrain : l'écran reste allumé tant que l'application est au premier plan
        // (sinon la mise en veille interrompt le tracé en cours de marche).
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Bouton « retour » : si la page a une entrée d'historique (rapport ouvert),
        // on revient en arrière dans la page ; sinon comportement Android habituel.
        // OnBackPressedDispatcher fonctionne aussi avec le retour prédictif d'Android 16
        // (cible SDK 36), qui n'appelle plus onBackPressed().
        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Bridge b = getBridge();
                WebView wv = b != null ? b.getWebView() : null;
                if (wv != null && wv.canGoBack()) {
                    wv.goBack();
                    return;
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
                setEnabled(true);
            }
        });

        // Arrêt du moteur d'affichage : sans ce relais, Capacitor laisse Android
        // fermer l'application sans aucune trace (onRenderProcessGone → false).
        Bridge bridge = getBridge();
        if (bridge != null) {
            bridge.addWebViewListener(new WebViewListener() {
                @Override
                public boolean onRenderProcessGone(WebView webView, RenderProcessGoneDetail detail) {
                    boolean crashed = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && detail != null && detail.didCrash();
                    String cause = crashed
                        ? "le moteur d'affichage (WebView) a planté"
                        : "le moteur d'affichage (WebView) a été arrêté sans planter (tué par la WebView elle-même, par exemple après un appel à une fonction qu'elle n'implémente pas, ou par Android faute de mémoire)";
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && detail != null) {
                        // 0 = WAIVED, 1 = BOUND, 2 = IMPORTANT (RenderProcessGoneDetail)
                        cause += " — priorité du moteur à l'arrêt : " + detail.rendererPriorityAtExit();
                    }
                    String report = CrashReporter.build(MainActivity.this, cause, null, null);
                    CrashReporter.save(MainActivity.this, report);
                    CrashReporter.show(MainActivity.this, report);
                    finish();
                    return true;
                }
            });
        }
    }
}
