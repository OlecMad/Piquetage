/* Tests de l'export (www/export.js) — exécution : node tools/test-export.js
   Écrit aussi des exemples dans /tmp/piq-export/ pour la relecture indépendante :
     python3 tools/check-dxf.py /tmp/piq-export  (ezdxf) */
const fs = require('fs');
const path = require('path');
const Sess = require('../www/session.js');
const X = require('../www/export.js');

let fails = 0, n = 0;
function ok(c, label, detail) { n++; console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : '')); if (!c) fails++; }

/* ---- session d'exemple : un tracé « sol », un tracé « antenne », un tracé mixte, 3 points ---- */
function sample() {
  const s = Sess.create();
  s.setMeta({ project: 'Berges de la Cisse', place: 'Genillé (Indre-et-Loire)', interval: 0.5 });
  const sp = (x, y, hs, ha, extra) => Object.assign({ x93: x, y93: y, hNgfGround: hs, hNgfAntenna: ha, t: '2026-10-05T10:00:00.000Z' }, extra || {});
  s.startTrack();
  for (let i = 0; i < 6; i++) s.addEpoch(sp(555700 + i, 6677600 + i * 0.5, 50 + i * 0.1, 52 + i * 0.1));
  s.stopTrack();
  s.startTrack();
  for (let i = 0; i < 4; i++) s.addEpoch(sp(555720 + i, 6677610, null, 60 + i * 0.2));
  s.stopTrack();
  s.startTrack();
  s.addEpoch(sp(555730, 6677620, 49, 51)); s.addEpoch(sp(555731, 6677621, null, 52)); s.addEpoch(sp(555732, 6677622, null, null));
  s.stopTrack();
  s.addPoint({ x93: 555700.123, y93: 6677600.456, hNgfGround: 50.123, hNgfAntenna: 52.185, lat: 47.18331234, lon: 1.09401234, hEll: 99.999, qualityLabel: 'RTK FIX', acc: 0.0123, epochs: 5, sats: 20, mountpoint: 'NEAR', receiver: 'RTK_GNSS_4F2A', poleHeight: 2, apcOffset: 0.0615, t: '2026-10-05T10:01:00.000Z' });
  s.addPoint({ x93: 555710, y93: 6677605, hNgfGround: null, hNgfAntenna: 53.5, qualityLabel: 'RTK FIX', t: '2026-10-05T10:02:00.000Z' });
  s.addPoint({ x93: 555715, y93: 6677606, hNgfGround: null, hNgfAntenna: null, t: '2026-10-05T10:03:00.000Z' });
  return s;
}
const NOW = new Date(2026, 9, 5, 14, 7);

console.log('\n── Ensemble et noms de fichiers ──');
const s = sample();
const r = X.build(s.data, { decimal: 'virgule', now: NOW });
ok(r.files.length === 3, 'trois fichiers : points, tracés, DXF');
ok(r.files[0].name === 'Berges_de_la_Cisse_20261005-1407_points.csv' && r.files[1].name === 'Berges_de_la_Cisse_20261005-1407_traces.csv' && r.files[2].name === 'Berges_de_la_Cisse_20261005-1407.dxf', 'noms sans accent ni espace, horodatés', r.files.map((f) => f.name).join(' | '));
ok(X.slug('') === 'piquetage' && X.slug('Été à l’île / 3') === 'Ete_a_l_ile_3', 'nom de projet vide ou accentué');
ok(r.summary.points === 3 && r.summary.tracks === 3 && r.summary.vertices === 6 + 4 + 3, 'résumé : 3 points, 3 tracés, 13 sommets', JSON.stringify(r.summary));
ok(X.build(Sess.create().data, {}).error && X.build({ points: [], tracks: [{ v: [] }] }, {}).error, 'rien à exporter : refusé avec un message');
const onlyPts = Sess.create(); onlyPts.addPoint({ x93: 1, y93: 2, hNgfGround: 3 });
ok(X.build(onlyPts.data, { now: NOW }).files.length === 2, 'sans tracé : pas de fichier de tracés');

console.log('\n── CSV des points ──');
const pts = r.files[0].content;
const rows = pts.replace(/^\uFEFF/, '').split('\r\n').filter(Boolean);
ok(pts.startsWith('\uFEFF') && pts.endsWith('\r\n'), 'UTF-8 avec BOM, fins de ligne CRLF (Excel)');
ok(rows.length === 4 && rows[0].split(';').length === 19 && rows.every((l) => l.split(';').length === 19 || l.includes('"')), 'en-tête et 3 lignes de 19 colonnes');
const c1 = rows[1].split(';');
ok(c1[2] === 'P1' && c1[4] === '555700,123' && c1[5] === '6677600,456' && c1[6] === '50,123' && c1[7] === 'sol', 'P1 : X, Y, H sol, virgule décimale', c1.slice(2, 8).join(' | '));
ok(c1[8] === '99,999' && c1[9] === '2,000' && c1[10] === '0,0615' && c1[12] === '0,012' && c1[13] === '5' && c1[14] === '20', 'h ellipsoïdale, canne, centre de phase, précision, époques, satellites');
ok(c1[15] === 'NEAR' && c1[16] === 'RTK_GNSS_4F2A' && c1[17] === '47,183312340' && c1[18] === '1,094012340', 'point de montage, récepteur, latitude et longitude');
const c2 = rows[2].split(';');
ok(c2[6] === '53,500' && c2[7] === 'antenne' && c2[9] === '' && c2[10] === '', 'P2 : altitude d’antenne signalée, hauteurs absentes laissées vides');
const c3 = rows[3].split(';');
ok(c3[6] === '' && c3[7] === '', 'P3 : sans altitude → colonne vide, jamais 0');
ok(rows[1].split(';')[1] === '"Genillé (Indre-et-Loire)"' || rows[1].split(';')[1] === 'Genillé (Indre-et-Loire)', 'lieu accentué conservé (UTF-8)');

const rp = X.build(s.data, { decimal: 'point', now: NOW }).files[0].content.split('\r\n')[1].split(';');
ok(rp[4] === '555700.123' && rp[6] === '50.123' && rp[17] === '47.183312340', 'décimale « point » (QGIS)');

const rd = X.build(s.data, { now: NOW }).files[0].content.split('\r\n')[1].split(';');
ok(rd[4] === '555700.123' && rd[17] === '47.183312340', 'sans réglage : décimale « point » par défaut');

console.log('\n── CSV : protections ──');
{
  const t = Sess.create(); t.setMeta({ project: '=SOMME(A1)', place: 'a;b "c"' });
  t.addPoint({ x93: 1, y93: 2, hNgfGround: 3 });
  const l = X.csvPoints({ project: t.data.project, place: t.data.place, points: t.data.points }, 'point').replace(/^\uFEFF/, '').split('\r\n')[1];
  ok(l.startsWith("'=SOMME(A1);") , 'formule de tableur neutralisée (apostrophe)');
  ok(l.includes('"a;b ""c"""'), 'point-virgule et guillemets échappés', l.split(';').slice(0, 3).join(' | '));
}

console.log('\n── CSV des tracés ──');
const trk = r.files[1].content.replace(/^\uFEFF/, '').split('\r\n').filter(Boolean);
ok(trk.length === 1 + 13 && trk[0].split(';').length === 10, 'un sommet par ligne : 13 + en-tête');
const t1 = trk[1].split(';'), t6 = trk[6].split(';');
ok(t1[2] === 'T1' && t1[3] === '1' && t1[9] === '0,000', 'premier sommet : distance cumulée 0');
const exp = Math.hypot(5, 2.5);
ok(t6[3] === '6' && Math.abs(parseFloat(t6[9].replace(',', '.')) - exp) < 1e-3 && t6[7] === '50,500' && t6[8] === 'sol', 'sixième sommet : distance cumulée sur le plan et altitude', t6[9] + ' m');
ok(trk[13].split(';')[7] === '' && trk[13].split(';')[8] === '' && trk[11].split(';')[7] === '49,000', 'dernier sommet sans altitude : colonne vide ; le premier du même tracé garde la sienne');

console.log('\n── DXF ──');
const dxf = r.files[2].content;
const codes = dxf.split('\r\n');
ok(codes.length % 2 === 1 && codes[codes.length - 2] === 'EOF' && codes[codes.length - 3] === '0', 'structure code/valeur et fin « EOF »');
ok(/\r\n9\r\n\$ACADVER\r\n1\r\nAC1009\r\n/.test(dxf), 'DXF R12 (AC1009), lisible par tous les logiciels');
ok(!/[^\x00-\x7f]/.test(dxf), 'ASCII pur (aucun accent dans le fichier)');
const count = (re) => (dxf.match(re) || []).length;
ok(count(/\r\n0\r\nPOINT\r\n/g) === 3 && count(/\r\n0\r\nCIRCLE\r\n/g) === 3 && /\r\n0\r\nCIRCLE\r\n8\r\nPIQ_PT_SOL\r\n10\r\n555700\.123\r\n20\r\n6677600\.456\r\n30\r\n50\.123\r\n40\r\n0\.150\r\n/.test(dxf), '3 POINT, chacun entouré d’un CIRCLE de 0,15 m (visible dans tous les logiciels)');
ok(count(/\r\n0\r\nPOLYLINE\r\n/g) === 3 && count(/\r\n0\r\nSEQEND\r\n/g) === 3 && count(/\r\n0\r\nVERTEX\r\n/g) === 13, '3 POLYLINE, 13 VERTEX, 3 SEQEND');
ok(/8\r\nPIQ_PT_SOL\r\n10\r\n555700\.123\r\n20\r\n6677600\.456\r\n30\r\n50\.123\r\n/.test(dxf), 'P1 : calque SOL, X Y Z en point décimal (3 décimales)');
ok(/8\r\nPIQ_PT_ANTENNE\r\n10\r\n555710\.000\r\n20\r\n6677605\.000\r\n30\r\n53\.500\r\n/.test(dxf), 'P2 : calque ANTENNE');
ok(/8\r\nPIQ_PT_SANS_Z\r\n10\r\n555715\.000\r\n20\r\n6677606\.000\r\n30\r\n0\.000\r\n/.test(dxf), 'P3 : calque SANS_Z (Z = 0 imposé par le format)');
ok(count(/1\r\nP[123]\r\n/g) === 3 && /1\r\n50\.12\r\n/.test(dxf) && /1\r\n53\.50\r\n/.test(dxf) && !/1\r\n0\.00\r\n/.test(dxf), 'numéros P1–P3 et altitudes inscrites ; aucune altitude « 0.00 » inventée');
ok(/8\r\nPIQ_TRACE_SOL\r\n66\r\n1\r\n[\s\S]*?70\r\n8\r\n/.test(dxf) && /8\r\nPIQ_TRACE_ANTENNE\r\n66\r\n1\r\n[\s\S]*?70\r\n8\r\n/.test(dxf), 'tracés « sol » et « antenne » en polylignes 3D');
ok(/8\r\nPIQ_TRACE_2D\r\n66\r\n1\r\n10\r\n0\.0\r\n20\r\n0\.0\r\n30\r\n0\.0\r\n70\r\n0\r\n/.test(dxf), 'tracé aux altitudes mixtes ou absentes : polyligne 2D');
ok(/PIQUETAGE - Berges de la Cisse - Genille \(Indre-et-Loire\)/.test(dxf) && /EPSG:2154/.test(dxf) && /NGF-IGN69/.test(dxf), 'cartouche : projet, lieu sans accent, EPSG:2154, NGF-IGN69');
ok(X.trackKind({ v: [{ h: 1, k: 'S' }, { h: 2, k: 'S' }] }) === 'SOL' && X.trackKind({ v: [{ h: 1, k: 'S' }, { h: 2, k: 'A' }] }) === '2D' && X.trackKind({ v: [{ h: null, k: null }] }) === '2D', 'nature du tracé : sol, antenne, ou 2D');

console.log('\n── DXF en repère local ──');
{
  const rl = X.build(s.data, { now: NOW, origin: 'local' });
  const f = rl.files.find((x) => x.name.endsWith('.dxf'));
  ok(f.name === 'Berges_de_la_Cisse_20261005-1407_local.dxf' && rl.summary.origin === 'local', 'nom de fichier avec le suffixe « _local »');
  const dl = f.content;
  ok(/8\r\nPIQ_PT_SOL\r\n10\r\n0\.123\r\n20\r\n0\.456\r\n30\r\n50\.123\r\n/.test(dl), 'P1 en repère local : X = 0,123 ; Y = 0,456 ; Z inchangé');
  ok(/REPERE LOCAL : X Lambert-93 = X dessin \+ 555700 ; Y Lambert-93 = Y dessin \+ 6677600/.test(dl), 'décalage inscrit au cartouche');
  ok(!/\r\n10\r\n55\d{4}\./.test(dl.split('ENTITIES')[1]), 'aucune coordonnée Lambert-93 absolue dans les entités');
  ok(rl.files.filter((x) => x.name.endsWith('.csv')).every((x) => /5557\d\d[.,]\d{3}/.test(x.content)), 'les CSV restent en Lambert-93 absolu');
  ok(!X.build(s.data, { now: NOW }).files.find((x) => x.name.endsWith('.dxf')).name.includes('_local'), 'repère absolu : pas de suffixe');
  fs.mkdirSync('/tmp/piq-export', { recursive: true });
  fs.writeFileSync('/tmp/piq-export/' + f.name, f.content, 'utf8');
}

console.log('\n── Avertissements ──');
ok(r.warnings.length === 4 && r.warnings[0].includes('altitude d’antenne') && r.warnings[1].includes('sans altitude') && r.warnings.join(' ').includes('tracé aux altitudes de natures différentes'), 'avertissements : antenne, points et sommets sans altitude, tracé mixte', r.warnings.length + ' lignes');
const clean = Sess.create(); clean.startTrack(); clean.addEpoch({ x93: 1, y93: 1, hNgfGround: 5, hNgfAntenna: 7 }); clean.addEpoch({ x93: 3, y93: 1, hNgfGround: 5, hNgfAntenna: 7 });
clean.addPoint({ x93: 1, y93: 1, hNgfGround: 5, hNgfAntenna: 7, poleHeight: 2, apcOffset: 0 });
ok(X.build(clean.data, { now: NOW }).warnings.length === 0, 'données complètes : aucun avertissement');

console.log('\n── Valeurs sensibles ──');
{
  const e = Sess.create(); e.startTrack(); e.addEpoch({ x93: 555000.0005, y93: 6600000.0004, hNgfGround: 12.0005, hNgfAntenna: 14 });
  e.addEpoch({ x93: 555002, y93: 6600000, hNgfGround: 12, hNgfAntenna: 14 });
  const d = X.build(e.data, { now: NOW, decimal: 'point' }).files[0].content;
  ok(/;55500[0]\.00[01];66000{2}0\.00[01];12\.00[01];sol;/.test(d), 'arrondi au millimètre (3 décimales exactement)', d.split('\r\n')[1]);
  ok(!/e[+-]\d/i.test(d), 'aucune notation scientifique');
}

fs.mkdirSync('/tmp/piq-export', { recursive: true });
X.build(s.data, { now: NOW }).files.forEach((f) => fs.writeFileSync(path.join('/tmp/piq-export', f.name), f.content, 'utf8'));   // réglages par défaut : décimale point
ok(true, 'exemples (réglages par défaut) écrits dans /tmp/piq-export/');

console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
process.exit(fails ? 1 : 0);
