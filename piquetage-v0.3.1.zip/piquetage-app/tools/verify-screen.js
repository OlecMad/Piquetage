/* Vérification de l'écran principal (www/index.html) dans Chromium, avec un faux pont
   Capacitor et une marche simulée : exécution  node tools/verify-screen.js
   Ne remplace pas l'essai avec la vraie canne sur le Fairphone et la tablette. */
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');
const G = require('../www/geo.js');
eval(fs.readFileSync(path.join(__dirname, '../www/raf20.js'), 'utf8').replace('window.RAF20', 'globalThis.RAF20'));
G.loadGeoid(globalThis.RAF20);

const LAT = 47.1833, LON = 1.0940, H_ELL = 100.000, SEP = 47.000;
let fails = 0, n = 0;
function ok(c, label, detail) { n++; console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : '')); if (!c) fails++; }

const root = path.join(__dirname, '../www');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.woff2': 'font/woff2', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const f = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/^\/$/, '/index.html'));
  if (!f.startsWith(root) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});

const FAKE = () => {
  window.__calls = { connect: [], startNtrip: [], stopNtrip: 0, disconnect: 0 };
  window.__listeners = {};
  window.__emit = (evt, data) => (window.__listeners[evt] || []).forEach((cb) => cb(data));
  window.Capacitor = {
    isNativePlatform: () => true, getPlatform: () => 'android',
    isPluginAvailable: (nm) => ['GnssBridge', 'Filesystem', 'Share'].indexOf(nm) !== -1,
    Plugins: {
      Filesystem: {
        writeFile: (o) => { (window.__writes = window.__writes || []).push(o); return window.__failWrite ? Promise.reject(new Error('disque plein')) : Promise.resolve({ uri: 'file:///x' }); },
        getUri: (o) => Promise.resolve({ uri: 'file:///storage/emulated/0/Documents/' + o.path }),
      },
      Share: { share: (o) => { (window.__shares = window.__shares || []).push(o); return Promise.resolve(); } },
      GnssBridge: {
      addListener: (evt, cb) => { (window.__listeners[evt] = window.__listeners[evt] || []).push(cb); return Promise.resolve({ remove: () => Promise.resolve() }); },
      listDevices: () => Promise.resolve({ devices: [{ name: 'RTK_GNSS_4F2A', address: '00:11:22:33:44:55', type: 1 }] }),
      connect: (o) => { window.__calls.connect.push(o); return Promise.resolve({ address: o.address }); },
      disconnect: () => { window.__calls.disconnect++; return Promise.resolve(); },
      startNtrip: (o) => { window.__calls.startNtrip.push(o); return Promise.resolve(); },
      stopNtrip: () => { window.__calls.stopNtrip++; return Promise.resolve(); },
    } }
  };
  let tick = 0;
  window.__nmea = function (lat, lon, hEll, sep, q) {
    function cs(b) { let c = 0; for (const ch of b) c ^= ch.charCodeAt(0); return '$' + b + '*' + c.toString(16).toUpperCase().padStart(2, '0'); }
    function dm(v, w) { const d = Math.floor(Math.abs(v)); const m = (Math.abs(v) - d) * 60; return String(d).padStart(w, '0') + m.toFixed(7).padStart(10, '0'); }
    tick++;
    const time = '12' + String(Math.floor(tick / 60) % 60).padStart(2, '0') + String(tick % 60).padStart(2, '0') + '.00';
    window.__emit('nmea', { line: cs('GNGGA,' + time + ',' + dm(lat, 2) + ',N,' + dm(lon, 3) + ',E,' + q + ',20,0.50,' + (hEll - sep).toFixed(4) + ',M,' + sep.toFixed(4) + ',M,1.0,0412') });
    window.__emit('nmea', { line: cs('GNGST,' + time + ',0.012,0.010,0.008,45.0,0.009,0.008,0.015') });
  };
};

(async () => {
  await new Promise((r) => server.listen(0, r));
  const BASE = 'http://localhost:' + server.address().port;
  const errors = [];
  async function open(viewport, withPlugin, keep) {
    const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--single-process'] });
    const ctx = await browser.newContext({ viewport, deviceScaleFactor: 2, locale: 'fr-FR', timezoneId: 'Europe/Paris' });
    const page = await ctx.newPage();
    page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    if (withPlugin) await page.addInitScript(FAKE);
    await page.goto(BASE + '/index.html', { waitUntil: 'domcontentloaded' });
    if (!keep) await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(400);
    return { browser, page };
  }
  const text = (page, sel) => page.locator(sel).innerText();
  // pixels « encre » d'un canvas (non transparents) : le tracé est-il vraiment dessiné ?
  const ink = (page, sel) => page.evaluate((s) => {
    const c = document.querySelector(s), x = c.getContext('2d');
    const d = x.getImageData(0, 0, c.width, c.height).data; let k = 0;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 40) k++;
    return k;
  }, sel);
  const nmea = (page, lat, lon, h, q) => page.evaluate(([a, b, c, d, e]) => window.__nmea(a, b, c, d, e), [lat, lon, h, SEP, q]);
  const overflow = (page) => page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1 || document.documentElement.scrollHeight > window.innerHeight + 1);

  /* ======================= Fairphone, portrait ======================= */
  console.log('\n── Fairphone (360 × 780) ──');
  const A = await open({ width: 360, height: 780 }, true);
  let page = A.page;
  ok(await page.locator('#banner').isVisible() && await page.locator('#cv-track').isVisible() && await page.locator('#cv-prof').isVisible() && await page.locator('#bar').isVisible(), 'bandeau, tracé, profil et barre d’actions visibles');
  ok(!(await overflow(page)), 'aucun défilement ni débordement sur 360 × 780');
  ok((await text(page, '#m-project')) === 'Projet sans nom' && (await text(page, '#m-place')) === 'Lieu à renseigner', 'bandeau : projet et lieu à renseigner');
  ok(/^\d{2}:\d{2}$/.test(await text(page, '#m-time')) && (await text(page, '#m-date')).length > 6, 'bandeau : heure et date', (await text(page, '#m-time')) + ' · ' + (await text(page, '#m-date')));
  ok((await text(page, '#m-pill')) === 'Non reliée' && await page.locator('#b-point').isDisabled(), '« Point » inactif tant que la canne n’est pas reliée');
  ok(await page.locator('#b-impl').isDisabled(), '« Impl. » inactif (étape 5)');
  ok((await text(page, '#cv-track').catch(() => '')) === '' && (await ink(page, '#cv-track')) > 100, 'tracé vide : message « Aucune position » dessiné');

  // projet et lieu
  await page.locator('#banner').click();
  ok(await page.locator('#sheet-proj').isVisible(), 'toucher le bandeau ouvre le panneau Projet');
  await page.fill('#p-name', 'Berges de la Cisse'); await page.fill('#p-place', 'Genillé');
  await page.locator('#close-proj').click(); await page.waitForTimeout(150);
  ok(await page.locator('#sheet-proj').isHidden() && (await text(page, '#m-project')) === 'Berges de la Cisse' && (await text(page, '#m-place')) === 'Genillé', 'nom et lieu affichés dans le bandeau');
  await page.locator('#b-proj').click(); await page.goBack(); await page.waitForTimeout(150);
  ok(await page.locator('#sheet-proj').isHidden(), 'le bouton « retour » d’Android ferme le panneau');

  // canne : hauteurs puis connexion
  await page.locator('#b-link').click();
  await page.fill('#pole', '2,000'); await page.fill('#apc', '0,0615');
  await page.locator('#connect').click(); await page.waitForTimeout(250);
  ok((await text(page, '#connect')) === 'Déconnecter', 'connexion depuis le panneau Canne');
  await page.locator('#close-link').click();
  const calls = await page.evaluate(() => window.__calls);
  ok(calls.connect[0].address === '00:11:22:33:44:55' && calls.startNtrip[0].host === 'crtk.net', 'canne RTK_GNSS_* connectée, NTRIP Centipede lancé');

  await nmea(page, LAT, LON, H_ELL, 4); await page.waitForTimeout(200);
  const exp = G.toLambert93(LAT, LON), N = G.geoidN(LAT, LON), hSol = H_ELL - N - 2 - 0.0615;
  const fr = (v, d) => v.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d }).replace(/[\u202f\u00a0]/g, ' ');
  ok((await text(page, '#m-pill')) === 'RTK FIX' && await page.locator('#b-point').isEnabled(), 'RTK FIX affiché, « Point » actif');
  ok((await text(page, '#big-value')) === fr(hSol, 2) + ' m', 'altitude NGF du sol en gros chiffres', await text(page, '#big-value'));
  ok((await text(page, '#big-label')).includes('sol'), 'libellé « altitude sol »');
  ok((await text(page, '#m-xy')).includes('X ' + fr(exp.x, 2)) && (await text(page, '#m-xy')).includes('Y ' + fr(exp.y, 2)), 'X, Y Lambert-93 en direct sous l’instrument', await text(page, '#m-xy'));
  ok((await text(page, '#m-acc')).includes('±1,2 cm H') && (await text(page, '#m-acc')).includes('20 sat.'), 'précisions horizontale et verticale, satellites', await text(page, '#m-acc'));

  // marche simulée : 24 pas vers le nord-est, ~1,3 m chacun, montée de 0,15 m/pas
  await page.locator('#b-track').click();
  ok((await text(page, '#b-track')) === 'Arrêter' && (await page.getAttribute('#b-track', 'aria-pressed')) === 'true', 'tracé démarré : bouton « Arrêter »');
  const pts = [];
  for (let i = 0; i < 24; i++) {
    const lat = LAT + i * 0.0000085, lon = LON + i * 0.0000085;
    pts.push([lat, lon, H_ELL + i * 0.15]);
    await nmea(page, lat, lon, H_ELL + i * 0.15, 4);
    await page.waitForTimeout(30);
  }
  await page.waitForTimeout(350);
  let length = 0;
  for (let i = 1; i < pts.length; i++) {
    const a = G.toLambert93(pts[i - 1][0], pts[i - 1][1]), b = G.toLambert93(pts[i][0], pts[i][1]);
    length += Math.hypot(b.x - a.x, b.y - a.y);
  }
  const sess = await page.evaluate(() => window.PIQUETAGE.session.stats());
  ok(sess.vertices >= 20 && sess.vertices <= 24, 'sommets enregistrés pendant la marche (intervalle 1 m)', sess.vertices + ' sommets');
  ok(Math.abs(sess.length - length) < 1.5, 'longueur du tracé = distance parcourue sur le plan', sess.length.toFixed(2) + ' m / ' + length.toFixed(2) + ' m');
  ok(Math.abs(sess.up - 23 * 0.15) < 0.4 && sess.down < 0.05, 'dénivelé positif mesuré', 'D+ ' + sess.up.toFixed(2) + ' m');
  ok((await ink(page, '#cv-track')) > 800, 'tracé dessiné');
  ok((await ink(page, '#cv-prof')) > 400, 'profil dessiné au fil de la marche');
  ok((await text(page, '#tr-info')).includes('Tracé en cours') && (await text(page, '#pr-info')).includes('D+'), 'cartouches : longueur, sommets, D+ / D−', (await text(page, '#tr-info')) + ' | ' + (await text(page, '#pr-info')));

  // cap de marche
  await page.locator('#tab-cap').click();
  const dx = G.toLambert93(pts[23][0], pts[23][1]).x - G.toLambert93(pts[0][0], pts[0][1]).x, dy = G.toLambert93(pts[23][0], pts[23][1]).y - G.toLambert93(pts[0][0], pts[0][1]).y;
  const hd = (Math.atan2(dx, dy) * 180 / Math.PI + 360) % 360;
  const hv = await text(page, '#big-value');
  ok(/^\d{3}° (N|NE|E|SE|S|SO|O|NO)$/.test(hv) && Math.abs(parseInt(hv, 10) - hd) < 6, 'cap de marche vers le nord-est (nord du plan)', hv + ' (attendu ≈ ' + hd.toFixed(0) + '°)');
  ok((await text(page, '#big-sub')).includes('pas le nord géographique'), 'mention : nord du plan, pas le nord géographique');

  // point levé
  await page.locator('#b-link').click(); await page.selectOption('#avg', '1'); await page.locator('#close-link').click();
  await nmea(page, pts[23][0], pts[23][1], pts[23][2], 4);          // trame fraîche (moins de 3 s) avant le levé
  await page.locator('#b-point').click(); await page.waitForTimeout(1000);
  await page.locator('#tab-pts').click();
  ok((await text(page, '#big-value')) === '1' && (await text(page, '#big-sub')).startsWith('P1 · X'), 'point P1 levé et compté', await text(page, '#big-sub'));
  ok((await text(page, '#m-msg')).includes('P1 enregistré'), 'message « P1 enregistré »');

  // qualité dégradée : sommets ignorés quand le FIX est exigé
  const before = (await page.evaluate(() => window.PIQUETAGE.session.stats())).vertices;
  for (let i = 0; i < 6; i++) { await nmea(page, LAT + 0.001 + i * 0.00002, LON, H_ELL, 5); await page.waitForTimeout(20); }
  await page.waitForTimeout(250);
  ok((await text(page, '#m-pill')) === 'RTK FLOAT', 'RTK FLOAT signalé');
  ok((await page.evaluate(() => window.PIQUETAGE.session.stats())).vertices === before, 'aucun sommet enregistré en FLOAT (FIX exigé)');

  // arrêt du tracé puis redémarrage de l'application
  await page.locator('#b-track').click();
  ok((await text(page, '#b-track')) === 'Tracé', 'tracé arrêté');
  await page.waitForTimeout(1300);
  await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForTimeout(400);
  const back = await page.evaluate(() => window.PIQUETAGE.session.stats());
  ok(back.vertices === sess.vertices || back.vertices === before, 'tracé relu après redémarrage', back.vertices + ' sommets');
  ok((await text(page, '#m-project')) === 'Berges de la Cisse' && back.points === 1, 'projet et point relus après redémarrage');
  ok((await ink(page, '#cv-track')) > 800, 'tracé redessiné après redémarrage');

  // affichage : points seuls
  await page.locator('#b-proj').click(); await page.selectOption('#p-display', 'points'); await page.locator('#close-proj').click(); await page.waitForTimeout(250);
  const inkDots = await ink(page, '#cv-track');
  await page.locator('#b-proj').click(); await page.selectOption('#p-display', 'les deux'); await page.locator('#close-proj').click(); await page.waitForTimeout(250);
  ok(inkDots > 100 && (await ink(page, '#cv-track')) > inkDots, 'affichage « points » puis « tracé et points » (plus d’encre)');

  // export CSV + DXF
  await page.locator('#b-proj').click();
  ok(await page.inputValue('#p-decimal') === 'point', 'décimale des CSV : point par défaut');
  await page.locator('#p-export').click(); await page.waitForTimeout(500);
  const writes = await page.evaluate(() => window.__writes || []);
  const shares = await page.evaluate(() => window.__shares || []);
  ok(writes.length === 3 && writes.every((w) => w.directory === 'DOCUMENTS' && w.encoding === 'utf8' && w.recursive === true && w.path.startsWith('Piquetage/')), 'trois fichiers écrits dans Documents › Piquetage', writes.map((w) => w.path).join(' | '));
  const names = writes.map((w) => w.path.replace('Piquetage/', ''));
  ok(names.some((m) => /^Berges_de_la_Cisse_\d{8}-\d{4}_points\.csv$/.test(m)) && names.some((m) => /_traces\.csv$/.test(m)) && names.some((m) => /\.dxf$/.test(m)), 'noms : projet, horodatage, points / traces / dxf');
  const wp = writes.find((w) => w.path.endsWith('_points.csv'));
  ok(wp.data.startsWith('\uFEFF') && wp.data.includes('P1;') && wp.data.includes('555 '.trim()) && /;5556\d\d\.\d{3};66776\d\d\.\d{3};/.test(wp.data), 'CSV des points : BOM, P1, X et Y avec point décimal (réglage par défaut)');
  const wd = writes.find((w) => w.path.endsWith('.dxf'));
  ok(wd.data.includes('AC1009') && (wd.data.match(/\r\nPOLYLINE\r\n/g) || []).length === 1 && (wd.data.match(/\r\nVERTEX\r\n/g) || []).length === back.vertices, 'DXF : une polyligne, un VERTEX par sommet du tracé', back.vertices + ' sommets');
  ok(shares.length === 1 && shares[0].files.length === 3 && shares[0].files.every((u) => u.startsWith('file:///storage/emulated/0/Documents/Piquetage/')), 'partage Android avec les trois fichiers (URI file://)');
  const out = await text(page, '#p-export-out');
  ok(out.includes('3 fichiers enregistrés') && out.includes('.dxf'), 'panneau : fichiers listés', out.split('\n')[0]);
  ok(out.includes('À vérifier') === false, 'données complètes (altitude du sol) : aucun avertissement');
  await page.selectOption('#p-decimal', 'virgule'); await page.locator('#p-export').click(); await page.waitForTimeout(500);
  const wp2 = (await page.evaluate(() => window.__writes)).slice(3).find((w) => w.path.endsWith('_points.csv'));
  ok(wp2 && /;5556\d\d,\d{3};/.test(wp2.data), 'décimale « virgule » prise en compte au second export');
  ok(await page.inputValue('#p-decimal') === 'virgule' && await page.inputValue('#p-origin') === 'l93', 'repère du DXF : Lambert-93 absolu par défaut');
  await page.selectOption('#p-origin', 'local'); await page.locator('#p-export').click(); await page.waitForTimeout(500);
  const wl = (await page.evaluate(() => window.__writes)).slice(6);
  const wdl = wl.find((w) => w.path.endsWith('.dxf'));
  ok(wl.length === 3 && wdl.path.endsWith('_local.dxf') && wdl.data.includes('REPERE LOCAL'), 'repère local : fichier « _local.dxf » et décalage au cartouche', wdl.path.replace('Piquetage/', ''));
  ok(!/\r\n10\r\n55\d{4}\./.test(wdl.data.split('ENTITIES')[1]), 'aucune coordonnée Lambert-93 absolue dans le DXF local');
  ok((wl.find((w) => w.path.endsWith('_points.csv')).data.match(/;5556\d\d,\d{3};/) || []).length === 1, 'les CSV restent en Lambert-93 absolu');
  await page.selectOption('#p-origin', 'l93');
  await page.evaluate(() => { window.__failWrite = true; });
  await page.locator('#p-export').click(); await page.waitForTimeout(400);
  ok((await text(page, '#p-export-out')).startsWith('Export impossible : disque plein') && await page.locator('#p-export').isEnabled(), 'échec d’écriture signalé, bouton de nouveau actif');
  await page.evaluate(() => { window.__failWrite = false; });

  // annuler le dernier point (deux temps)
  await page.locator('#p-undo').click();
  ok((await text(page, '#p-undo')).startsWith('Confirmer') && (await page.evaluate(() => window.PIQUETAGE.session.stats())).points === 1, 'annulation armée, rien de retiré au premier appui');
  await page.locator('#p-undo').click();
  ok((await page.evaluate(() => window.PIQUETAGE.session.stats())).points === 0, 'second appui : dernier point retiré');
  await page.locator('#p-export').click(); await page.waitForTimeout(400);
  const w3 = (await page.evaluate(() => window.__writes)).slice(10);   // 3 + 3 + 3 écrits, +1 tentative échouée (disque plein)
  ok(w3.length === 2 && w3.some((w) => w.path.endsWith('_traces.csv')) && w3.some((w) => w.path.endsWith('.dxf')) && !w3.some((w) => w.path.endsWith('_points.csv')), 'tracé seul : deux fichiers (traces.csv et dxf), pas de CSV de points');
  await page.locator('#p-clear').click(); await page.locator('#p-clear').click();
  await page.locator('#p-export').click(); await page.waitForTimeout(300);
  ok((await text(page, '#p-export-out')).startsWith('Rien à exporter'), 'session vide : « Rien à exporter »');
  await page.locator('#close-proj').click();
  await page.evaluate(() => { const s = window.PIQUETAGE.session; s.addPoint({ x93: 555700, y93: 6677600, hNgfGround: 50, hNgfAntenna: 52, t: 'T' }); });

  // effacement en deux temps
  await page.evaluate(() => { const s = window.PIQUETAGE.session; s.startTrack(); s.addEpoch({ x93: 1, y93: 1, hNgfGround: 5 }); s.addEpoch({ x93: 5, y93: 1, hNgfGround: 5 }); s.stopTrack(); });
  await page.locator('#b-proj').click();
  await page.locator('#p-clear').click();
  ok((await text(page, '#p-clear')).startsWith('Confirmer') && (await page.evaluate(() => window.PIQUETAGE.session.stats())).vertices > 0, 'effacement armé, rien d’effacé au premier appui');
  await page.locator('#p-clear').click();
  const afterClear = await page.evaluate(() => window.PIQUETAGE.session.stats());
  ok(afterClear.vertices === 0 && afterClear.points === 1, 'second appui : tracés effacés, points conservés');
  await page.locator('#p-new').click(); await page.locator('#p-new').click();
  ok((await page.evaluate(() => window.PIQUETAGE.session.stats())).points === 0 && (await page.inputValue('#p-name')) === '', 'nouveau projet : tout est remis à zéro');
  await A.browser.close();

  /* ======================= Tablette, portrait puis paysage ======================= */
  console.log('\n── Tablette (800 × 1280, portrait) ──');
  const B = await open({ width: 800, height: 1280 }, true);
  ok(!(await overflow(B.page)), 'aucun débordement en portrait');
  ok(await B.page.locator('#cv-track').isVisible() && await B.page.locator('#cv-prof').isVisible(), 'tracé et profil visibles');
  await B.browser.close();

  console.log('\n── Tablette (1280 × 800, paysage) ──');
  const C = await open({ width: 1280, height: 800 }, true);
  ok(!(await overflow(C.page)), 'aucun débordement en paysage');
  const boxes = await C.page.evaluate(() => ['#instr', '#views', '#bar'].map((s) => { const r = document.querySelector(s).getBoundingClientRect(); return { l: r.left, r: r.right, t: r.top, b: r.bottom }; }));
  ok(boxes[1].l >= boxes[0].r - 1 && boxes[2].r <= boxes[1].l + 1, 'instruments et barre à gauche, tracé et profil à droite');
  await C.browser.close();

  console.log('\n── Navigateur sans plugin ──');
  const D = await open({ width: 360, height: 780 }, false);
  ok((await text(D.page, '#m-pill')) === 'Non reliée' && await D.page.locator('#b-point').isDisabled(), 'lecture seule : « Point » inactif');
  await D.page.locator('#b-link').click();
  ok(await D.page.locator('#noplugin').isVisible() && await D.page.locator('#connect').isDisabled(), 'panneau Canne : avertissement et connexion désactivée');
  await D.page.locator('#close-link').click();
  await D.page.evaluate(() => window.PIQUETAGE.session.addPoint({ x93: 555700, y93: 6677600, hNgfGround: 50, hNgfAntenna: 52, t: 'T' }));
  await D.page.locator('#b-proj').click();
  const dl = D.page.waitForEvent('download', { timeout: 4000 }).catch(() => null);
  await D.page.locator('#p-export').click();
  const got = await dl;
  ok(got && /_points\.csv$/.test(got.suggestedFilename()), 'navigateur : les fichiers sont téléchargés', got && got.suggestedFilename());
  ok((await text(D.page, '#p-export-out')).includes('3 fichiers téléchargés') || (await text(D.page, '#p-export-out')).includes('2 fichiers téléchargés'), 'navigateur : liste des fichiers affichée');
  await D.browser.close();

  ok(errors.length === 0, 'aucune erreur JavaScript', errors.join(' || '));
  server.close();
  console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
