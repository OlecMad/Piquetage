package com.getcapacitor;
import org.json.JSONObject;
/** Signatures relevées dans @capacitor/android 8.5.2 (JSObject.java l.115-154). */
public class JSObject extends JSONObject {
  public JSObject() { super(); }
  @Override public JSObject put(String key, boolean value) { return this; }
  @Override public JSObject put(String key, int value) { return this; }
  @Override public JSObject put(String key, long value) { return this; }
  @Override public JSObject put(String key, double value) { return this; }
  @Override public JSObject put(String key, Object value) { return this; }
  public JSObject put(String key, String value) { return this; }
}
