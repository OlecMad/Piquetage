package com.getcapacitor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
/** @capacitor/android 8.5.2, BridgeActivity.java l.11-62. */
public class BridgeActivity extends AppCompatActivity {
  @Override protected void onCreate(Bundle savedInstanceState) {}
  public void registerPlugin(Class<? extends Plugin> plugin) {}
  public Bridge getBridge() { return null; }
}
