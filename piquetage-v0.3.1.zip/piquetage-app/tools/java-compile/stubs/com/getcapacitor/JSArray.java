package com.getcapacitor;
import org.json.JSONArray;
/** @capacitor/android 8.5.2 : public class JSArray extends JSONArray (put hérité de JSONArray). */
public class JSArray extends JSONArray { public JSArray() { super(); } }
