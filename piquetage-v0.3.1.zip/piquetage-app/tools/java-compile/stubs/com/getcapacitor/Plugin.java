package com.getcapacitor;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
/** Signatures de @capacitor/android 8.5.2, Plugin.java l.96-1004. */
public class Plugin {
  public void load() {}
  public Context getContext() { return null; }
  public AppCompatActivity getActivity() { return null; }
  public Bridge getBridge() { return null; }   // Plugin.java l.223
  protected void requestPermissionForAlias(String alias, PluginCall call, String callbackName) {}
  public PermissionState getPermissionState(String alias) { return null; }
  protected void notifyListeners(String eventName, JSObject data, boolean retainUntilConsumed) {}
  protected void notifyListeners(String eventName, JSObject data) {}
  protected void handleOnDestroy() {}
}
