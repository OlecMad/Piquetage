package com.getcapacitor;
/** Signatures de @capacitor/android 8.5.2, PluginCall.java l.53-262. */
public class PluginCall {
  public void resolve(JSObject data) {} public void resolve() {}
  public void reject(String msg, String code, Exception ex, JSObject data) {} public void reject(String msg, Exception ex, JSObject data) {}
  public void reject(String msg, String code, JSObject data) {} public void reject(String msg, String code, Exception ex) {}
  public void reject(String msg, JSObject data) {} public void reject(String msg, Exception ex) {}
  public void reject(String msg, String code) {} public void reject(String msg) {}
  public String getString(String name) { return null; } public String getString(String name, String defaultValue) { return null; }
  public Integer getInt(String name) { return null; } public Integer getInt(String name, Integer defaultValue) { return null; }
  public Boolean getBoolean(String name) { return null; } public Boolean getBoolean(String name, Boolean defaultValue) { return null; }
}
