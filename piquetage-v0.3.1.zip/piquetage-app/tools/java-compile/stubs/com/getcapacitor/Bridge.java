package com.getcapacitor;
/** @capacitor/android 8.5.2, Bridge.java l.1497. */
public class Bridge {
  public android.webkit.WebView getWebView() { return null; }   // Bridge.java l.517
  public void addWebViewListener(WebViewListener webViewListener) {}
}
