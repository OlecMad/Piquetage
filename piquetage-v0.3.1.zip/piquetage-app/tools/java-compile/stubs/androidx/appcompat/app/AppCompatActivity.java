package androidx.appcompat.app;
/** Chaîne réelle : AppCompatActivity → FragmentActivity → ComponentActivity → android.app.Activity.
    getOnBackPressedDispatcher() est déclarée par androidx.activity.ComponentActivity. */
public class AppCompatActivity extends android.app.Activity {
  public final androidx.activity.OnBackPressedDispatcher getOnBackPressedDispatcher() { return null; }
}
