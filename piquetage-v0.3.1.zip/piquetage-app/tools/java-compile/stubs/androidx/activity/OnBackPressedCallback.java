package androidx.activity;
/** androidx.activity (Kotlin : abstract class OnBackPressedCallback(enabled: Boolean)). */
public abstract class OnBackPressedCallback {
  public OnBackPressedCallback(boolean enabled) {}
  public abstract void handleOnBackPressed();
  public final boolean isEnabled() { return true; }
  public final void setEnabled(boolean enabled) {}
}
