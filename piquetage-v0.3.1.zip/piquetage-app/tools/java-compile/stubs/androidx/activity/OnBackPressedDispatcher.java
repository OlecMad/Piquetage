package androidx.activity;
/** androidx.activity : addCallback(OnBackPressedCallback), onBackPressed(). */
public final class OnBackPressedDispatcher {
  public void addCallback(OnBackPressedCallback onBackPressedCallback) {}
  public void onBackPressed() {}
}
