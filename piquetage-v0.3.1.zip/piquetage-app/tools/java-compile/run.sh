#!/usr/bin/env bash
# Compilation du code Java de l'application contre la VRAIE API Android 36
# (android.jar de la plate-forme) et des bouchons Capacitor recopiés des
# signatures de @capacitor/android 8.5.2 — en Java 21, comme Gradle.
# Tout avertissement javac (-Xlint:all) est traité comme une erreur.
#
# android.jar (≈ 54 Mo) n'est pas versionné : il est téléchargé une fois dans
# ~/.cache/diagfluvial depuis le dépôt public Reginer/aosp-android-jar.
set -euo pipefail
cd "$(dirname "$0")"
CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/diagfluvial"
JAR="$CACHE/android-36.jar"
if [ ! -s "$JAR" ]; then
  mkdir -p "$CACHE"
  curl -fsSL -o "$JAR" https://raw.githubusercontent.com/Reginer/aosp-android-jar/main/android-36/android.jar
fi
unzip -l "$JAR" android/bluetooth/BluetoothSocket.class >/dev/null
APP=../../android/app/src/main/java/fr/lileauvert/piquetage
rm -rf out && mkdir out
# -classfile : ce android.jar annote ses classes avec @UnsupportedAppUsage, absent du jar.
javac --release 21 -Xlint:all,-options,-classfile -Werror -encoding UTF-8 \
  -cp "$JAR" -d out $(find stubs -name "*.java") $(find "$APP" -name "*.java")
N=$(find out/fr -name "*.class" | wc -l)
echo "✅ Code Java compilé contre android-36 (Java 21, 0 avertissement) : $N classes."
