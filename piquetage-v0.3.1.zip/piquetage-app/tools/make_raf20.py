#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Conversion de la grille IGN RAF20 (GeoTIFF PROJ-data) en fichier JavaScript
compact embarqué dans l'application : www/raf20.js

Source : OSGeo/PROJ-data, fr_ign/fr_ign_RAF20.tif
  « From RGF93 v2b (EPSG:9781) to NGF-IGN69 height (EPSG:5720).
    Converted from RAF20.tac (last modified at 2022/06/09) »
  Licence de la grille : Licence Ouverte / Etalab (IGN).

Géométrie lue dans le fichier (RasterPixelIsPoint) :
  nœud (0,0) = lon -5.5°, lat 51.5° ; pas 1/30° en longitude, 0.025° en latitude,
  421 colonnes × 381 lignes → lon -5.5…8.5°, lat 42.0…51.5°.

Encodage : N (m) stocké en uint16 = round((N − 40) × 1000), résolution 1 mm,
valeur 65535 = hors grille. Erreur de quantification ≤ 0,5 mm, très inférieure
à la précision annoncée de la grille (centimétrique).

Usage : python3 tools/make_raf20.py chemin/vers/fr_ign_RAF20.tif
"""

import base64
import sys

import numpy as np
import tifffile

OFFSET = 40.0
SCALE = 0.001
NODATA = 65535


def main(path, out="www/raf20.js"):
    tif = tifffile.TiffFile(path)
    page = tif.pages[0]
    grid = page.asarray().astype(np.float64)
    tags = {t.name: t.value for t in page.tags.values()}

    sx, sy, _ = tags["ModelPixelScaleTag"]
    _, _, _, lon0, lat0, _ = tags["ModelTiepointTag"]
    nrows, ncols = grid.shape

    finite = np.isfinite(grid)
    q = np.full(grid.shape, NODATA, dtype="<u2")
    q[finite] = np.round((grid[finite] - OFFSET) / SCALE).astype("<u2")
    assert q[finite].max() < NODATA, "valeur hors plage d'encodage"

    b64 = base64.b64encode(q.tobytes()).decode("ascii")
    desc = tags.get("ImageDescription", "")

    js = (
        "/* Grille RAF20 — IGN, via OSGeo/PROJ-data (fr_ign_RAF20.tif).\n"
        "   " + desc + "\n"
        "   Licence Ouverte / Etalab. Généré par tools/make_raf20.py — ne pas éditer. */\n"
        "window.RAF20 = {\n"
        f"  lon0: {lon0!r}, lat0: {lat0!r},\n"
        f"  dlon: {sx!r}, dlat: {sy!r},\n"
        f"  ncols: {ncols}, nrows: {nrows},\n"
        f"  offset: {OFFSET}, scale: {SCALE}, nodata: {NODATA},\n"
        f"  data: \"{b64}\"\n"
        "};\n"
    )
    with open(out, "w", encoding="utf-8") as f:
        f.write(js)

    print(f"{out} : {ncols}×{nrows} nœuds, {int((~finite).sum())} hors grille, "
          f"N ∈ [{grid[finite].min():.3f} ; {grid[finite].max():.3f}] m, "
          f"{len(js) / 1024:.0f} Ko")


if __name__ == "__main__":
    main(sys.argv[1])
