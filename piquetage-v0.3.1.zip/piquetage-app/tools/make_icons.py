#!/usr/bin/env python3
"""Génère le logo de Piquetage et toutes les icônes Android.

Usage :
  python3 tools/make_icons.py apercu OUT.png        planche des variantes A, B, C
  python3 tools/make_icons.py generer [A|B|C]       écrit les ressources Android (défaut : A)

Dessin en 1024 × 1024 suréchantillonné ×2, puis réduit (PIL seul, aucune police).
Variantes :
  A  « Repère »  repère de position orange, réticule au centre, posé sur des courbes de niveau
  B  « Cible »   réticule de pointage, point orange au centre
  C  « Piquet »  piquet de géomètre à tête orange planté dans le sol, courbes de niveau
"""
import math
import os
import sys

from PIL import Image, ImageDraw

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RES = os.path.join(ROOT, 'android', 'app', 'src', 'main', 'res')

BG_TOP, BG_BOT = (47, 107, 79), (24, 68, 49)      # vert Piquetage (accent #2f6b4f)
ORANGE, ORANGE_D = (242, 107, 33), (201, 80, 14)
WOOD, WOOD_D = (240, 221, 180), (206, 180, 128)
WHITE, LIGHT = (255, 255, 255), (150, 214, 178)
S = 2                                              # suréchantillonnage
N = 1024 * S


def px(v):
    return int(round(v * S))


def gradient_bg():
    img = Image.new('RGB', (N, N))
    d = ImageDraw.Draw(img)
    for y in range(N):
        t = y / (N - 1)
        d.line([(0, y), (N, y)], fill=tuple(int(BG_TOP[i] + (BG_BOT[i] - BG_TOP[i]) * t) for i in range(3)))
    return img


def arc(d, cx, cy, r, a0, a1, w, fill):
    box = [px(cx - r), px(cy - r), px(cx + r), px(cy + r)]
    d.arc(box, a0, a1, fill=fill, width=px(w))
    for a in (a0, a1):                              # bouts arrondis
        x = cx + r * math.cos(math.radians(a)); y = cy + r * math.sin(math.radians(a))
        d.ellipse([px(x - w / 2), px(y - w / 2), px(x + w / 2), px(y + w / 2)], fill=fill)


def stake(d, cx, top, tip, width=92, paint=150, ground=None):
    """Piquet : tête peinte (orange), fût en bois, pointe."""
    hw = width / 2
    body_end = tip - 150
    # fût + pointe
    d.polygon([(px(cx - hw), px(top)), (px(cx + hw), px(top)), (px(cx + hw), px(body_end)),
               (px(cx), px(tip)), (px(cx - hw), px(body_end))], fill=WOOD)
    d.polygon([(px(cx), px(top)), (px(cx + hw), px(top)), (px(cx + hw), px(body_end)),
               (px(cx), px(tip))], fill=WOOD_D)      # face à l'ombre
    # tête peinte
    d.rectangle([px(cx - hw), px(top), px(cx + hw), px(top + paint)], fill=ORANGE)
    d.rectangle([px(cx), px(top), px(cx + hw), px(top + paint)], fill=ORANGE_D)
    d.rectangle([px(cx - hw), px(top - 18), px(cx + hw), px(top + 12)], fill=(255, 150, 90))


def ground_line(d, y, x0=200, x1=824, w=26):
    d.line([(px(x0), px(y)), (px(x1), px(y))], fill=LIGHT, width=px(w))
    for x in (x0, x1):
        d.ellipse([px(x - w / 2), px(y - w / 2), px(x + w / 2), px(y + w / 2)], fill=LIGHT)


def contours(d, cx, cy, radii, alpha0=255, step=45, width=20):
    for i, (rx, ry) in enumerate(radii):
        d.ellipse([px(cx - rx), px(cy - ry), px(cx + rx), px(cy + ry)],
                  outline=(150, 214, 178, max(60, alpha0 - i * step)), width=px(width))


def pin(d, cx, cy, r, tip_y):
    """Repère de position (goutte) : cercle + pointe tangente."""
    dist = tip_y - cy
    a = math.degrees(math.acos(r / dist))
    t1 = (cx + r * math.cos(math.radians(90 - a)), cy + r * math.sin(math.radians(90 - a)))
    t2 = (cx + r * math.cos(math.radians(90 + a)), cy + r * math.sin(math.radians(90 + a)))
    d.polygon([(px(cx), px(tip_y)), (px(t1[0]), px(t1[1])), (px(t2[0]), px(t2[1]))], fill=ORANGE)
    d.ellipse([px(cx - r), px(cy - r), px(cx + r), px(cy + r)], fill=ORANGE)
    # reflet à droite
    d.pieslice([px(cx - r), px(cy - r), px(cx + r), px(cy + r)], -60, 60, fill=ORANGE_D)
    d.polygon([(px(cx), px(tip_y)), (px(t1[0]), px(t1[1])), (px(cx + 4), px(cy + r * 0.2))], fill=ORANGE_D)


def foreground(variant):
    """Calque transparent 1024 × 1024 (sans fond)."""
    img = Image.new('RGBA', (N, N), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if variant == 'A':
        contours(d, 512, 800, ((170, 52), (280, 86), (390, 120), (480, 150)))
        d.ellipse([px(512 - 40), px(800 - 13), px(512 + 40), px(800 + 13)], fill=(14, 44, 31, 255))
        pin(d, 512, 395, 235, 800)
        d.ellipse([px(512 - 112), px(395 - 112), px(512 + 112), px(395 + 112)], fill=WHITE)
        d.ellipse([px(512 - 80), px(395 - 80), px(512 + 80), px(395 + 80)], outline=ORANGE, width=px(16))
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            d.line([(px(512 + dx * 38), px(395 + dy * 38)), (px(512 + dx * 96), px(395 + dy * 96))], fill=ORANGE, width=px(16))
        d.ellipse([px(512 - 20), px(395 - 20), px(512 + 20), px(395 + 20)], fill=ORANGE)
    elif variant == 'B':
        d.ellipse([px(512 - 320), px(512 - 320), px(512 + 320), px(512 + 320)], outline=WHITE, width=px(36))
        d.ellipse([px(512 - 170), px(512 - 170), px(512 + 170), px(512 + 170)], outline=LIGHT, width=px(24))
        for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
            x0, y0 = 512 + dx * 190, 512 + dy * 190
            x1, y1 = 512 + dx * 420, 512 + dy * 420
            d.line([(px(x0), px(y0)), (px(x1), px(y1))], fill=WHITE, width=px(36))
        d.ellipse([px(512 - 70), px(512 - 70), px(512 + 70), px(512 + 70)], fill=ORANGE)
        d.ellipse([px(512 - 70), px(512 - 70), px(512 + 70), px(512 + 70)], outline=(255, 190, 150), width=px(10))
    else:  # C — piquet planté
        contours(d, 512, 735, ((300, 90), (400, 120), (490, 148)), alpha0=200, step=55)
        d.ellipse([px(512 - 230), px(735 - 70), px(512 + 230), px(735 + 70)], fill=(95, 168, 128, 255))   # sol, partie arrière
        stake(d, 512, 250, 900, width=168, paint=165)
        d.pieslice([px(512 - 230), px(735 - 70), px(512 + 230), px(735 + 70)], 0, 180, fill=(70, 140, 103, 255))  # sol, partie avant
        d.ellipse([px(512 - 84), px(250 - 26), px(512 + 84), px(250 + 26)], fill=(255, 150, 90, 255))     # tête du piquet
        d.ellipse([px(512 - 22), px(250 - 8), px(512 + 22), px(250 + 8)], fill=(60, 30, 10, 255))         # clou
    return img


def full_icon(variant, radius=0.22):
    """Icône pleine (fond vert + dessin), 1024 × 1024 final, coins arrondis."""
    bg = gradient_bg().convert('RGBA')
    bg.alpha_composite(foreground(variant))
    bg = bg.resize((1024, 1024), Image.LANCZOS)
    mask = Image.new('L', (1024 * 2, 1024 * 2), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, 2047, 2047], radius=int(2048 * radius), fill=255)
    bg.putalpha(mask.resize((1024, 1024), Image.LANCZOS))
    return bg


def round_icon(variant):
    bg = gradient_bg().convert('RGBA')
    bg.alpha_composite(foreground(variant))
    bg = bg.resize((1024, 1024), Image.LANCZOS)
    mask = Image.new('L', (2048, 2048), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, 2047, 2047], fill=255)
    bg.putalpha(mask.resize((1024, 1024), Image.LANCZOS))
    return bg


def adaptive_foreground(variant):
    """Calque adaptatif : le dessin tient dans la zone sûre (66/108 du côté)."""
    fg = foreground(variant).resize((1024, 1024), Image.LANCZOS)
    safe = int(1024 * 66 / 108 * 1.12)             # le dessin déborde un peu du centre : 1,12
    fg = fg.resize((safe, safe), Image.LANCZOS)
    canvas = Image.new('RGBA', (1024, 1024), (0, 0, 0, 0))
    canvas.alpha_composite(fg, ((1024 - safe) // 2, (1024 - safe) // 2))
    return canvas


def save(img, path, size):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(path, optimize=True)


def splash(variant, w, h, path):
    """Écran de démarrage : fond vert, logo au centre."""
    bg = Image.new('RGB', (w, h), BG_BOT)
    logo = full_icon(variant)
    side = int(min(w, h) * 0.34)
    logo = logo.resize((side, side), Image.LANCZOS)
    bg.paste(logo, ((w - side) // 2, (h - side) // 2), logo)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    bg.save(path, optimize=True)


def apercu(out):
    sheet = Image.new('RGB', (1500, 700), (243, 245, 241))
    d = ImageDraw.Draw(sheet)
    names = {'A': 'A · Repere', 'B': 'B · Cible', 'C': 'C · Piquet'}
    for i, v in enumerate('ABC'):
        x = 40 + i * 490
        big = full_icon(v).resize((300, 300), Image.LANCZOS)
        sheet.paste(big, (x, 60), big)
        rnd = round_icon(v).resize((120, 120), Image.LANCZOS)
        sheet.paste(rnd, (x + 330, 60), rnd)
        small = full_icon(v).resize((60, 60), Image.LANCZOS)
        sheet.paste(small, (x + 345, 200), small)
        tiny = full_icon(v).resize(( 36, 36), Image.LANCZOS)
        sheet.paste(tiny, (x + 360, 280), tiny)
        d.text((x, 20), names[v], fill=(29, 36, 32))
        # fond de lanceur sombre
        dark = Image.new('RGB', (440, 150), (30, 34, 32))
        for j, sz in enumerate((96, 64, 48)):
            ic = full_icon(v).resize((sz, sz), Image.LANCZOS)
            dark.paste(ic, (20 + j * 130, 20), ic)
        sheet.paste(dark, (x, 400))
    sheet.save(out)


def generer(variant):
    densities = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
    fg_sizes = {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}
    full, rnd, fg = full_icon(variant), round_icon(variant), adaptive_foreground(variant)
    for dens in densities:
        save(full, os.path.join(RES, f'mipmap-{dens}', 'ic_launcher.png'), densities[dens])
        save(rnd, os.path.join(RES, f'mipmap-{dens}', 'ic_launcher_round.png'), densities[dens])
        save(fg, os.path.join(RES, f'mipmap-{dens}', 'ic_launcher_foreground.png'), fg_sizes[dens])
    with open(os.path.join(RES, 'values', 'ic_launcher_background.xml'), 'w', encoding='utf-8') as fh:
        fh.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
                 '    <color name="ic_launcher_background">#2F6B4F</color>\n</resources>\n')
    # l'ancien fond vectoriel du gabarit Capacitor et son avant-plan sont inutilisés : on les aligne
    for name, sz in (('drawable', (480, 320)), ('drawable-land-mdpi', (480, 320)), ('drawable-land-hdpi', (800, 480)),
                     ('drawable-land-xhdpi', (1280, 720)), ('drawable-land-xxhdpi', (1600, 960)),
                     ('drawable-land-xxxhdpi', (1920, 1280)),
                     ('drawable-port-mdpi', (320, 480)), ('drawable-port-hdpi', (480, 800)),
                     ('drawable-port-xhdpi', (720, 1280)), ('drawable-port-xxhdpi', (960, 1600)),
                     ('drawable-port-xxxhdpi', (1280, 1920))):
        splash(variant, sz[0], sz[1], os.path.join(RES, name, 'splash.png'))
    # icônes web (installation hors APK) : 192 et 512
    for sz in (192, 512):
        save(full, os.path.join(ROOT, 'www', 'icons', f'icon-{sz}.png'), sz)
    save(full_icon(variant, radius=0.0), os.path.join(ROOT, 'www', 'icons', 'icon-512-maskable.png'), 512)
    save(full_icon(variant, radius=0.0), os.path.join(ROOT, 'www', 'icons', 'icon-192-maskable.png'), 192)
    full.resize((512, 512), Image.LANCZOS).save(os.path.join(ROOT, 'tools', 'logo-piquetage-512.png'), optimize=True)
    print('Icônes générées, variante', variant)


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'generer'
    if cmd == 'apercu':
        apercu(sys.argv[2])
    else:
        generer(sys.argv[2] if len(sys.argv) > 2 else 'A')
