/* Tests du noyau RTK (www/rtk-core.js) — exécution : node tools/test-rtk-core.js

   Faux plugin GnssBridge + horloge simulée : aucune attente réelle, aucun
   navigateur. Trames NMEA authentiques (sommes de contrôle calculées).
   Les valeurs attendues (Lambert-93, RAF20) viennent de geo.js, lui-même
   validé contre PROJ 9.5.1 dans Diagnostic Fluvial.

   Ne remplace pas l'essai avec la vraie canne : voir README, « Essai terrain ». */
const fs = require('fs');
const path = require('path');
const G = require('../www/geo.js');
eval(fs.readFileSync(path.join(__dirname, '../www/raf20.js'), 'utf8').replace('window.RAF20', 'globalThis.RAF20'));
G.loadGeoid(globalThis.RAF20);
const RtkCore = require('../www/rtk-core.js');

let fails = 0, n = 0;
function ok(c, label, detail) {
  n++;
  console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : ''));
  if (!c) fails++;
}

const LAT = 47.1833, LON = 1.0940, H_ELL = 100.000, SEP = 47.000;

/* ---- horloge simulée ---- */
function makeClock() {
  let t = 1000000, id = 0;
  const timers = new Map();
  return {
    now: () => t,
    setTimeout: (f, ms) => { const h = ++id; timers.set(h, { f, at: t + ms, every: 0 }); return h; },
    clearTimeout: (h) => timers.delete(h),
    setInterval: (f, ms) => { const h = ++id; timers.set(h, { f, at: t + ms, every: ms }); return h; },
    clearInterval: (h) => timers.delete(h),
    pending: () => timers.size,
    advance(ms) {
      const end = t + ms;
      for (;;) {
        let nextH = null, next = null;
        for (const [h, x] of timers) if (x.at <= end && (next === null || x.at < next.at)) { next = x; nextH = h; }
        if (next === null) break;
        t = next.at;
        if (next.every) next.at += next.every; else timers.delete(nextH);
        next.f();
      }
      t = end;
    }
  };
}
const flush = async () => { for (let i = 0; i < 6; i++) await Promise.resolve(); };

/* ---- faux plugin GnssBridge ---- */
function makePlugin(opts) {
  opts = opts || {};
  const listeners = {};
  const calls = { connect: [], startNtrip: [], stopNtrip: 0, disconnect: 0, list: 0 };
  const plugin = {
    failConnect: !!opts.failConnect,
    devices: opts.devices || [
      { name: 'Galaxy Buds', address: 'AA:AA:AA:AA:AA:AA', type: 1 },
      { name: 'RTK_GNSS_4F2A', address: '00:11:22:33:44:55', type: 1 }
    ],
    addListener: (evt, cb) => { (listeners[evt] = listeners[evt] || []).push(cb); return Promise.resolve({ remove: () => Promise.resolve() }); },
    listDevices: () => { calls.list++; return Promise.resolve({ devices: plugin.devices }); },
    connect: (o) => { calls.connect.push(o); return plugin.failConnect ? Promise.reject(new Error('échec simulé')) : Promise.resolve({ address: o.address }); },
    disconnect: () => { calls.disconnect++; return Promise.resolve(); },
    startNtrip: (o) => { calls.startNtrip.push(o); return Promise.resolve(); },
    stopNtrip: () => { calls.stopNtrip++; return Promise.resolve(); },
    emit: (evt, data) => (listeners[evt] || []).forEach((cb) => cb(data))
  };
  plugin.calls = calls;
  return plugin;
}

/* ---- trames NMEA ---- */
function cs(b) { let c = 0; for (const ch of b) c ^= ch.charCodeAt(0); return '$' + b + '*' + c.toString(16).toUpperCase().padStart(2, '0'); }
function dm(v, w) { const d = Math.floor(Math.abs(v)); const m = (Math.abs(v) - d) * 60; return String(d).padStart(w, '0') + m.toFixed(7).padStart(10, '0'); }
let tick = 0;
function nmea(plugin, q, opt) {
  opt = opt || {};
  const lat = opt.lat !== undefined ? opt.lat : LAT, lon = opt.lon !== undefined ? opt.lon : LON, hEll = opt.hEll !== undefined ? opt.hEll : H_ELL;
  tick++;
  const s = tick % 60;
  const time = '120' + String(Math.floor(tick / 60) % 10) + String(s).padStart(2, '0') + '.00';
  plugin.emit('nmea', { line: cs('GNGGA,' + time + ',' + dm(lat, 2) + ',N,' + dm(lon, 3) + ',E,' + q + ',20,0.50,' + (hEll - SEP).toFixed(4) + ',M,' + SEP.toFixed(4) + ',M,1.0,0412') });
  if (opt.gst !== false) plugin.emit('nmea', { line: cs('GNGST,' + time + ',0.012,0.010,0.008,45.0,0.009,0.008,0.015') });
}

function memStore() { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, _m: m }; }

async function setup(opts) {
  opts = opts || {};
  const clock = makeClock();
  const plugin = makePlugin(opts.plugin);
  const store = opts.store || memStore();
  const rtk = RtkCore.create({ geo: G, plugin: opts.noPlugin ? null : plugin, storage: store, timers: clock });
  const msgs = [];
  rtk.on('message', (m) => msgs.push(m));
  return { clock, plugin, store, rtk, msgs };
}

/* =========================================================== */
(async () => {
  console.log('\n── Démarrage et appareils ──');
  {
    const { rtk, plugin, store } = await setup();
    const st = rtk.status();
    ok(st.code === 'OFF' && st.label === 'Non reliée' && st.available, 'état initial « Non reliée »');
    ok(!st.heights.complete && st.heights.missing.length === 2, 'hauteurs non saisies : aucune valeur par défaut');
    const devs = await rtk.refreshDevices();
    ok(devs.length === 2 && plugin.calls.list === 1, 'appareils appairés listés');
    ok(rtk.settings.address === '00:11:22:33:44:55' && rtk.settings.name === 'RTK_GNSS_4F2A', 'récepteur RTK_GNSS_* présélectionné');
    ok(JSON.parse(store._m['piquetage.rtk']).address === '00:11:22:33:44:55', 'sélection mémorisée');
  }
  {
    const { rtk } = await setup({ noPlugin: true });
    ok(!rtk.status().available && (await rtk.refreshDevices()).length === 0, 'sans plugin (navigateur) : lecture seule');
    let err = null; await rtk.connect().catch((e) => { err = e; });
    ok(err && /application Android/.test(err.message), 'connexion refusée avec un message clair', err && err.message);
  }

  console.log('\n── Connexion et NTRIP ──');
  const ctx = await setup();
  const { rtk, plugin, clock, msgs } = ctx;
  await rtk.refreshDevices();
  await rtk.connect();
  await flush();
  ok(plugin.calls.connect.length === 1 && plugin.calls.connect[0].address === '00:11:22:33:44:55', 'connexion à la bonne adresse');
  const nt = plugin.calls.startNtrip[0] || {};
  ok(nt.host === 'crtk.net' && nt.port === 2101 && nt.mountpoint === 'NEAR' && nt.user === 'centipede' && nt.password === 'centipede' && nt.ggaInterval === 10,
    'NTRIP : paramètres Centipede par défaut', JSON.stringify(nt));
  ok(rtk.status().connected && rtk.status().code === 'NONE' && rtk.status().label === 'Aucune trame', 'relié, en attente de trames');
  plugin.emit('ntrip', { state: 'connected', bytes: 4096 });
  ok(rtk.status().ntrip.state === 'connected' && rtk.status().ntrip.bytes === 4096, 'état NTRIP et octets reçus relayés');
  plugin.emit('ntrip', { state: 'error', message: 'refusé' });
  ok(msgs.some((m) => m === 'NTRIP : refusé'), 'erreur NTRIP signalée une fois');

  console.log('\n── Position en direct ──');
  nmea(plugin, 4);
  let st = rtk.status();
  ok(st.code === 'FIX' && st.label === 'RTK FIX' && st.fresh, 'RTK FIX');
  ok(st.sats === 20 && st.hdop === 0.5 && st.diffAge === 1, '20 satellites, HDOP 0,50, âge des corrections 1,0 s');
  ok(st.gstAvailable && rtk.cm(st.sdH) === '1,2 cm' && rtk.cm(st.sdV) === '1,5 cm', 'σ horizontal 1,2 cm et vertical 1,5 cm issus de la GST');
  const exp = G.toLambert93(LAT, LON), N = G.geoidN(LAT, LON);
  ok(Math.abs(st.point.x93 - exp.x) < 1e-3 && Math.abs(st.point.y93 - exp.y) < 1e-3, 'Lambert-93 en direct', st.point.x93.toFixed(3) + ' ; ' + st.point.y93.toFixed(3));
  ok(st.point.hNgfGround === null && Math.abs(st.point.hNgfAntenna - (H_ELL - N)) < 1e-4, 'sans hauteurs saisies : altitude de l’antenne seule', st.point.hNgfAntenna.toFixed(4));
  rtk.set('pole', '2,000'); rtk.set('apc', '0,0615');
  st = rtk.status();
  ok(rtk.settings.pole === '2.000' && st.heights.complete, 'virgule décimale acceptée');
  ok(Math.abs(st.point.hNgfGround - (H_ELL - N - 2 - 0.0615)) < 1e-4, 'H sol = h − N(RAF20) − canne − centre de phase', st.point.hNgfGround.toFixed(4));
  nmea(plugin, 5);
  ok(rtk.status().code === 'FLOAT', 'RTK FLOAT');
  nmea(plugin, 1);
  ok(rtk.status().code === 'GPS', 'GPS autonome');
  clock.advance(3100);
  ok(rtk.status().code === 'NONE' && !rtk.status().fresh, 'sans trame pendant 3 s : « Aucune trame »');

  console.log('\n── Levé d’un point ──');
  {
    rtk.set('avg', 5); rtk.set('requireFix', true);
    nmea(plugin, 5);
    let err = null; await rtk.capture().catch((e) => { err = e; });
    ok(err && /RTK FIX exigé/.test(err.message), 'point refusé en FLOAT quand le FIX est exigé', err && err.message);

    nmea(plugin, 4);
    clock.advance(10);          // l'époque précédente est antérieure au début de la mesure
    const prom = rtk.capture();
    for (let i = 0; i < 5; i++) { clock.advance(1000); nmea(plugin, 4, { hEll: H_ELL + i * 0.002 }); }
    clock.advance(1000);       // dernier passage de l'intervalle, puis attente de la GST (350 ms)
    clock.advance(400);
    const p = await prom;
    ok(p.epochsRequested === 5 && Math.abs(p.x93 - exp.x) < 1e-3 && Math.abs(p.y93 - exp.y) < 1e-3, 'point moyenné sur 5 époques, Lambert-93 exact', p.x93.toFixed(3) + ' ; ' + p.y93.toFixed(3));
    ok(Math.abs(p.hNgfGround - (H_ELL + 0.004 - N - 2 - 0.0615)) < 1e-3, 'altitude moyennée = moyenne des hauteurs − N − hauteurs saisies', p.hNgfGround.toFixed(4));
    ok(p.receiver === 'RTK_GNSS_4F2A' && p.mountpoint === 'NEAR' && p.acc !== null && /^\d{4}-/.test(p.t), 'récepteur, point de montage, précision et date enregistrés');
    ok(msgs.some((m) => /5 \/ 5 époques/.test(m)), 'progression « n / 5 époques » annoncée');

    // une mesure ne peut pas en chevaucher une autre
    nmea(plugin, 4);
    const a = rtk.capture(); let dup = null; await rtk.capture().catch((e) => { dup = e; });
    ok(dup && /déjà en cours/.test(dup.message), 'deuxième mesure refusée pendant la première');
    clock.advance(2000); nmea(plugin, 4); clock.advance(15000); clock.advance(400);
    await a.catch(() => {});

    // FLOAT en cours de mesure : époques écartées et comptées
    rtk.set('avg', 1);
    nmea(plugin, 4);
    const one = rtk.capture();
    clock.advance(300); clock.advance(400);
    const p1 = await one;
    ok(p1.epochsRequested === 1 && Math.abs(p1.x93 - exp.x) < 1e-3, 'mesure instantanée (1 époque) : Lambert-93 exact');
  }

  console.log('\n── Perte de liaison et reconnexion ──');
  {
    const c = plugin.calls.connect.length, stops = plugin.calls.stopNtrip;
    plugin.emit('bluetooth', { state: 'disconnected', message: 'perdu' });
    ok(!rtk.status().connected && rtk.status().label === 'Reconnexion…', 'liaison perdue : « Reconnexion… »');
    ok(plugin.calls.stopNtrip === stops + 1 && msgs.some((m) => /reconnexion automatique/.test(m)), 'NTRIP arrêté et opérateur prévenu');
    clock.advance(4900);
    ok(plugin.calls.connect.length === c, 'pas de nouvelle tentative avant 5 s');
    clock.advance(200);
    await flush();
    ok(plugin.calls.connect.length === c + 1, 'reconnexion automatique après 5 s');
    ok(rtk.status().connected && plugin.calls.startNtrip.length >= 2, 'reliée de nouveau, NTRIP relancé');

    plugin.failConnect = true;
    plugin.emit('bluetooth', { state: 'disconnected' });
    clock.advance(5100); await flush();
    const c2 = plugin.calls.connect.length;
    clock.advance(5100); await flush();
    ok(plugin.calls.connect.length === c2 + 1, 'échec de reconnexion : nouvel essai programmé');

    rtk.disconnect();
    const c3 = plugin.calls.connect.length;
    clock.advance(30000); await flush();
    ok(plugin.calls.connect.length === c3 && plugin.calls.disconnect >= 1, 'déconnexion volontaire : plus aucune reconnexion');
    ok(rtk.status().label === 'Non reliée', 'état « Non reliée » après déconnexion');
  }

  console.log('\n── Réglages ──');
  {
    const { rtk: r, store } = await setup();
    r.set('ntrip.mount', ' LHER '); r.set('ntrip.port', '2102'); r.set('ntrip.gga', 'abc'); r.set('avg', '10'); r.set('requireFix', false);
    ok(r.settings.ntrip.mount === 'LHER' && r.settings.ntrip.port === 2102, 'point de montage nettoyé, port numérique');
    ok(r.settings.ntrip.gga === 10, 'valeur invalide : retour à la valeur par défaut');
    const r2 = RtkCore.create({ geo: G, plugin: null, storage: store, timers: makeClock() });
    ok(r2.settings.ntrip.mount === 'LHER' && r2.settings.avg === 10 && r2.settings.requireFix === false, 'réglages relus au redémarrage');
    let bad = null; try { r.set('inconnu', 1); } catch (e) { bad = e; }
    ok(!!bad, 'réglage inconnu refusé');
    const corrupt = memStore(); corrupt.setItem('piquetage.rtk', '{pas du json');
    const r3 = RtkCore.create({ geo: G, plugin: null, storage: corrupt, timers: makeClock() });
    ok(r3.settings.ntrip.host === 'crtk.net', 'stockage corrompu : réglages par défaut');
  }

  console.log('\n── Nettoyage ──');
  {
    const { rtk: r, clock: c } = await setup();
    r.dispose();
    ok(c.pending() === 0, 'dispose() arrête toutes les horloges');
  }

  console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
