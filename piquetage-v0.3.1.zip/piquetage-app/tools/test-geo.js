/* Tests unitaires du module géodésique www/geo.js — exécution : node tools/test-geo.js
   Les références Lambert-93 et RAF20 sont vérifiées séparément contre pyproj/PROJ
   (voir README, § Vérification) ; ici : NMEA, chaîne de calcul, cas limites. */
const fs = require('fs');
const path = require('path');
const G = require('../www/geo.js');
eval(fs.readFileSync(path.join(__dirname, '../www/raf20.js'), 'utf8').replace('window.RAF20', 'globalThis.RAF20'));
G.loadGeoid(globalThis.RAF20);

let fails = 0, n = 0;
function ok(c, label, detail) {
  n++;
  console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : ''));
  if (!c) fails++;
}
function near(a, b, tol) { return a !== null && b !== null && Math.abs(a - b) <= tol; }
function withCs(body) {
  let cs = 0;
  for (const ch of body) cs ^= ch.charCodeAt(0);
  return '$' + body + '*' + cs.toString(16).toUpperCase().padStart(2, '0');
}

console.log('\n── Somme de contrôle NMEA ──');
// Exemple canonique de la norme NMEA 0183 (somme *47 publiée)
const canon = '$GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47';
ok(G.checksumOk(canon), 'trame GGA canonique acceptée (*47)');
ok(!G.checksumOk(canon.replace('*47', '*48')), 'somme fausse rejetée');
ok(G.parseNmea(canon.replace('4807.038', '4807.039')) === null, 'trame altérée rejetée');
ok(G.parseNmea('GPGGA,sans,dollar') === null, 'trame sans $ rejetée');

console.log('\n── GGA ──');
const g = G.parseNmea(canon);
ok(g && g.type === 'GGA', 'type GGA');
ok(near(g.lat, 48 + 7.038 / 60, 1e-12), 'latitude ddmm.mmm → degrés', g.lat.toFixed(7));
ok(near(g.lon, 11 + 31 / 60, 1e-12), 'longitude dddmm.mmm → degrés', g.lon.toFixed(7));
ok(g.quality === 1 && g.sats === 8 && g.hdop === 0.9, 'qualité 1, 8 satellites, HDOP 0,9');
ok(near(g.hEll, 545.4 + 46.9, 1e-9), 'h ellipsoïdale = altitude + séparation', g.hEll);

const gS = G.parseNmea(withCs('GNGGA,101530.00,4710.00000,N,00054.00000,W,4,18,0.52,120.123,M,47.456,M,1.0,0412'));
ok(gS.lon < 0 && near(gS.lon, -0.9, 1e-12), 'hémisphère Ouest → longitude négative');
ok(gS.quality === 4 && G.qualityInfo(4).code === 'FIX', 'qualité 4 = RTK FIX');
ok(gS.diffAge === 1.0 && gS.diffStation === '0412', 'âge des corrections et station');
const gNoSep = G.parseNmea(withCs('GNGGA,101530.00,4710.00000,N,00054.00000,E,5,18,0.52,120.1,M,,M,,'));
ok(gNoSep.hEll === null && gNoSep.quality === 5, 'séparation absente → h ellipsoïdale inconnue, pas inventée');
ok(G.qualityInfo(5).code === 'FLOAT' && G.qualityInfo(5).rank < G.qualityInfo(4).rank, 'FLOAT classé sous FIX');

console.log('\n── GST ──');
const s = G.parseNmea(withCs('GNGST,101530.00,0.012,0.010,0.008,45.0,0.009,0.008,0.015'));
ok(s && s.type === 'GST' && s.sdLat === 0.009 && s.sdLon === 0.008 && s.sdAlt === 0.015, 'écarts-types lat / lon / alt');

console.log('\n── Chaîne de calcul d’un point ──');
// Point à Genillé (Indre-et-Loire), secteur des bases LHER / PRDR / FORG du guide
const lat = 47.1833, lon = 1.0940;
const N = G.geoidN(lat, lon);
ok(N !== null && N > 42 && N < 57, 'ondulation RAF20 dans la plage de la grille', N.toFixed(4) + ' m');
function epoch(dLatM, dLonM, h, q) {
  const dl = dLatM / 111200, dn = dLonM / (111200 * Math.cos(lat * Math.PI / 180));
  const la = lat + dl, lo = lon + dn;
  const toDm = (v, w) => { const d = Math.floor(Math.abs(v)); const m = (Math.abs(v) - d) * 60; return String(d).padStart(w, '0') + m.toFixed(7).padStart(10, '0'); };
  const body = 'GNGGA,101530.00,' + toDm(la, 2) + ',N,' + toDm(lo, 3) + ',E,' + q + ',20,0.50,' + (h - 47).toFixed(4) + ',M,47.0000,M,1.0,0412';
  return { gga: G.parseNmea(withCs(body)), gst: { sdLat: 0.010, sdLon: 0.012, sdAlt: 0.020 } };
}
const eps = [epoch(0.004, 0, 100, 4), epoch(-0.004, 0, 100.002, 4), epoch(0, 0.004, 99.998, 4), epoch(0, -0.004, 100, 4)];
const p = G.surveyPoint(eps, { poleHeight: 2.0, apcOffset: 0.0 });
ok(p.epochs === 4, '4 époques moyennées');
ok(near(p.lat, lat, 1e-8) && near(p.lon, lon, 1e-8), 'moyenne des positions', p.lat.toFixed(8) + ', ' + p.lon.toFixed(8));
ok(near(p.hEll, 100, 1e-6), 'h ellipsoïdale moyenne', p.hEll.toFixed(4));
ok(near(p.hNgfAntenna, 100 - N, 1e-6), 'H antenne = h − N', p.hNgfAntenna.toFixed(4));
ok(near(p.hNgfGround, 100 - N - 2.0, 1e-6), 'H sol = H antenne − hauteur de canne', p.hNgfGround.toFixed(4));
const l = G.toLambert93(p.lat, p.lon);
ok(near(p.x93, l.x, 1e-6) && near(p.y93, l.y, 1e-6), 'Lambert-93 du point moyen', p.x93.toFixed(3) + ' ; ' + p.y93.toFixed(3));
ok(near(p.spreadH, Math.sqrt(4 * 0.004 * 0.004 / 3), 2e-4), 'dispersion horizontale empirique', (p.spreadH * 1000).toFixed(2) + ' mm');
ok(near(p.sdLat, 0.010, 1e-12) && near(p.sdAlt, 0.020, 1e-12), 'écarts-types GST moyennés');
ok(p.quality === 4 && p.qualityLabel === 'RTK FIX', 'qualité du point = RTK FIX');

const mixed = G.surveyPoint([epoch(0, 0, 100, 4), epoch(0, 0, 100, 5)], {});
ok(mixed.quality === 5, 'une époque FLOAT dégrade le point en FLOAT');

const pApc = G.surveyPoint(eps, { poleHeight: 2.0, apcOffset: 0.057 });
ok(near(pApc.hNgfGround, 100 - N - 2.057, 1e-6), 'décalage centre de phase soustrait en plus de la canne');

const noApc = G.surveyPoint(eps, { poleHeight: 2.0 });
ok(noApc.hNgfAntenna !== null && noApc.hNgfGround === null && noApc.apcOffset === null,
  'décalage centre de phase non saisi → pas d’altitude au sol (aucune valeur par défaut)');
const noPole = G.surveyPoint(eps, { apcOffset: 0 });
ok(noPole.hNgfGround === null && noPole.poleHeight === null, 'hauteur de canne non saisie → pas d’altitude au sol');
const zeroOk = G.surveyPoint(eps, { poleHeight: 0, apcOffset: 0 });
ok(near(zeroOk.hNgfGround, 100 - N, 1e-6), '0 saisi explicitement est accepté');

const noSep = G.surveyPoint([{ gga: gNoSep, gst: null }], { poleHeight: 2, apcOffset: 0 });
ok(noSep.hEll === null && noSep.hNgfAntenna === null && noSep.hNgfGround === null,
  'sans séparation : aucune altitude NGF calculée (pas d’approximation)');
ok(G.geoidN(40.0, 0.0) === null && G.geoidN(47, 10.0) === null, 'hors emprise RAF20 → null');

console.log('\n' + (fails === 0 ? '✅ ' + n + ' assertions vertes.' : '❌ ' + fails + '/' + n + ' en échec.'));
process.exit(fails ? 1 : 0);
