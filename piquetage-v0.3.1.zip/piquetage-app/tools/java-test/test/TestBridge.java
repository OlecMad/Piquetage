import fr.lileauvert.piquetage.GnssBridgePlugin;
import com.getcapacitor.Plugin;
import android.bluetooth.BluetoothSocket;
import java.io.*; import java.lang.reflect.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.util.*;

public class TestBridge {
  static int fails = 0, n = 0;
  static void ok(boolean c, String label, Object detail){ n++; System.out.println((c?"  ✓ ":"  ✗ ")+label+(detail!=null?"  → "+detail:"")); if(!c) fails++; }
  static Field f(String name) throws Exception { Field x = GnssBridgePlugin.class.getDeclaredField(name); x.setAccessible(true); return x; }
  static Method m(String name, Class<?>... t) throws Exception { Method x = GnssBridgePlugin.class.getDeclaredMethod(name, t); x.setAccessible(true); return x; }
  static String cs(String body){ int c=0; for(char ch: body.toCharArray()) c^=ch; return "$"+body+"*"+String.format("%02X", c); }
  static List<String> events(String type){ List<String> r=new ArrayList<>(); synchronized(Plugin.EVENTS){ for(String[] e: Plugin.EVENTS) if(e[0].equals(type)) r.add(e[1]); } return r; }

  /** Faux caster : une connexion, réponse imposée, puis flux de faux RTCM ; mémorise la requête et les GGA reçues. */
  static class FakeCaster extends Thread {
    final ServerSocket ss; final String reply; final boolean stream; final StringBuilder received = new StringBuilder(); volatile int sent = 0;
    FakeCaster(String reply, boolean stream) throws IOException { ss = new ServerSocket(0); this.reply = reply; this.stream = stream; setDaemon(true); }
    int port(){ return ss.getLocalPort(); }
    public void run(){
      try (Socket s = ss.accept()) {
        s.setSoTimeout(300);
        InputStream in = s.getInputStream(); OutputStream out = s.getOutputStream();
        long end = System.currentTimeMillis() + 2500; boolean replied = false; byte[] b = new byte[1024];
        while (System.currentTimeMillis() < end) {
          try { int k = in.read(b); if (k < 0) break; synchronized(received){ received.append(new String(b,0,k,StandardCharsets.US_ASCII)); } } catch (SocketTimeoutException te) {}
          if (!replied && received.indexOf("\r\n\r\n") >= 0) { out.write(reply.getBytes(StandardCharsets.US_ASCII)); out.flush(); replied = true; if (!stream) { Thread.sleep(200); break; } }
          if (replied && stream) { byte[] rtcm = new byte[]{(byte)0xD3,0x00,0x13,0x3E,(byte)0xD0,0x00,0x03}; out.write(rtcm); out.flush(); sent += rtcm.length; }
        }
      } catch (Exception ignored) {}
    }
  }

  static void runNtrip(GnssBridgePlugin p, int port, String mount, String user, String pass, long ms) throws Exception {
    f("ntripWanted").set(p, true);
    Method loop = m("ntripLoop", String.class, int.class, String.class, String.class, String.class, int.class);
    Thread t = new Thread(() -> { try { loop.invoke(p, "127.0.0.1", port, mount, user, pass, 1); } catch (Exception e) { e.printStackTrace(); } });
    t.start(); Thread.sleep(ms); f("ntripWanted").set(p, false);
    Object sock = f("ntripSocket").get(p); if (sock != null) ((Socket) sock).close();
    t.join(8000);
  }

  public static void main(String[] a) throws Exception {
    String GGA = cs("GNGGA,101530.00,4710.99800,N,00105.64000,E,4,20,0.50,72.100,M,47.000,M,1.0,0412");

    System.out.println("\n── Lecture Bluetooth : découpe et filtrage des trames ──");
    GnssBridgePlugin bt = new GnssBridgePlugin();
    ByteArrayOutputStream feed = new ByteArrayOutputStream();
    feed.write((GGA + "\r\n").getBytes(StandardCharsets.US_ASCII));
    feed.write(new byte[]{(byte)0xB5,0x62,0x01,0x07,0x5C,0x00,'\n',(byte)0xFF,(byte)0x80});  // binaire UBX parasite, contenant un \n
    feed.write((cs("GNGSV,3,1,11,02,45,120,40") + "\r\n").getBytes(StandardCharsets.US_ASCII));
    feed.write((cs("GNGST,101530.00,0.012,0.010,0.008,45.0,0.009,0.008,0.015") + "\r\n").getBytes(StandardCharsets.US_ASCII));
    feed.write((cs("GNRMC,101530.00,A,4710.99800,N,00105.64000,E,0.01,,220926,,,R,V") + "\r\n").getBytes(StandardCharsets.US_ASCII));
    feed.write((cs("GNVTG,,T,,M,0.01,N,0.02,K,R") + "\r\n").getBytes(StandardCharsets.US_ASCII));
    BluetoothSocket.TEST_IN = new ByteArrayInputStream(feed.toByteArray());
    BluetoothSocket sock = new BluetoothSocket();
    f("btSocket").set(bt, sock);
    Plugin.EVENTS.clear();
    m("readLoop", BluetoothSocket.class).invoke(bt, sock);
    List<String> nmea = events("nmea");
    ok(nmea.size() == 3, "3 trames transmises (GGA, GST, RMC), GSV et VTG filtrées", nmea.size());
    ok(nmea.size() > 0 && nmea.get(0).contains(GGA), "GGA transmise intacte, somme de contrôle comprise", null);
    ok(GGA.equals(f("lastGga").get(bt)), "dernière GGA mémorisée pour le caster", null);
    ok(events("bluetooth").stream().anyMatch(e -> e.contains("disconnected")), "fin de flux → événement « disconnected »", null);
    ok(f("btSocket").get(bt) == null, "socket libéré après coupure", null);

    System.out.println("\n── NTRIP : flux ICY 200 OK ──");
    GnssBridgePlugin p = new GnssBridgePlugin();
    f("lastGga").set(p, GGA);
    FakeCaster fc = new FakeCaster("ICY 200 OK\r\n", true); fc.start();
    Plugin.EVENTS.clear();
    runNtrip(p, fc.port(), "LHER", "centipede", "centipede", 2200);
    String req; synchronized(fc.received){ req = fc.received.toString(); }
    ok(req.startsWith("GET /LHER HTTP/1.0\r\n"), "requête NTRIP v1 sur le point de montage", req.split("\r\n")[0]);
    String auth = "Basic " + Base64.getEncoder().encodeToString("centipede:centipede".getBytes(StandardCharsets.UTF_8));
    ok(req.contains("Authorization: " + auth + "\r\n"), "authentification Basic centipede/centipede", auth);
    ok(req.contains("User-Agent: NTRIP "), "en-tête User-Agent au format NTRIP", null);
    int ggaCount = req.split(java.util.regex.Pattern.quote(GGA), -1).length - 1;
    ok(ggaCount >= 1, "GGA envoyée au caster (intervalle 1 s pendant le test)", ggaCount + " envoi(s)");
    long bytes = (long) f("ntripBytes").get(p);
    ok(bytes > 0 && bytes <= fc.sent, "octets RTCM reçus et comptés", bytes + " / " + fc.sent + " émis");
    ok(events("ntrip").stream().anyMatch(e -> e.contains("state=connected")), "événement « connected »", null);
    ok(events("ntrip").stream().anyMatch(e -> e.contains("state=stopped")), "arrêt propre → « stopped »", null);

    System.out.println("\n── NTRIP : sans identifiants ──");
    GnssBridgePlugin p2 = new GnssBridgePlugin();
    FakeCaster fc2 = new FakeCaster("ICY 200 OK\r\n", true); fc2.start();
    runNtrip(p2, fc2.port(), "NEAR", "", "", 1200);
    String req2; synchronized(fc2.received){ req2 = fc2.received.toString(); }
    ok(req2.startsWith("GET /NEAR HTTP/1.0") && !req2.contains("Authorization"), "aucun en-tête Authorization si identifiant vide", null);

    System.out.println("\n── NTRIP : erreurs de réglage (pas de nouvel essai) ──");
    GnssBridgePlugin p3 = new GnssBridgePlugin();
    FakeCaster fc3 = new FakeCaster("SOURCETABLE 200 OK\r\nServer: fake\r\n\r\nENDSOURCETABLE\r\n", false); fc3.start();
    Plugin.EVENTS.clear();
    f("ntripWanted").set(p3, true);
    Method loop = m("ntripLoop", String.class, int.class, String.class, String.class, String.class, int.class);
    Thread t3 = new Thread(() -> { try { loop.invoke(p3, "127.0.0.1", fc3.port(), "XXXX", "", "", 10); } catch (Exception e) { e.printStackTrace(); } });
    t3.start(); t3.join(6000);
    ok(!t3.isAlive(), "point de montage inconnu → la boucle s'arrête d'elle-même", null);
    ok(events("ntrip").stream().anyMatch(e -> e.contains("XXXX") && e.contains("inconnu")), "message « Point de montage … inconnu »", null);
    ok(!(boolean) f("ntripWanted").get(p3), "aucune reconnexion programmée", null);

    GnssBridgePlugin p4 = new GnssBridgePlugin();
    FakeCaster fc4 = new FakeCaster("HTTP/1.0 401 Unauthorized\r\n\r\n", false); fc4.start();
    Plugin.EVENTS.clear();
    f("ntripWanted").set(p4, true);
    Thread t4 = new Thread(() -> { try { loop.invoke(p4, "127.0.0.1", fc4.port(), "LHER", "x", "y", 10); } catch (Exception e) { e.printStackTrace(); } });
    t4.start(); t4.join(6000);
    ok(!t4.isAlive() && events("ntrip").stream().anyMatch(e -> e.contains("Identifiants refusés")), "401 → « Identifiants refusés », arrêt", null);

    System.out.println("\n" + (fails == 0 ? "✅ " + n + " assertions vertes." : "❌ " + fails + "/" + n + " en échec."));
    System.exit(fails == 0 ? 0 : 1);
  }
}
