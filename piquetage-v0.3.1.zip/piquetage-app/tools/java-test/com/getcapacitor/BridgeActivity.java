package com.getcapacitor; import androidx.appcompat.app.AppCompatActivity; public class BridgeActivity extends AppCompatActivity {
 @Override protected void onCreate(android.os.Bundle b){} public void registerPlugin(Class<? extends Plugin> p){} }
