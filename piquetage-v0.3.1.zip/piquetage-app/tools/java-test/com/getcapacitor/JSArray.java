package com.getcapacitor; public class JSArray { public JSArray(){} public JSArray put(Object o){return this;} }
