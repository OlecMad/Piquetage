package com.getcapacitor; import android.content.Context; import androidx.appcompat.app.AppCompatActivity; import java.util.*; public class Plugin {
 public static final List<String[]> EVENTS = Collections.synchronizedList(new ArrayList<>());
 public void load(){} public Context getContext(){return null;} public AppCompatActivity getActivity(){return null;}
 protected void notifyListeners(String e, JSObject d){ EVENTS.add(new String[]{e, d.toString()}); } protected void notifyListeners(String e, JSObject d, boolean r){ notifyListeners(e,d); }
 public PermissionState getPermissionState(String alias){return PermissionState.GRANTED;}
 protected void requestPermissionForAlias(String alias, PluginCall call, String cb){} protected void handleOnDestroy(){} }
