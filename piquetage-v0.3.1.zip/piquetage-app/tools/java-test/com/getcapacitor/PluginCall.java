package com.getcapacitor; public class PluginCall {
 public String getString(String n){return null;} public String getString(String n, String d){return d;}
 public Integer getInt(String n){return null;} public Integer getInt(String n, Integer d){return d;}
 public Boolean getBoolean(String n){return null;} public Boolean getBoolean(String n, Boolean d){return d;}
 public void resolve(){} public void resolve(JSObject o){} public void reject(String m){} public void reject(String m, String code){} }
