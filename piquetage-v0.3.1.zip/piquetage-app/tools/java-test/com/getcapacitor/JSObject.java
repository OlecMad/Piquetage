package com.getcapacitor; import java.util.*; public class JSObject { public final Map<String,Object> m = new LinkedHashMap<>(); public JSObject(){}
 public JSObject put(String k, boolean v){m.put(k,v);return this;} public JSObject put(String k, int v){m.put(k,v);return this;} public JSObject put(String k, long v){m.put(k,v);return this;}
 public JSObject put(String k, double v){m.put(k,v);return this;} public JSObject put(String k, Object v){m.put(k,v);return this;} public JSObject put(String k, String v){m.put(k,v);return this;}
 public String toString(){return m.toString();} }
