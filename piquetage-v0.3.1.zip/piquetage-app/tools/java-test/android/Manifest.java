package android; public final class Manifest { public static final class permission { public static final String BLUETOOTH_CONNECT = "android.permission.BLUETOOTH_CONNECT"; } }
