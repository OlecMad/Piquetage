package android.bluetooth; import java.io.*; public final class BluetoothSocket implements Closeable {
 public static InputStream TEST_IN; public void connect() throws IOException {} public void close() throws IOException {}
 public InputStream getInputStream() throws IOException {return TEST_IN;} public OutputStream getOutputStream() throws IOException {return new ByteArrayOutputStream();} public boolean isConnected(){return true;} }
