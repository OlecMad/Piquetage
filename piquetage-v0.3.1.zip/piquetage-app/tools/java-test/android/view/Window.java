package android.view; public abstract class Window { public void addFlags(int f){} public void clearFlags(int f){} }
