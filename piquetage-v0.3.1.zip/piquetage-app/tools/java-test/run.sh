#!/usr/bin/env bash
# Banc d'essai du plugin natif GnssBridge, sans SDK Android.
# Compile le vrai GnssBridgePlugin.java contre des bouchons reproduisant les
# signatures de Capacitor 8.5.2 et de l'API Android, puis l'exécute contre
# un faux caster NTRIP local et un flux NMEA simulé (avec binaire UBX parasite).
set -euo pipefail
cd "$(dirname "$0")"
APP=../../android/app/src/main/java/fr/lileauvert/piquetage
rm -rf out && mkdir out
javac --release 21 -Xlint:all -encoding UTF-8 -d out $(find . -name "*.java" -not -path "./out/*") "$APP/GnssBridgePlugin.java"
java -Dstdout.encoding=UTF-8 -cp out TestBridge
