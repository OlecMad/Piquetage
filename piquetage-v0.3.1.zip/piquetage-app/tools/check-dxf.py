#!/usr/bin/env python3
"""Relecture indépendante des exports DXF et CSV avec ezdxf et le module csv de Python.

Usage : python3 tools/check-dxf.py DOSSIER   (produit par node tools/test-export.js)
"""
import csv
import glob
import os
import sys

import ezdxf
from ezdxf import recover, bbox as ezbbox

fails = 0


def ok(cond, label, detail=''):
    global fails
    print(('  ✓ ' if cond else '  ✗ ') + label + (('  → ' + str(detail)) if detail != '' else ''))
    if not cond:
        fails += 1


d = sys.argv[1] if len(sys.argv) > 1 else '/tmp/piq-export'
dxfs = sorted(glob.glob(os.path.join(d, '*.dxf')))
absolute = [f for f in dxfs if not f.endswith('_local.dxf')]
local = [f for f in dxfs if f.endswith('_local.dxf')]
ok(len(absolute) == 1 and len(local) == 1, 'un DXF absolu et un DXF local à relire', [os.path.basename(f) for f in dxfs])
path = absolute[0]

print('\n── DXF relu avec ezdxf ──')
doc = ezdxf.readfile(path)                       # lecture stricte
ok(doc.dxfversion == 'AC1009', 'version DXF R12', doc.dxfversion)
msp = doc.modelspace()
kinds = {}
for e in msp:
    kinds[e.dxftype()] = kinds.get(e.dxftype(), 0) + 1
ok(kinds.get('POINT') == 3 and kinds.get('POLYLINE') == 3 and kinds.get('CIRCLE') == 3, 'entités : 3 POINT, 3 CIRCLE, 3 POLYLINE', kinds)
circ = [(e.dxf.layer, round(e.dxf.radius, 3), tuple(round(c, 3) for c in e.dxf.center)) for e in msp.query('CIRCLE')]
ok(('PIQ_PT_SOL', 0.15, (555700.123, 6677600.456, 50.123)) in circ, 'cercle de 0,15 m centré sur P1', circ[0])
layers = sorted(l.dxf.name for l in doc.layers)
ok(all(n in layers for n in ['PIQ_PT_SOL', 'PIQ_PT_ANTENNE', 'PIQ_PT_SANS_Z', 'PIQ_NUM', 'PIQ_ALT', 'PIQ_TRACE_SOL', 'PIQ_TRACE_ANTENNE', 'PIQ_TRACE_2D', 'PIQ_INFO']), 'les neuf calques PIQ_ sont déclarés', [n for n in layers if not n.startswith('PIQ_')])

pts = {e.dxf.layer: tuple(round(c, 3) for c in e.dxf.location) for e in msp.query('POINT')}
ok(pts.get('PIQ_PT_SOL') == (555700.123, 6677600.456, 50.123), 'P1 (SOL) : X, Y, Z exacts', pts.get('PIQ_PT_SOL'))
ok(pts.get('PIQ_PT_ANTENNE') == (555710.0, 6677605.0, 53.5), 'P2 (ANTENNE) : X, Y, Z exacts', pts.get('PIQ_PT_ANTENNE'))
ok(pts.get('PIQ_PT_SANS_Z') == (555715.0, 6677606.0, 0.0), 'P3 (SANS_Z) : Z = 0', pts.get('PIQ_PT_SANS_Z'))

poly = {e.dxf.layer: e for e in msp.query('POLYLINE')}
sol = poly['PIQ_TRACE_SOL']
ok(sol.is_3d_polyline and len(sol.vertices) == 6, 'tracé SOL : polyligne 3D de 6 sommets', len(sol.vertices))
zs = [round(v.dxf.location[2], 3) for v in sol.vertices]
ok(zs == [50.0, 50.1, 50.2, 50.3, 50.4, 50.5], 'tracé SOL : altitudes', zs)
ant = poly['PIQ_TRACE_ANTENNE']
ok(ant.is_3d_polyline and len(ant.vertices) == 4 and round(ant.vertices[3].dxf.location[2], 3) == 60.6, 'tracé ANTENNE : 4 sommets, dernier Z = 60,6')
two = poly['PIQ_TRACE_2D']
ok(two.is_2d_polyline and len(two.vertices) == 3, 'tracé 2D : polyligne 2D de 3 sommets (altitudes mixtes)')
length = sum(((a.dxf.location[0] - b.dxf.location[0]) ** 2 + (a.dxf.location[1] - b.dxf.location[1]) ** 2) ** 0.5
             for a, b in zip(sol.vertices, list(sol.vertices)[1:]))
ok(abs(length - 5 * (1 + 0.25) ** 0.5) < 1e-6, 'longueur plane du tracé SOL', round(length, 3))

texts = [e.dxf.text for e in msp.query('TEXT')]
ok(all(t in texts for t in ['P1', 'P2', 'P3', '50.12', '53.50']), 'étiquettes P1–P3 et altitudes présentes')
ok(any('EPSG:2154' in t for t in texts) and any('Genille' in t for t in texts), 'cartouche : EPSG:2154, lieu', [t for t in texts if 'EPSG' in t][:1])
ok('0.00' not in texts, 'aucune altitude « 0.00 » inventée pour le point sans Z')

aud = doc.audit()
ok(not aud.has_errors, 'audit ezdxf : aucune erreur', [str(e) for e in aud.errors][:3])
doc2, auditor = recover.readfile(path)
ok(not auditor.has_errors, 'lecture tolérante (recover) : aucune erreur')

bb = ezbbox.extents(msp)
ok(555699 < bb.extmin.x and bb.extmax.x < 555733 and 6677590 < bb.extmin.y and bb.extmax.y < 6677630, 'emprise du dessin cohérente', (round(bb.extmin.x, 1), round(bb.extmax.y, 1)))

print('\n── DXF en repère local ──')
dl = ezdxf.readfile(local[0])
ml = dl.modelspace()
pl = {e.dxf.layer: tuple(round(c, 3) for c in e.dxf.location) for e in ml.query('POINT')}
ok(pl.get('PIQ_PT_SOL') == (0.123, 0.456, 50.123), 'P1 : (0,123 ; 0,456 ; 50,123) en repère local', pl.get('PIQ_PT_SOL'))
ok(abs(pl['PIQ_PT_ANTENNE'][0] - 10.0) < 1e-9 and abs(pl['PIQ_PT_ANTENNE'][1] - 5.0) < 1e-9, 'P2 : (10 ; 5) en repère local')
ok(any('REPERE LOCAL' in e.dxf.text and '555700' in e.dxf.text and '6677600' in e.dxf.text for e in ml.query('TEXT')), 'décalage de repère inscrit au cartouche')
ok(not dl.audit().has_errors, 'audit ezdxf : aucune erreur')
bl = ezbbox.extents(ml)
ok(bl.extmax.x < 100 and bl.extmax.y < 100, 'emprise locale de quelques dizaines de mètres', (round(bl.extmax.x, 1), round(bl.extmax.y, 1)))

print('\n── CSV relus avec le module csv ──')
for f in sorted(glob.glob(os.path.join(d, '*.csv'))):
    with open(f, encoding='utf-8-sig', newline='') as fh:
        rows = list(csv.reader(fh, delimiter=';'))
    widths = {len(r) for r in rows}
    ok(len(widths) == 1, os.path.basename(f) + ' : toutes les lignes ont le même nombre de colonnes', f'{len(rows) - 1} lignes × {widths.pop()} colonnes')
    if f.endswith('_points.csv'):
        h = rows[0]
        r1 = dict(zip(h, rows[1]))
        ok(float(r1['x_l93_m'].replace(',', '.')) == 555700.123 and r1['h_type'] == 'sol', 'points : P1 relu', (r1['x_l93_m'], r1['h_type']))
    with open(f, 'rb') as fh:
        raw = fh.read()
    ok(raw.startswith(b'\xef\xbb\xbf') and b'\r\n' in raw, '  BOM UTF-8 et CRLF')

print('\n' + ('✗ %d échec(s)' % fails if fails else '✓ relecture indépendante réussie'))
sys.exit(1 if fails else 0)
