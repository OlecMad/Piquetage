# Piquetage — relevé et implantation RTK

Application Android (Capacitor 8) de relevé et d'implantation, reliée à la canne RTK
(ArduSimple Calibrated Surveyor, ZED-F9P, Bluetooth Classic) et au réseau Centipede.
Calculs en **Lambert-93 (EPSG:2154)**, altitudes **NGF-IGN69** par la grille **RAF20**.

Version **0.3.1 — étape 3** : écran principal (disposition C) avec tracé et profil en direct,
points levés numérotés, projet enregistré sur l'appareil, **export CSV et DXF**. Le code RTK est repris de Diagnostic
Fluvial 1.6 (validé sur le terrain avec la canne) ; il est ici séparé de toute interface.

## Écran principal

Bandeau (projet, lieu, date, heure) · pastille de qualité RTK et précisions · un instrument en
gros chiffres (**Alt.** altitude NGF, **Points** levés, **Cap** de marche) · tracé en direct ·
profil altimétrique · barre **Point / Tracé / Impl. / Canne / Projet**. Sur tablette en paysage,
instruments à gauche, tracé et profil à droite.

| Choix | Détail |
|---|---|
| Repère | RGF93 / Lambert-93 (EPSG:2154), nord **du plan** en haut ; altitudes NGF-IGN69 (grille RAF20) |
| Altitude | « sol » si hauteur de canne et centre de phase sont saisis, sinon « antenne » ; jamais estimée |
| Distances | sur le plan Lambert-93 (distance de grille, pas de terrain) |
| Tracé | un sommet tous les 0,5 / 1 / 2 / 5 m (réglable, 1 m par défaut) ; seulement en RTK FIX si « FIX uniquement » |
| Cap de marche | calculé sur la marche récente (≥ 3 m), par rapport au nord du plan — pas le nord géographique ni une boussole |
| Écran | maintenu allumé pendant l'utilisation (FLAG_KEEP_SCREEN_ON) |
| Session | enregistrée dans le stockage local de l'appareil, relue au lancement |

## Export

| Fichier | Contenu |
|---|---|
| `<projet>_<AAAAMMJJ-HHMM>_points.csv` | un point par ligne : X/Y Lambert-93, H NGF et sa nature (sol / antenne), h ellipsoïdale, hauteur de canne, centre de phase, qualité, précision, époques, satellites, point de montage, récepteur, latitude/longitude RGF93 |
| `…_traces.csv` | un sommet par ligne : trace, rang, date, X, Y, H, nature, distance cumulée sur le plan |
| `….dxf` | DXF R12 ASCII : POINT entouré d'un CIRCLE de 0,15 m, numéros, altitudes, polylignes 3D, cartouche (EPSG:2154, NGF-IGN69) |
| `…_local.dxf` | même dessin en repère local (X, Y diminués d'une origine arrondie au 100 m, inscrite au cartouche) |

CSV : séparateur `;`, UTF-8 avec BOM, fins de ligne CRLF ; décimale **point** par défaut (QGIS), virgule au choix (Excel en français).
Une altitude absente n'est jamais remplacée par une valeur estimée : cellule vide en CSV ; en DXF, Z vaut 0
(imposé par le format) et l'objet est mis dans un calque `PIQ_PT_SANS_Z`. La nature de l'altitude se lit dans
les calques : `PIQ_PT_SOL`, `PIQ_PT_ANTENNE`, `PIQ_TRACE_SOL`, `PIQ_TRACE_ANTENNE` ; un tracé aux altitudes
mélangées ou absentes est exporté en 2D (`PIQ_TRACE_2D`). Un DXF ne porte pas de système de coordonnées :
il est indiqué dans le cartouche. Les fichiers portent un nom horodaté, sans écrasement.

DXF et logiciels : le R12 ASCII est la version de DXF la mieux prise en charge entre logiciels (source : DANS, archivage des formats CAO). Vectorworks ne lit pas d'unités dans un DXF antérieur à 2000 : choisir le mètre à l'import. Compatibilité avec DesignCAD 10 : non vérifiée (aucune source trouvée pour cette version) ; à tester sur votre poste.

Pas encore là : import `.gpkg` (étape 4), implantation (5), fond IGN (6), boussole par capteur et météo (7).

## Contenu

| Élément | Rôle | Origine |
|---|---|---|
| `android/…/GnssBridgePlugin.java` | Bluetooth Classic SPP, client NTRIP v1 | repris tel quel (package renommé) |
| `android/…/MainActivity`, `PiqApp`, `CrashReporter`, `CrashActivity` | pont Capacitor, rapport de plantage, écran allumé | repris et adapté |
| `www/geo.js`, `www/raf20.js` | NMEA, Lambert-93, altitude NGF | repris tels quels |
| `www/rtk-core.js` | liaison, NTRIP, époques, levé moyenné — sans interface | extrait de `rtk.js` |
| `www/session.js` | tracés, points, statistiques, cap | nouveau |
| `www/views.js` | dessin du tracé et du profil (canvas) | nouveau |
| `www/export.js` | CSV des points, CSV des tracés, DXF R12 | nouveau |
| `www/diag.js`, `www/app.js`, `www/index.html` | panneau Canne, écran principal | nouveau |
| `tools/make_icons.py` | logo et icônes Android | nouveau |

Permissions : Internet (NTRIP), Bluetooth, stockage pour les exports. Plus de micro, de
caméra ni de localisation : la position vient uniquement de la canne.

## Vérifications

| Commande | Ce qu'elle contrôle |
|---|---|
| `node tools/test-geo.js` | Lambert-93, RAF20, NMEA (32 assertions) |
| `node tools/test-rtk-core.js` | noyau RTK avec faux plugin et horloge simulée (43) |
| `node tools/test-session.js` | tracés, points, profil, cap, relecture (47) |
| `node tools/test-export.js` | CSV et DXF : colonnes, calques, cercles, repère local, altitudes absentes, échappements (46) |
| `python3 tools/check-dxf.py /tmp/piq-export` | relecture indépendante du DXF (ezdxf) et des CSV (csv), après `test-export.js` |
| `node tools/verify-screen.js` | écran principal dans Chromium : marche simulée, export, téléphone et tablette (65) |
| `python3 tools/check-android.py .` | cohérence du projet Android avant Gradle |
| `tools/java-test/run.sh` | plugin GnssBridge contre un faux caster NTRIP (17) |

Ces vérifications ne remplacent pas l'essai avec la vraie canne sur chaque appareil.

## Compilation

Voir `PROCEDURE_INSTALLATION.md` : dépôt GitHub, workflow `android.yml`, artefact
`piquetage-debug`.
