package com.hoho.android.usbserial;

/**
 * Remplace la classe générée par le module Gradle d'origine de la bibliothèque : ici les sources de
 * usb-serial-for-android sont compilées dans l'application, qui ne la génère pas. DEBUG ne sert
 * qu'à une assertion de développement sur les indicateurs de vitesse.
 */
public final class BuildConfig {
    public static final boolean DEBUG = false;
    private BuildConfig() { }
}
