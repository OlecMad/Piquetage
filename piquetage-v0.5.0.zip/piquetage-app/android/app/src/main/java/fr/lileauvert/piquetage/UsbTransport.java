package fr.lileauvert.piquetage;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;

import com.hoho.android.usbserial.driver.CdcAcmSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;

import java.io.IOException;
import java.util.Locale;

/**
 * Liaison USB (câble OTG) avec le récepteur : USB natif du ZED-F9P (CDC-ACM) ou pont série FTDI, CP210x,
 * CH34x, Prolific, via la bibliothèque usb-serial-for-android. La permission USB doit avoir été obtenue
 * avant l'appel.
 */
final class UsbTransport implements Transport {

    private final UsbSerialPort port;
    private final LinkListener listener;
    private final String name, info;
    private final Object writeLock = new Object();
    private volatile boolean closed = false;
    private Thread reader;

    private UsbTransport(UsbSerialPort port, LinkListener listener, String name, String info) {
        this.port = port; this.listener = listener; this.name = name; this.info = info;
    }

    /** Identifiant stable d'un appareil USB : « vvvv:pppp » en hexadécimal. */
    static String idOf(UsbDevice d) {
        return String.format(Locale.ROOT, "%04x:%04x", d.getVendorId(), d.getProductId());
    }

    /** Pilote reconnu pour cet appareil, ou null. */
    static UsbSerialDriver probe(UsbDevice d) {
        return UsbSerialProber.getDefaultProber().probeDevice(d);
    }

    static UsbTransport open(UsbManager um, UsbDevice dev, int baud, LinkListener listener) throws IOException {
        UsbSerialDriver drv = probe(dev);
        if (drv == null) throw new IOException("Appareil USB " + idOf(dev) + " non reconnu comme port série (ni CDC-ACM, ni FTDI, CP210x, CH34x, Prolific)");
        if (drv.getPorts().isEmpty()) throw new IOException("Aucun port série sur l'appareil USB " + idOf(dev));
        UsbDeviceConnection conn = um.openDevice(dev);
        if (conn == null) throw new IOException("Ouverture de l'appareil USB refusée (permission ou câble)");
        UsbSerialPort p = drv.getPorts().get(0);
        try {
            p.open(conn);
            try {
                p.setParameters(baud, UsbSerialPort.DATABITS_8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            } catch (UnsupportedOperationException ignored) {
                // certains pilotes CDC n'acceptent pas le réglage : sans effet sur l'USB natif
            }
            if (drv instanceof CdcAcmSerialDriver) {
                try { p.setDTR(true); } catch (IOException | UnsupportedOperationException ignored) { }
            }
        } catch (IOException e) {
            try { p.close(); } catch (IOException ignored) { }
            conn.close();
            throw e;
        }
        String chip = drv.getClass().getSimpleName().replace("SerialDriver", "");
        String label = dev.getProductName() != null ? dev.getProductName() : "USB " + idOf(dev);
        UsbTransport t = new UsbTransport(p, listener, label, "USB · " + chip + " · " + idOf(dev) + " · " + baud + " bauds");
        t.reader = new Thread(t::readLoop, "usb-read");
        t.reader.setDaemon(true);
        t.reader.start();
        return t;
    }

    private void readLoop() {
        byte[] buf = new byte[4096];
        try {
            while (!closed) {
                int n = port.read(buf, 250);
                if (n < 0) throw new IOException("fin de flux");
                if (n > 0) listener.onData(this, buf, 0, n);
            }
        } catch (IOException e) {
            if (!closed) {
                close();
                listener.onLost(this, "Liaison USB perdue (" + (e.getMessage() != null ? e.getMessage() : "câble débranché ?") + ")");
            }
        }
    }

    @Override public void write(byte[] data, int len) throws IOException {
        if (closed) throw new IOException("Liaison USB fermée");
        synchronized (writeLock) { port.write(data, len, 1000); }
    }

    @Override public void close() {
        if (closed) return;
        closed = true;
        try { port.close(); } catch (IOException ignored) { }
    }

    @Override public String kind() { return "usb"; }
    @Override public String name() { return name; }
    @Override public String info() { return info; }
}
