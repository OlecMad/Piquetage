package fr.lileauvert.piquetage;

/** Retour d'une liaison vers le plugin. Appelé depuis les fils propres à chaque liaison. */
interface LinkListener {
    /** Octets reçus du récepteur. */
    void onData(Transport from, byte[] buf, int off, int len);

    /** La liaison s'est interrompue (câble débranché, récepteur éteint, hors de portée…). */
    void onLost(Transport from, String message);
}
