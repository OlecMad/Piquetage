package fr.lileauvert.piquetage;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.UUID;

/** Liaison Bluetooth Classic (profil série SPP) — code repris de Diagnostic Fluvial 1.6. */
@SuppressLint("MissingPermission")
final class ClassicTransport implements Transport {

    /** UUID normalisé du profil série Bluetooth (SPP). */
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final BluetoothAdapter adapter;
    private final BluetoothDevice dev;
    private final LinkListener listener;
    private final Object writeLock = new Object();
    private volatile BluetoothSocket socket;
    private volatile OutputStream out;
    private volatile boolean closed = false;
    private final String name;

    ClassicTransport(BluetoothAdapter adapter, BluetoothDevice dev, LinkListener listener) {
        this.adapter = adapter;
        this.dev = dev;
        this.listener = listener;
        String n = dev.getName();
        this.name = n != null ? n : dev.getAddress();
    }

    /** Ouvre le socket (bloquant) puis démarre la lecture. */
    void connect() throws IOException {
        try { adapter.cancelDiscovery(); } catch (SecurityException ignored) { }
        BluetoothSocket s = null;
        String lastError = "";
        // 1. socket sécurisé standard ; 2. socket non sécurisé (modules HC-05 et certains ponts série) ;
        // 3. canal RFCOMM 1 par réflexion, contournement connu pour les piles qui ne publient pas le SDP.
        for (int attempt = 0; attempt < 3 && s == null; attempt++) {
            BluetoothSocket candidate = null;
            try {
                if (attempt == 0) candidate = dev.createRfcommSocketToServiceRecord(SPP_UUID);
                else if (attempt == 1) candidate = dev.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                else {
                    Method m = dev.getClass().getMethod("createRfcommSocket", int.class);
                    candidate = (BluetoothSocket) m.invoke(dev, 1);
                }
                candidate.connect();
                s = candidate;
            } catch (Exception e) {
                lastError = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                closeQuietly(candidate);
            }
        }
        if (s == null) throw new IOException("Connexion impossible : " + lastError);
        synchronized (writeLock) { out = s.getOutputStream(); }
        socket = s;
        final BluetoothSocket sock = s;
        Thread t = new Thread(() -> readLoop(sock), "classic-read");
        t.setDaemon(true);
        t.start();
    }

    private void readLoop(BluetoothSocket sock) {
        byte[] buf = new byte[4096];
        try {
            InputStream in = sock.getInputStream();
            while (!closed) {
                int n = in.read(buf);
                if (n < 0) break;
                listener.onData(this, buf, 0, n);
            }
        } catch (IOException ignored) {
            // liaison coupée : traitée ci-dessous
        }
        if (!closed) listener.onLost(this, "Liaison perdue avec " + name);
    }

    @Override public void write(byte[] data, int len) throws IOException {
        synchronized (writeLock) {
            OutputStream o = out;
            if (o == null) return;
            o.write(data, 0, len);
            o.flush();
        }
    }

    @Override public void close() {
        if (closed) return;
        closed = true;
        synchronized (writeLock) { out = null; }
        closeQuietly(socket);
        socket = null;
    }

    private static void closeQuietly(BluetoothSocket s) {
        if (s == null) return;
        try { s.close(); } catch (IOException ignored) { }
    }

    @Override public String kind() { return "classic"; }
    @Override public String name() { return name; }
    @Override public String info() { return "Bluetooth Classic (SPP)"; }
}
