package fr.lileauvert.piquetage;

/**
 * Découpe un flux d'octets en lignes NMEA. Le récepteur peut mêler des messages
 * binaires (UBX, RTCM) au NMEA : une ligne dépassant 256 caractères est abandonnée, un « $ » redémarre la
 * ligne (le binaire qui précède est jeté), et seules les lignes commençant par « $ » sont transmises.
 */
final class NmeaSplitter {

    interface LineListener { void onLine(String line); }

    private static final int MAX_LINE = 256;
    private final StringBuilder line = new StringBuilder(128);
    private final LineListener listener;

    NmeaSplitter(LineListener listener) { this.listener = listener; }

    /** Alimente le découpeur ; une même instance ne doit être alimentée que par un seul fil à la fois. */
    synchronized void feed(byte[] buf, int off, int len) {
        for (int i = off; i < off + len; i++) {
            char c = (char) (buf[i] & 0xFF);
            if (c == '\n') {
                String l = line.toString().trim();
                line.setLength(0);
                if (l.length() >= 7 && l.charAt(0) == '$') listener.onLine(l);
            } else if (c == '$') {
                // Un « $ » ouvre toujours une nouvelle trame : si des octets binaires (UBX, RTCM) ou le début d'une
                // trame tronquée précèdent, ils sont abandonnés ; la trame NMEA qui suit n'est pas perdue.
                line.setLength(0);
                line.append(c);
            } else if (c != '\r') {
                if (line.length() < MAX_LINE) line.append(c); else line.setLength(0);
            }
        }
    }

    synchronized void reset() { line.setLength(0); }
}
