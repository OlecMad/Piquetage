package fr.lileauvert.piquetage;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.ParcelUuid;
import android.util.Base64;
import android.view.WindowManager;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.hoho.android.usbserial.driver.UsbSerialDriver;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * Pont entre l'application et le récepteur GNSS RTK.
 *
 * Trois liaisons possibles vers le récepteur, au choix :
 *   · « ble »     Bluetooth LE (GATT, port série d'un module BLE) ;
 *   · « usb »     câble USB-OTG (USB natif du ZED-F9P ou pont FTDI / CP210x / CH34x) ;
 *   · « classic » Bluetooth Classic SPP (repris de Diagnostic Fluvial).
 *
 * Deux flux indépendants :
 *   1. liaison : lecture des trames NMEA du récepteur, transmises à la page (événement « nmea », GGA, GST, RMC) ;
 *   2. NTRIP (facultatif) : client NTRIP v1 vers le caster Centipede ; les corrections RTCM3 sont écrites
 *      directement sur la liaison, sans passer par la page. La dernière GGA est renvoyée au caster.
 */
@CapacitorPlugin(
    name = "GnssBridge",
    permissions = {
        @Permission(alias = "bluetooth", strings = { Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN }),
        @Permission(alias = "location", strings = { Manifest.permission.ACCESS_FINE_LOCATION })
    }
)
public class GnssBridgePlugin extends Plugin {

    private static final String ACTION_USB_PERMISSION = "fr.lileauvert.piquetage.USB_PERMISSION";
    private static final Pattern RTK_NAME = Pattern.compile("(rtk|gnss|gps|zed|u-?blox|simplertk|ardusimple|f9p|surveyor)", Pattern.CASE_INSENSITIVE);

    private final ExecutorService exec = Executors.newCachedThreadPool();

    // --- liaison ---
    private volatile Transport link;
    private volatile String linkAddress = "";
    private volatile String lastGga = null;
    private volatile long nmeaLines = 0;
    private final NmeaSplitter splitter = new NmeaSplitter(this::handleLine);

    private final LinkListener linkListener = new LinkListener() {
        @Override public void onData(Transport from, byte[] buf, int off, int len) {
            if (from == link) splitter.feed(buf, off, len);
        }
        @Override public void onLost(Transport from, String message) {
            if (from != link) return;
            closeLink(false);
            emitLink("disconnected", message, from.kind());
        }
    };

    // --- NTRIP ---
    private volatile NtripClient ntrip;
    private volatile String ntripState = "stopped";

    // --- USB ---
    private PluginCall usbPendingCall;
    private boolean usbReceiverRegistered = false;
    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (!ACTION_USB_PERMISSION.equals(i.getAction())) return;
            final PluginCall call;
            synchronized (GnssBridgePlugin.this) { call = usbPendingCall; usbPendingCall = null; }
            if (call == null) return;
            if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) exec.execute(() -> doConnectUsb(call));
            else call.reject("Permission USB refusée : le câble est reconnu mais l'application n'a pas le droit de l'ouvrir", "PERMISSION_DENIED");
        }
    };

    /* ================================================================
       Permissions
       Android ≥ 12 : BLUETOOTH_CONNECT + BLUETOOTH_SCAN (alias « bluetooth »).
       Android ≤ 11 : BLUETOOTH / BLUETOOTH_ADMIN accordées à l'installation ; la recherche BLE exige
       en plus la localisation précise (alias « location ») et la localisation activée dans le système.
       ================================================================ */

    private boolean needsBtPermission() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && getPermissionState("bluetooth") != PermissionState.GRANTED;
    }

    private boolean needsScanPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) return getPermissionState("bluetooth") != PermissionState.GRANTED;
        return getPermissionState("location") != PermissionState.GRANTED;
    }

    private String scanAlias() { return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? "bluetooth" : "location"; }

    private BluetoothAdapter adapter() {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        return bm != null ? bm.getAdapter() : null;
    }

    private boolean btReady(PluginCall call) {
        BluetoothAdapter ad = adapter();
        if (ad == null) { call.reject("Aucun Bluetooth sur cet appareil", "NO_BLUETOOTH"); return false; }
        if (!ad.isEnabled()) { call.reject("Le Bluetooth est désactivé", "BLUETOOTH_OFF"); return false; }
        return true;
    }

    /* ================================================================
       Appareils : Bluetooth Classic appairés, recherche BLE, USB
       ================================================================ */

    @PluginMethod
    public void listDevices(PluginCall call) {
        if (needsBtPermission()) { requestPermissionForAlias("bluetooth", call, "listDevicesPermission"); return; }
        doListDevices(call);
    }

    @PermissionCallback
    private void listDevicesPermission(PluginCall call) {
        if (!needsBtPermission()) doListDevices(call);
        else call.reject("Permission Bluetooth refusée", "PERMISSION_DENIED");
    }

    @SuppressLint("MissingPermission")
    private void doListDevices(PluginCall call) {
        if (!btReady(call)) return;
        JSArray list = new JSArray();
        Set<BluetoothDevice> bonded = adapter().getBondedDevices();
        if (bonded != null) {
            for (BluetoothDevice d : bonded) {
                JSObject o = new JSObject();
                String name = d.getName();
                o.put("name", name != null ? name : "(sans nom)");
                o.put("address", d.getAddress());
                o.put("type", d.getType());   // 1 Classic, 2 LE, 3 double
                list.put(o);
            }
        }
        JSObject res = new JSObject();
        res.put("devices", list);
        call.resolve(res);
    }

    /** Recherche d'appareils BLE à proximité (quelques secondes). */
    @PluginMethod
    public void scanBle(PluginCall call) {
        if (needsScanPermission()) { requestPermissionForAlias(scanAlias(), call, "scanPermission"); return; }
        doScan(call);
    }

    @PermissionCallback
    private void scanPermission(PluginCall call) {
        if (!needsScanPermission()) doScan(call);
        else call.reject(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            ? "Permission « appareils à proximité » refusée"
            : "Permission de localisation refusée (obligatoire pour la recherche BLE sous Android 11 et moins)", "PERMISSION_DENIED");
    }

    @SuppressLint("MissingPermission")
    private void doScan(final PluginCall call) {
        if (!btReady(call)) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            LocationManager lm = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
            if (lm != null && !lm.isLocationEnabled()) {
                call.reject("Activez la localisation d'Android : sous Android 11 et moins, la recherche BLE ne renvoie rien sans elle", "LOCATION_OFF");
                return;
            }
        }
        final BluetoothLeScanner scanner = adapter().getBluetoothLeScanner();
        if (scanner == null) { call.reject("Recherche BLE indisponible (Bluetooth éteint ?)", "NO_BLE"); return; }
        int req = call.getInt("duration", 6000);
        final long duration = Math.max(2000, Math.min(15000, req));

        final Map<String, JSObject> found = Collections.synchronizedMap(new LinkedHashMap<String, JSObject>());
        final int[] failure = { 0 };
        final ScanCallback cb = new ScanCallback() {
            @Override public void onScanResult(int callbackType, ScanResult r) {
                BluetoothDevice d = r.getDevice();
                ScanRecord rec = r.getScanRecord();
                String name = rec != null ? rec.getDeviceName() : null;
                if (name == null) name = d.getName();
                JSObject o = new JSObject();
                o.put("name", name != null ? name : "(sans nom)");
                o.put("address", d.getAddress());
                o.put("rssi", r.getRssi());
                o.put("rtk", name != null && RTK_NAME.matcher(name).find());
                JSArray uu = new JSArray();
                if (rec != null && rec.getServiceUuids() != null) {
                    for (ParcelUuid u : rec.getServiceUuids()) { if (uu.length() < 4) uu.put(u.getUuid().toString()); }
                }
                o.put("services", uu);
                found.put(d.getAddress(), o);
            }
            @Override public void onScanFailed(int errorCode) { failure[0] = errorCode; }
        };
        ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        try {
            scanner.startScan(null, settings, cb);
        } catch (SecurityException e) {
            call.reject("Permission refusée pour la recherche BLE", "PERMISSION_DENIED");
            return;
        }
        exec.execute(() -> {
            try { Thread.sleep(duration); } catch (InterruptedException ignored) { }
            try { scanner.stopScan(cb); } catch (RuntimeException ignored) { }
            if (failure[0] != 0 && found.isEmpty()) {
                call.reject("Échec de la recherche BLE (code " + failure[0] + ")" + (failure[0] == 2 ? " : trop de recherches rapprochées, attendre 30 s" : ""), "SCAN_FAILED");
                return;
            }
            List<JSObject> list;
            synchronized (found) { list = new ArrayList<>(found.values()); }
            Collections.sort(list, new Comparator<JSObject>() {
                @Override public int compare(JSObject a, JSObject b) {
                    boolean ra = a.optBoolean("rtk", false), rb = b.optBoolean("rtk", false);
                    if (ra != rb) return ra ? -1 : 1;
                    return Integer.compare(b.optInt("rssi", -127), a.optInt("rssi", -127));
                }
            });
            JSArray arr = new JSArray();
            for (JSObject o : list) arr.put(o);
            JSObject res = new JSObject();
            res.put("devices", arr);
            call.resolve(res);
        });
    }

    private UsbManager usbManager() { return (UsbManager) getContext().getSystemService(Context.USB_SERVICE); }

    /** Appareils USB branchés, avec l'indication du pilote reconnu. */
    @PluginMethod
    public void listUsb(PluginCall call) {
        UsbManager um = usbManager();
        if (um == null) { call.reject("Cet appareil n'a pas de port USB hôte", "NO_USB"); return; }
        JSArray list = new JSArray();
        for (UsbDevice d : um.getDeviceList().values()) {
            JSObject o = new JSObject();
            String name = null;
            try { name = d.getProductName(); } catch (SecurityException ignored) { }
            UsbSerialDriver drv = UsbTransport.probe(d);
            o.put("id", UsbTransport.idOf(d));
            o.put("name", name != null ? name : "Appareil USB");
            o.put("manufacturer", safeManufacturer(d));
            o.put("supported", drv != null);
            o.put("chip", drv != null ? drv.getClass().getSimpleName().replace("SerialDriver", "") : "");
            o.put("hasPermission", um.hasPermission(d));
            list.put(o);
        }
        JSObject res = new JSObject();
        res.put("devices", list);
        call.resolve(res);
    }

    private static String safeManufacturer(UsbDevice d) {
        try { String m = d.getManufacturerName(); return m != null ? m : ""; } catch (SecurityException e) { return ""; }
    }

    /* ================================================================
       Connexion
       ================================================================ */

    @PluginMethod
    public void connect(PluginCall call) {
        String t = call.getString("transport", "classic");
        if (!"usb".equals(t) && needsBtPermission()) { requestPermissionForAlias("bluetooth", call, "connectPermission"); return; }
        doConnect(call);
    }

    @PermissionCallback
    private void connectPermission(PluginCall call) {
        if (!needsBtPermission()) doConnect(call);
        else call.reject("Permission Bluetooth refusée", "PERMISSION_DENIED");
    }

    private void doConnect(final PluginCall call) {
        final String t = call.getString("transport", "classic");
        if ("usb".equals(t)) { prepareUsb(call); return; }
        if (!"ble".equals(t) && !"classic".equals(t)) { call.reject("Liaison inconnue : " + t, "BAD_ARGUMENT"); return; }
        final String address = call.getString("address");
        if (address == null || address.isEmpty()) { call.reject("Adresse Bluetooth manquante", "BAD_ARGUMENT"); return; }
        if (!btReady(call)) return;
        final BluetoothAdapter ad = adapter();

        closeLink(false);
        emitLink("connecting", address, t);

        exec.execute(() -> {
            BluetoothDevice dev;
            try {
                dev = ad.getRemoteDevice(address);
            } catch (IllegalArgumentException e) {
                emitLink("error", "Adresse invalide", t);
                call.reject("Adresse Bluetooth invalide : " + address, "BAD_ARGUMENT");
                return;
            }
            Transport tr;
            try {
                if ("ble".equals(t)) {
                    BleTransport b = new BleTransport(getContext(), dev, linkListener);
                    link = b;
                    b.connect(15000);
                    tr = b;
                } else {
                    ClassicTransport c = new ClassicTransport(ad, dev, linkListener);
                    link = c;
                    c.connect();
                    tr = c;
                }
            } catch (IOException e) {
                Transport failed = link;
                link = null;
                if (failed != null) failed.close();
                emitLink("error", e.getMessage(), t);
                call.reject(e.getMessage(), "CONNECT_FAILED");
                return;
            }
            finishConnect(call, tr, address);
        });
    }

    private void prepareUsb(final PluginCall call) {
        final String id = call.getString("usbId");
        if (id == null || id.isEmpty()) { call.reject("Appareil USB non choisi", "BAD_ARGUMENT"); return; }
        UsbManager um = usbManager();
        if (um == null) { call.reject("Cet appareil n'a pas de port USB hôte", "NO_USB"); return; }
        UsbDevice target = null;
        for (UsbDevice d : um.getDeviceList().values()) {
            if (UsbTransport.idOf(d).equalsIgnoreCase(id)) { target = d; break; }
        }
        if (target == null) { call.reject("Appareil USB " + id + " introuvable : vérifier le câble OTG et l'alimentation du récepteur", "NOT_FOUND"); return; }
        closeLink(false);
        emitLink("connecting", id, "usb");
        if (um.hasPermission(target)) { exec.execute(() -> doConnectUsb(call)); return; }
        registerUsbReceiver();
        synchronized (this) { usbPendingCall = call; }
        Intent intent = new Intent(ACTION_USB_PERMISSION);
        intent.setPackage(getContext().getPackageName());
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_MUTABLE : 0;
        um.requestPermission(target, PendingIntent.getBroadcast(getContext(), 0, intent, flags));
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private void registerUsbReceiver() {
        if (usbReceiverRegistered) return;
        IntentFilter f = new IntentFilter(ACTION_USB_PERMISSION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) getContext().registerReceiver(usbReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(usbReceiver, f);
        usbReceiverRegistered = true;
    }

    private void doConnectUsb(PluginCall call) {
        final String id = call.getString("usbId");
        int baud = call.getInt("baud", 115200);
        UsbManager um = usbManager();
        UsbDevice target = null;
        if (um != null) {
            for (UsbDevice d : um.getDeviceList().values()) {
                if (UsbTransport.idOf(d).equalsIgnoreCase(id)) { target = d; break; }
            }
        }
        if (target == null) { emitLink("error", "Appareil USB introuvable", "usb"); call.reject("Appareil USB introuvable", "NOT_FOUND"); return; }
        try {
            UsbTransport u = UsbTransport.open(um, target, baud, linkListener);
            link = u;
            finishConnect(call, u, id);
        } catch (IOException e) {
            emitLink("error", e.getMessage(), "usb");
            call.reject(e.getMessage(), "CONNECT_FAILED");
        }
    }

    private void finishConnect(PluginCall call, Transport tr, String address) {
        linkAddress = address;
        nmeaLines = 0;
        splitter.reset();
        keepScreenOn(true);
        emitLink("connected", tr.name(), tr.kind());
        JSObject res = new JSObject();
        res.put("name", tr.name());
        res.put("address", address);
        res.put("transport", tr.kind());
        res.put("info", tr.info());
        call.resolve(res);
    }

    private void handleLine(String l) {
        String type = l.substring(3, 6);
        if ("GGA".equals(type)) lastGga = l;
        if ("GGA".equals(type) || "GST".equals(type) || "RMC".equals(type)) {
            nmeaLines++;
            JSObject o = new JSObject();
            o.put("line", l);
            o.put("t", System.currentTimeMillis());
            notifyListeners("nmea", o);
        }
    }

    /** Écrit des corrections vers le récepteur. */
    private void writeToReceiver(byte[] data, int len) {
        Transport t = link;
        if (t == null) return;
        try {
            t.write(data, len);
        } catch (IOException ignored) {
            // la lecture détectera la coupure
        }
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        closeLink(true);
        call.resolve();
    }

    private void closeLink(boolean notify) {
        Transport t = link;
        link = null;
        splitter.reset();
        if (t != null) t.close();
        keepScreenOn(false);
        if (notify && t != null) emitLink("disconnected", "Déconnecté", t.kind());
    }

    /* ================================================================
       Client NTRIP v1
       ================================================================ */

    @PluginMethod
    public void startNtrip(PluginCall call) {
        final String mount = call.getString("mountpoint", "").trim();
        if (mount.isEmpty()) { call.reject("Point de montage manquant", "BAD_ARGUMENT"); return; }
        final String user = call.getString("user", "");
        final String pass = call.getString("password", "");

        stopNtripInternal();
        NtripClient.Config cfg = new NtripClient.Config();
        cfg.host = call.getString("host", "crtk.net");
        cfg.port = call.getInt("port", 2101);
        cfg.mount = mount;
        cfg.ggaIntervalS = Math.max(1, call.getInt("ggaInterval", 10));
        if (user != null && !user.isEmpty()) {
            cfg.basicAuth = "Basic " + Base64.encodeToString((user + ":" + (pass != null ? pass : "")).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        }
        NtripClient c = new NtripClient(cfg, () -> lastGga, new NtripClient.Listener() {
            @Override public void onState(String state, String message) { emitNtrip(state, message); }
            @Override public void onData(byte[] buf, int len) { writeToReceiver(buf, len); }
            @Override public void onBytes(long total) {
                JSObject o = new JSObject();
                o.put("state", "connected");
                o.put("bytes", total);
                o.put("mountpoint", mount);
                notifyListeners("ntrip", o);
            }
        });
        ntrip = c;
        c.start();
        call.resolve();
    }

    @PluginMethod
    public void stopNtrip(PluginCall call) {
        stopNtripInternal();
        call.resolve();
    }

    private void stopNtripInternal() {
        NtripClient c = ntrip;
        ntrip = null;
        if (c != null) c.stop();
    }

    /* ================================================================
       État et utilitaires
       ================================================================ */

    @PluginMethod
    public void getStatus(PluginCall call) {
        Transport t = link;
        NtripClient c = ntrip;
        JSObject o = new JSObject();
        o.put("bluetooth", t != null ? "connected" : "disconnected");
        o.put("transport", t != null ? t.kind() : "");
        o.put("name", t != null ? t.name() : "");
        o.put("address", linkAddress);
        o.put("info", t != null ? t.info() : "");
        o.put("nmeaLines", nmeaLines);
        o.put("ntrip", ntripState);
        o.put("ntripBytes", c != null ? c.bytes() : 0);
        o.put("rtcmAgeMs", c != null && c.lastDataAt() > 0 ? System.currentTimeMillis() - c.lastDataAt() : -1);
        call.resolve(o);
    }

    private void emitLink(String state, String message, String transport) {
        JSObject o = new JSObject();
        o.put("state", state);
        o.put("message", message);
        o.put("transport", transport);
        Transport t = link;
        if ("connected".equals(state) && t != null) o.put("info", t.info());
        notifyListeners("bluetooth", o);
    }

    private void emitNtrip(String state, String message) {
        ntripState = state;
        NtripClient c = ntrip;
        JSObject o = new JSObject();
        o.put("state", state);
        o.put("message", message);
        o.put("bytes", c != null ? c.bytes() : 0);
        notifyListeners("ntrip", o);
    }

    /** Écran allumé tant que le récepteur est relié : un levé ne doit pas s'interrompre en veille. */
    private void keepScreenOn(final boolean on) {
        if (getActivity() == null) return;
        getActivity().runOnUiThread(() -> {
            if (on) getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    @Override
    protected void handleOnDestroy() {
        stopNtripInternal();
        closeLink(false);
        if (usbReceiverRegistered) {
            try { getContext().unregisterReceiver(usbReceiver); } catch (IllegalArgumentException ignored) { }
            usbReceiverRegistered = false;
        }
        exec.shutdownNow();
    }

    @SuppressWarnings("unused")
    private static String lower(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT); }
}
