package fr.lileauvert.piquetage;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Client NTRIP v1 (réseau Centipede : crtk.net:2101). Reçoit les corrections RTCM3 du caster et les
 * remet à l'appelant ; renvoie périodiquement la dernière position GGA, ce que le caster exige.
 * Reconnexion automatique après une coupure ; arrêt définitif sur une erreur de réglage
 * (point de montage inconnu, identifiants refusés, NTRIP v2). Classe sans dépendance Android.
 */
final class NtripClient {

    interface Listener {
        /** connecting, connected, reconnecting, error, stopped. */
        void onState(String state, String message);
        /** Octets de correction à transmettre au récepteur. */
        void onData(byte[] buf, int len);
        /** Compteur d'octets reçus, environ toutes les 2 s. */
        void onBytes(long total);
    }

    interface GgaSource { String lastGga(); }

    static final class Config {
        String host = "crtk.net";
        int port = 2101;
        String mount = "";
        /** Valeur « Basic xxx » déjà encodée, ou null pour une connexion sans identifiants. */
        String basicAuth = null;
        int ggaIntervalS = 10;
        String userAgent = "NTRIP Piquetage/0.5";
        long retryDelayMs = 5000;
    }

    private final Config cfg;
    private final GgaSource gga;
    private final Listener out;
    private volatile boolean wanted = false;
    private volatile Socket socket;
    private volatile long bytes = 0;
    private volatile long lastDataAt = 0;
    private Thread thread;

    NtripClient(Config cfg, GgaSource gga, Listener out) { this.cfg = cfg; this.gga = gga; this.out = out; }

    synchronized void start() {
        if (wanted) return;
        wanted = true;
        bytes = 0; lastDataAt = 0;
        thread = new Thread(this::loop, "ntrip");
        thread.setDaemon(true);
        thread.start();
    }

    synchronized void stop() {
        wanted = false;
        closeQuietly(socket);
        socket = null;
        Thread t = thread;
        thread = null;
        if (t != null) t.interrupt();
    }

    boolean isRunning() { return wanted; }
    long bytes() { return bytes; }
    long lastDataAt() { return lastDataAt; }

    /** Attend la fin du fil (tests). */
    boolean join(long ms) throws InterruptedException {
        Thread t;
        synchronized (this) { t = thread; }
        if (t == null) return true;
        t.join(ms);
        return !t.isAlive();
    }

    private void loop() {
        while (wanted) {
            Socket sock = new Socket();
            try {
                out.onState("connecting", cfg.host + ":" + cfg.port + "/" + cfg.mount);
                sock.connect(new InetSocketAddress(cfg.host, cfg.port), 10000);
                sock.setSoTimeout(2000);
                socket = sock;
                OutputStream os = sock.getOutputStream();
                InputStream in = sock.getInputStream();

                StringBuilder req = new StringBuilder();
                req.append("GET /").append(cfg.mount).append(" HTTP/1.0\r\n");
                req.append("User-Agent: ").append(cfg.userAgent).append("\r\n");
                req.append("Accept: */*\r\n");
                req.append("Connection: close\r\n");
                if (cfg.basicAuth != null) req.append("Authorization: ").append(cfg.basicAuth).append("\r\n");
                req.append("\r\n");
                os.write(req.toString().getBytes(StandardCharsets.US_ASCII));
                os.flush();

                String status = readHeaderLine(in);
                if (status.startsWith("ICY 200")) {
                    // NTRIP v1 : les données suivent immédiatement
                } else if (status.startsWith("HTTP/1.") && status.contains(" 200")) {
                    String h;
                    while (!(h = readHeaderLine(in)).isEmpty()) {
                        String low = h.toLowerCase(Locale.ROOT);
                        if (low.startsWith("transfer-encoding:") && low.contains("chunked")) {
                            throw new Fatal("Le caster répond en NTRIP v2 (chunked), non géré");
                        }
                    }
                } else if (status.startsWith("SOURCETABLE")) {
                    throw new Fatal("Point de montage « " + cfg.mount + " » inconnu du caster");
                } else if (status.contains("401")) {
                    throw new Fatal("Identifiants refusés par le caster");
                } else {
                    throw new IOException("Réponse inattendue du caster : " + (status.isEmpty() ? "(vide)" : status));
                }

                out.onState("connected", cfg.mount);

                long nextGga = 0, lastStat = 0;
                int silent = 0;
                byte[] buf = new byte[4096];
                while (wanted) {
                    long now = System.currentTimeMillis();
                    String g = gga.lastGga();
                    if (g != null && now >= nextGga) {
                        os.write((g + "\r\n").getBytes(StandardCharsets.US_ASCII));
                        os.flush();
                        nextGga = now + cfg.ggaIntervalS * 1000L;
                    }
                    int n;
                    try {
                        n = in.read(buf);
                    } catch (SocketTimeoutException te) {
                        // 15 × 2 s sans octet : le flux est considéré comme mort
                        if (++silent >= 15) throw new IOException("Aucune correction reçue depuis 30 s");
                        continue;
                    }
                    if (n < 0) throw new IOException("Le caster a fermé la connexion");
                    silent = 0;
                    bytes += n;
                    lastDataAt = System.currentTimeMillis();
                    out.onData(buf, n);
                    if (lastDataAt - lastStat >= 2000) {
                        lastStat = lastDataAt;
                        out.onBytes(bytes);
                    }
                }
            } catch (Fatal e) {
                wanted = false;
                out.onState("error", e.getMessage());
            } catch (IOException e) {
                if (wanted) out.onState("error", e.getMessage() != null ? e.getMessage() : "Erreur réseau");
            } finally {
                closeQuietly(sock);
                if (socket == sock) socket = null;
            }
            if (wanted) {
                out.onState("reconnecting", "Nouvel essai dans " + Math.max(1, cfg.retryDelayMs / 1000) + " s");
                try { Thread.sleep(cfg.retryDelayMs); } catch (InterruptedException ie) { break; }
            }
        }
        out.onState("stopped", "");
    }

    /** Lit une ligne d'en-tête (jusqu'à \n, 1 024 octets au plus). */
    private static String readHeaderLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        long deadline = System.currentTimeMillis() + 10000;
        while (sb.length() < 1024) {
            int c;
            try {
                c = in.read();
            } catch (SocketTimeoutException te) {
                if (System.currentTimeMillis() > deadline) throw new IOException("Pas de réponse du caster");
                continue;
            }
            if (c < 0) break;
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        return sb.toString().trim();
    }

    private static void closeQuietly(Socket s) {
        if (s == null) return;
        try { s.close(); } catch (IOException ignored) { }
    }

    /** Erreur NTRIP qui ne doit pas déclencher de nouvel essai (mauvais réglage). */
    private static final class Fatal extends IOException {
        private static final long serialVersionUID = 1L;
        Fatal(String m) { super(m); }
    }
}
