package fr.lileauvert.piquetage;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Choix du « port série » d'un récepteur Bluetooth LE.
 *
 * Il n'existe pas de profil série BLE normalisé : chaque fabricant de module publie le sien.
 * On reconnaît les plus courants (Nordic UART, Microchip, HM-10, u-blox SPS) ; à défaut, on prend
 * le premier service qui possède à la fois une caractéristique en notification et une en écriture.
 * Classe sans dépendance Android, testée sous Java seul.
 */
final class BleUartProfiles {

    // Propriétés GATT (mêmes valeurs que BluetoothGattCharacteristic.PROPERTY_*)
    static final int P_READ = 0x02, P_WRITE_NO_RESPONSE = 0x04, P_WRITE = 0x08, P_NOTIFY = 0x10, P_INDICATE = 0x20;

    /** Une caractéristique GATT découverte. */
    static final class Chr {
        final UUID service, uuid;
        final int props;
        Chr(UUID service, UUID uuid, int props) { this.service = service; this.uuid = uuid; this.props = props; }
        boolean canNotify() { return (props & (P_NOTIFY | P_INDICATE)) != 0; }
        boolean canWrite() { return (props & (P_WRITE | P_WRITE_NO_RESPONSE)) != 0; }
    }

    /** Résultat : caractéristique à écouter (récepteur → application) et à écrire (application → récepteur). */
    static final class Pick {
        final String profile;
        final UUID service, notify, write;
        final boolean writeNoResponse;
        Pick(String profile, UUID service, UUID notify, UUID write, boolean writeNoResponse) {
            this.profile = profile; this.service = service; this.notify = notify; this.write = write; this.writeNoResponse = writeNoResponse;
        }
    }

    private static UUID u(String s) { return UUID.fromString(s); }

    private static final class Known {
        final String name; final UUID service, notify, write;
        Known(String name, String service, String notify, String write) {
            this.name = name; this.service = u(service); this.notify = u(notify); this.write = u(write);
        }
    }

    // L'ordre est l'ordre de préférence.
    private static final Known[] KNOWN = {
        new Known("Nordic UART", "6e400001-b5a3-f393-e0a9-e50e24dcca9e", "6e400003-b5a3-f393-e0a9-e50e24dcca9e", "6e400002-b5a3-f393-e0a9-e50e24dcca9e"),
        new Known("Microchip transparent UART", "49535343-fe7d-4ae5-8fa9-9fafd205e455", "49535343-1e4d-4bd9-ba61-23c647249616", "49535343-8841-43f4-a8d4-ecbe34729bb3"),
        new Known("HM-10 / TI (FFE0)", "0000ffe0-0000-1000-8000-00805f9b34fb", "0000ffe1-0000-1000-8000-00805f9b34fb", "0000ffe1-0000-1000-8000-00805f9b34fb"),
        new Known("u-blox SPS", "2456e1b9-26e2-8f83-e744-f34f01e9d701", "2456e1b9-26e2-8f83-e744-f34f01e9d703", "2456e1b9-26e2-8f83-e744-f34f01e9d703"),
    };

    private static Chr find(List<Chr> all, UUID service, UUID uuid) {
        for (Chr c : all) if (c.service.equals(service) && c.uuid.equals(uuid)) return c;
        return null;
    }

    /** Services normalisés du Bluetooth SIG (0x1800–0x18FF : accès générique, batterie, etc.). */
    static boolean isStandardService(UUID s) {
        String t = s.toString().toLowerCase(Locale.ROOT);
        return t.startsWith("000018") && t.endsWith("-0000-1000-8000-00805f9b34fb");
    }

    /** null si aucun port série reconnaissable. */
    static Pick pick(List<Chr> all) {
        for (Known k : KNOWN) {
            Chr n = find(all, k.service, k.notify), w = find(all, k.service, k.write);
            if (n != null && w != null && n.canNotify() && w.canWrite()) {
                return new Pick(k.name, k.service, n.uuid, w.uuid, (w.props & P_WRITE_NO_RESPONSE) != 0);
            }
        }
        // À défaut : premier service non normalisé ayant une caractéristique en notification et une en écriture.
        List<UUID> order = new ArrayList<>();
        for (Chr c : all) if (!order.contains(c.service) && !isStandardService(c.service)) order.add(c.service);
        for (UUID s : order) {
            Chr n = null, w = null;
            for (Chr c : all) {
                if (!c.service.equals(s)) continue;
                if (n == null && c.canNotify()) n = c;
            }
            for (Chr c : all) {
                if (!c.service.equals(s)) continue;
                // préférence : écriture sans réponse (plus rapide), d'une caractéristique distincte de celle qui notifie
                if (c.canWrite() && (w == null || ((c.props & P_WRITE_NO_RESPONSE) != 0 && (w.props & P_WRITE_NO_RESPONSE) == 0))) w = c;
            }
            if (n != null && w != null) return new Pick("Port série générique", s, n.uuid, w.uuid, (w.props & P_WRITE_NO_RESPONSE) != 0);
        }
        return null;
    }

    /** Description des services découverts, pour le diagnostic quand aucun port série n'est reconnu. */
    static String describe(List<Chr> all) {
        StringBuilder sb = new StringBuilder();
        UUID last = null;
        for (Chr c : all) {
            if (!c.service.equals(last)) { if (sb.length() > 0) sb.append(" ; "); sb.append(shortUuid(c.service)).append(" ["); last = c.service; }
            else sb.append(", ");
            sb.append(shortUuid(c.uuid)).append(':').append(propsText(c.props));
        }
        if (last != null) sb.append(']');
        return sb.length() == 0 ? "aucun service" : sb.toString();
    }

    static String propsText(int p) {
        StringBuilder s = new StringBuilder();
        if ((p & P_READ) != 0) s.append('r');
        if ((p & P_WRITE) != 0) s.append('w');
        if ((p & P_WRITE_NO_RESPONSE) != 0) s.append('c');   // « commande » : écriture sans réponse
        if ((p & P_NOTIFY) != 0) s.append('n');
        if ((p & P_INDICATE) != 0) s.append('i');
        return s.toString();
    }

    private static String shortUuid(UUID u) {
        String t = u.toString().toLowerCase(Locale.ROOT);
        return t.endsWith("-0000-1000-8000-00805f9b34fb") ? t.substring(4, 8) : t;
    }
}
