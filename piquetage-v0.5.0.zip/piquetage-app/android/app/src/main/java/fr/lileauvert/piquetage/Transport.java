package fr.lileauvert.piquetage;

import java.io.IOException;

/**
 * Liaison entre l'application et le récepteur GNSS, quel que soit le support :
 * Bluetooth LE, USB ou Bluetooth Classic. Les octets reçus du récepteur sont
 * remis à un {@link LinkListener} ; les corrections RTCM sont écrites par
 * {@link #write}.
 */
interface Transport {
    /** Écrit des octets vers le récepteur (corrections RTCM3). Ne bloque pas longtemps. */
    void write(byte[] data, int len) throws IOException;

    /** Ferme la liaison. Sans effet si elle est déjà fermée. */
    void close();

    /** « ble », « usb » ou « classic ». */
    String kind();

    /** Nom lisible du récepteur. */
    String name();

    /** Détails utiles au diagnostic (profil BLE retenu, pilote USB, MTU…). */
    String info();
}
