#!/usr/bin/env python3
"""Jeu de fichiers de test pour trouver quel DXF votre logiciel de CAO accepte.

Le même petit dessin (3 points, 3 tracés) est écrit en plusieurs variantes :
  1  PIQUETAGE (écrivain de l'application, R12 complet)
  2  R12 écrit par ezdxf (référence)
  3  R2000 écrit par ezdxf
  4  R2007 écrit par ezdxf
  0  fichier minimal (une ligne et un cercle) : le logiciel ouvre-t-il le moindre DXF ?
Usage : python3 tools/make_dxf_kit.py FICHIER_PIQUETAGE.dxf DOSSIER_SORTIE
"""
import os
import shutil
import sys

import ezdxf
from ezdxf.addons.importer import Importer

src_path, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
shutil.copyfile(src_path, os.path.join(out, '1_PIQUETAGE_R12.dxf'))

src = ezdxf.readfile(src_path)
for ver, name in (('R12', '2_ezdxf_R12_reference'), ('R2000', '3_ezdxf_R2000'), ('R2007', '4_ezdxf_R2007')):
    tgt = ezdxf.new(ver)
    for lay in src.layers:
        if lay.dxf.name not in tgt.layers:
            tgt.layers.add(lay.dxf.name, color=lay.dxf.color)
    imp = Importer(src, tgt)
    imp.import_modelspace()
    imp.finalize()
    tgt.saveas(os.path.join(out, name + '.dxf'))
mini = ezdxf.new('R12')
mini.modelspace().add_line((0, 0), (10, 10))
mini.modelspace().add_circle((5, 5), 2)
mini.saveas(os.path.join(out, '0_mini_ligne_cercle_R12.dxf'))
with open(os.path.join(out, 'LISEZ-MOI.txt'), 'w', encoding='utf-8') as fh:
    fh.write('''Jeu de fichiers de test DXF — Piquetage
=======================================
Le même petit dessin (3 points numérotés, 3 tracés) en plusieurs variantes de DXF. Ouvrez chaque fichier dans
Vectorworks et dans DesignCAD 10, de préférence avec la commande d'importation DXF/DWG du logiciel, puis avec
« Ouvrir » si elle existe. Notez pour chaque fichier : ouvert / refusé, et le message d'erreur exact.

0_mini_ligne_cercle_R12.dxf   une ligne et un cercle. Si celui-ci est refusé, le problème est dans la
                              manière d'ouvrir ou dans la version de DXF acceptée, pas dans mes fichiers.
1_PIQUETAGE_R12.dxf           ce que produit l'application (DXF R12 complet, repère local).
2_ezdxf_R12_reference.dxf     même dessin écrit par une bibliothèque de référence (ezdxf) en R12.
3_ezdxf_R2000.dxf             même dessin en DXF 2000.
4_ezdxf_R2007.dxf             même dessin en DXF 2007.

Unités : un DXF R12 n'en porte pas ; choisir le mètre à l'import. Les coordonnées sont locales (X, Y petits) :
le décalage vers le Lambert-93 est inscrit au cartouche du dessin.
''')
print('jeu de test écrit dans', out, sorted(os.listdir(out)))
