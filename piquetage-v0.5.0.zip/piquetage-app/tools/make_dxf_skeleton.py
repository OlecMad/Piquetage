#!/usr/bin/env python3
"""Génère www/dxf-skeleton.js : le squelette complet d'un DXF R12 (en-tête, tables, blocs).

Source : un document R12 vide écrit par ezdxf (structure éprouvée avec AutoCAD R12), nettoyé de ce qui
est propre à ezdxf ou aux poignées : groupes 5 et 105 (poignées), $HANDSEED, étiquettes 1000/1001,
calque « Defpoints ». Les calques du projet et les entités sont écrits par www/export.js.

Usage : python3 tools/make_dxf_skeleton.py
"""
import json
import os
import tempfile

import ezdxf

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

doc = ezdxf.new('R12')
tmp = os.path.join(tempfile.mkdtemp(), 'ref.dxf')
doc.saveas(tmp)
raw = open(tmp, 'rb').read().decode('latin-1')
lines = [x.rstrip('\r') for x in raw.split('\n')]
if lines and lines[-1] == '':
    lines.pop()
pairs = [(int(lines[i].strip()), lines[i + 1]) for i in range(0, len(lines) - 1, 2)]


def section(name):
    a = next(k for k, (c, v) in enumerate(pairs) if c == 2 and v == name and pairs[k - 1] == (0, 'SECTION'))
    b = next(k for k in range(a, len(pairs)) if pairs[k] == (0, 'ENDSEC'))
    return pairs[a + 1:b]          # contenu, sans « SECTION / nom » ni « ENDSEC »


def strip_handles(recs):
    out, i = [], 0
    while i < len(recs):
        c, v = recs[i]
        if c in (5, 105, 1000, 1001):
            i += 1
            continue
        out.append((c, v))
        i += 1
    return out


# ---------- HEADER : variables sans $HANDSEED, $HANDLING à 0 ----------
header = []
hs = section('HEADER')
i = 0
while i < len(hs):
    c, v = hs[i]
    if c == 9:
        j = i + 1
        while j < len(hs) and hs[j][0] != 9:
            j += 1
        name, vals = v, hs[i + 1:j]
        if name == '$HANDSEED':
            i = j
            continue
        if name == '$HANDLING':
            vals = [(70, '0')]
        header.append([name, [[c2, v2] for c2, v2 in vals]])
        i = j
    else:
        i += 1

# ---------- TABLES : découpe autour de LAYER ----------
tb = strip_handles(section('TABLES'))
tables = []          # [(nom, [enregistrements])]
i = 0
while i < len(tb):
    if tb[i] == (0, 'TABLE'):
        name = tb[i + 1][1]
        j = i
        while tb[j] != (0, 'ENDTAB'):
            j += 1
        body = tb[i + 2:j]           # commence par le groupe 70 (nombre d'enregistrements)
        tables.append((name, body))
        i = j + 1
    else:
        i += 1

order = [n for n, _ in tables]
tmap = dict(tables)
before = [(n, tmap[n]) for n in order[:order.index('LAYER')]]
after = [(n, tmap[n]) for n in order[order.index('LAYER') + 1:]]

# LTYPE : on ne garde que ByBlock, ByLayer, Continuous (déjà le cas) ; la table LAYER est écrite par export.js

# ---------- BLOCKS ----------
blocks = strip_handles(section('BLOCKS'))
# les enregistrements 1000/1001 propres à ezdxf ont été retirés ; on contrôle
assert not any(c in (1000, 1001, 5) for c, _ in blocks)

sk = {
    'header': header,
    'tablesBefore': [[n, [[c, v] for c, v in body]] for n, body in before],
    'tablesAfter': [[n, [[c, v] for c, v in body]] for n, body in after],
    'blocks': [[c, v] for c, v in blocks],
    'ezdxf': ezdxf.__version__,
}

js = ("/* Squelette d'un DXF R12 : en-tête, tables (hors calques), blocs.\n"
      "   Généré par tools/make_dxf_skeleton.py (ezdxf " + ezdxf.__version__ + ") — ne pas éditer à la main.\n"
      "   Utilisé par www/export.js : mêmes sections et variables qu'un DXF R12 écrit par un logiciel de CAO,\n"
      "   que les logiciels stricts attendent (HEADER complet, tables VPORT/LTYPE/STYLE/VIEW/UCS/APPID/DIMSTYLE, section BLOCKS). */\n"
      "(function (root, factory) {\n"
      "  if (typeof module === 'object' && module.exports) module.exports = factory();\n"
      "  else root.PiqDxfSkeleton = factory();\n"
      "})(typeof self !== 'undefined' ? self : this, function () {\n"
      "  'use strict';\n"
      "  return " + json.dumps(sk, ensure_ascii=True, separators=(',', ':')) + ";\n"
      "});\n")
open(os.path.join(ROOT, 'www', 'dxf-skeleton.js'), 'w', encoding='utf-8').write(js)
print('en-tête :', len(header), 'variables ; tables avant LAYER :', [n for n, _ in before], '; après :', [n for n, _ in after], '; blocs :', len(blocks), 'enregistrements')
print('taille :', len(js), 'octets')
