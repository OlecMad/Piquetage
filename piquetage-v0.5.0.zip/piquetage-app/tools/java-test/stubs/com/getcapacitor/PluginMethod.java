package com.getcapacitor;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface PluginMethod { String RETURN_PROMISE = "promise"; String returnType() default RETURN_PROMISE; }
