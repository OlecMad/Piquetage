package com.getcapacitor;
import org.json.JSONArray;
/** Bouchon aux signatures de Capacitor 8.5.2 (JSArray étend org.json.JSONArray). */
public class JSArray extends JSONArray {
    public JSArray() { super(); }
}
