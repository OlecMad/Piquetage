package com.getcapacitor;
import org.json.JSONObject;
/** Bouchon aux signatures de Capacitor 8.5.2 (JSObject étend org.json.JSONObject). */
public class JSObject extends JSONObject {
    public JSObject() { super(); }
    public JSObject put(String key, boolean value) { try { super.put(key, value); } catch (org.json.JSONException ignored) { } return this; }
    public JSObject put(String key, int value) { try { super.put(key, value); } catch (org.json.JSONException ignored) { } return this; }
    public JSObject put(String key, long value) { try { super.put(key, value); } catch (org.json.JSONException ignored) { } return this; }
    public JSObject put(String key, double value) { try { super.put(key, value); } catch (org.json.JSONException ignored) { } return this; }
    public JSObject put(String key, Object value) { try { super.put(key, value); } catch (org.json.JSONException ignored) { } return this; }
    public JSObject put(String key, String value) { try { super.put(key, value); } catch (org.json.JSONException ignored) { } return this; }
}
