package com.getcapacitor;
import androidx.appcompat.app.AppCompatActivity;
public class BridgeActivity extends AppCompatActivity {
    protected void registerPlugin(Class<? extends Plugin> plugin) { }
    public Bridge getBridge() { return null; }
}
