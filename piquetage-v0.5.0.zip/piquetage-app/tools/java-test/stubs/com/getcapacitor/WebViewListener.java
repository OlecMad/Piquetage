package com.getcapacitor;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
public abstract class WebViewListener {
    public boolean onRenderProcessGone(WebView webView, RenderProcessGoneDetail detail) { return false; }
}
