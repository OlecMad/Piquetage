package com.getcapacitor;
/** Bouchon aux signatures de Capacitor 8.5.2. */
public class PluginCall {
    public String getString(String name) { return null; }
    public String getString(String name, String defaultValue) { return defaultValue; }
    public Integer getInt(String name) { return null; }
    public Integer getInt(String name, Integer defaultValue) { return defaultValue; }
    public Long getLong(String name) { return null; }
    public Long getLong(String name, Long defaultValue) { return defaultValue; }
    public Boolean getBoolean(String name) { return null; }
    public Boolean getBoolean(String name, Boolean defaultValue) { return defaultValue; }
    public JSObject getData() { return new JSObject(); }
    public void resolve(JSObject data) { }
    public void resolve() { }
    public void reject(String msg, String code, Exception ex, JSObject data) { }
    public void reject(String msg, String code, JSObject data) { }
    public void reject(String msg, String code, Exception ex) { }
    public void reject(String msg, String code) { }
    public void reject(String msg, Exception ex) { }
    public void reject(String msg) { }
}
