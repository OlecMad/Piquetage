package com.getcapacitor;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
/** Bouchon aux signatures de Capacitor 8.5.2 (Plugin.java). */
public class Plugin {
    public Context getContext() { return null; }
    public AppCompatActivity getActivity() { return null; }
    public PermissionState getPermissionState(String alias) { return PermissionState.GRANTED; }
    public boolean isPermissionDeclared(String alias) { return true; }
    public boolean hasPermission(String permission) { return true; }
    protected void requestPermissionForAlias(String alias, PluginCall call, String callbackName) { }
    protected void requestPermissionForAliases(String[] aliases, PluginCall call, String callbackName) { }
    protected void notifyListeners(String eventName, JSObject data, boolean retainUntilConsumed) { }
    protected void notifyListeners(String eventName, JSObject data) { }
    protected void handleOnDestroy() { }
}
