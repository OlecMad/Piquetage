package androidx.activity;
public final class OnBackPressedDispatcher {
    public void addCallback(OnBackPressedCallback callback) { }
    public void onBackPressed() { }
}
