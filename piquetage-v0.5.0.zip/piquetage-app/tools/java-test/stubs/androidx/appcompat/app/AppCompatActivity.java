package androidx.appcompat.app;
import androidx.activity.OnBackPressedDispatcher;
/** Bouchon : la vraie classe hérite (via ComponentActivity) d'android.app.Activity. */
public class AppCompatActivity extends android.app.Activity {
    public OnBackPressedDispatcher getOnBackPressedDispatcher() { return null; }
}
