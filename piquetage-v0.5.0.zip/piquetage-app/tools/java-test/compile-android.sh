#!/usr/bin/env bash
# Vérifie que TOUT le code Java de l'application compile contre les VRAIES signatures de l'API Android 34
# (android.jar de l'AOSP). Capacitor et AndroidX sont remplacés par des bouchons aux signatures de Capacitor 8.5.2 :
# l'appel de Capacitor lui-même n'est donc pas vérifié ici, mais tous les appels Bluetooth, BLE, USB, Intent, etc. le sont.
# Ne remplace pas la compilation Gradle sur GitHub ; la détecte plus tôt.
#   ANDROID_JAR=/chemin/android.jar bash tools/java-test/compile-android.sh
set -euo pipefail
cd "$(dirname "$0")"
JAR="${ANDROID_JAR:-/tmp/android-api34.jar}"
if [ ! -s "$JAR" ]; then
  echo "Téléchargement de android.jar (API 34, ~41 Mo)…"
  curl -sL --max-time 180 -o "$JAR" "https://raw.githubusercontent.com/Reginer/aosp-android-jar/main/android-34/android.jar"
fi
SRC=../../android/app/src/main/java
rm -rf out-android && mkdir out-android
# -Xlint:all : les avertissements sont affichés (obsolescence des API BLE d'avant Android 13, voulue) ; seules les erreurs échouent
javac -source 21 -target 21 -Xlint:-options -Xlint:unchecked -encoding UTF-8 -cp "$JAR" -d out-android \
  $(find stubs -name "*.java") $(find "$SRC" -name "*.java")
echo "✅ Compilation contre android.jar (API 34) : $(find "$SRC" -name '*.java' | wc -l) fichiers Java, aucune erreur."
