#!/usr/bin/env bash
# Banc d'essai de la logique Java sans dépendance Android : découpe NMEA, file d'écriture BLE, choix du profil
# BLE et client NTRIP (contre un faux caster local). Le code propre à Android est vérifié par compile-android.sh.
set -euo pipefail
cd "$(dirname "$0")"
APP=../../android/app/src/main/java/fr/lileauvert/piquetage
rm -rf out && mkdir out
javac -source 21 -target 21 -Xlint:all -Xlint:-options -encoding UTF-8 -d out \
  "$APP/Transport.java" "$APP/LinkListener.java" "$APP/NmeaSplitter.java" "$APP/ChunkQueue.java" \
  "$APP/BleUartProfiles.java" "$APP/NtripClient.java" test/TestLinks.java
java -Dstdout.encoding=UTF-8 -cp out fr.lileauvert.piquetage.TestLinks
