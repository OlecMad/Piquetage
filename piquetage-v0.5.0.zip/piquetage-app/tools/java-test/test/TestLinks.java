package fr.lileauvert.piquetage;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/** Tests de la logique Java sans Android (même paquet pour atteindre les classes internes). */
public class TestLinks {
    static int fails = 0, n = 0;
    static void ok(boolean c, String label, Object detail) { n++; System.out.println((c ? "  ✓ " : "  ✗ ") + label + (detail != null ? "  → " + detail : "")); if (!c) fails++; }
    static String cs(String body) { int c = 0; for (char ch : body.toCharArray()) c ^= ch; return "$" + body + "*" + String.format("%02X", c); }
    static byte[] b(String s) { return s.getBytes(StandardCharsets.US_ASCII); }
    static UUID u(String s) { return UUID.fromString(s); }
    static final String BASE = "-0000-1000-8000-00805f9b34fb";

    /* ---------------- découpe NMEA ---------------- */
    static void nmea() throws Exception {
        System.out.println("\n── Découpe NMEA ──");
        List<String> got = new ArrayList<>();
        NmeaSplitter s = new NmeaSplitter(got::add);
        String GGA = cs("GNGGA,101530.00,4710.99800,N,00105.64000,E,4,20,0.50,72.100,M,47.000,M,1.0,0412");
        ByteArrayOutputStream feed = new ByteArrayOutputStream();
        feed.write(b(GGA + "\r\n"));
        feed.write(new byte[]{(byte) 0xB5, 0x62, 0x01, 0x07, 0x5C, 0x00, '\n', (byte) 0xFF, (byte) 0x80});   // binaire UBX parasite contenant un \n
        feed.write(b(cs("GNGSV,3,1,11,02,45,120,40") + "\r\n"));
        feed.write(b(cs("GNGST,101530.00,0.012,0.010,0.008,45.0,0.009,0.008,0.015") + "\r\n"));
        feed.write(b("\r\n\r\n$AB\r\n"));                       // lignes vides et trop courtes
        byte[] all = feed.toByteArray();
        s.feed(all, 0, all.length);
        ok(got.size() == 3 && got.get(0).equals(GGA) && got.get(1).startsWith("$GNGSV") && got.get(2).startsWith("$GNGST"), "3 lignes transmises (GGA, GSV, GST) : la GSV précédée de binaire sans saut de ligne n'est pas perdue ; lignes courtes ignorées", got.size());
        got.clear();
        for (int i = 0; i < all.length; i++) s.feed(all, i, 1);   // octet par octet
        ok(got.size() == 3, "même résultat reçu octet par octet (trames coupées n'importe où)", got.size());
        got.clear();
        StringBuilder longLine = new StringBuilder("$");
        for (int i = 0; i < 400; i++) longLine.append('A');
        byte[] lb = b(longLine + "\r\n" + GGA + "\r\n");
        s.feed(lb, 0, lb.length);
        ok(got.size() == 1 && got.get(0).equals(GGA), "ligne de plus de 256 caractères abandonnée, la suivante est lue", got.size());
        s.reset(); got.clear();
        byte[] half = b(GGA.substring(0, 30)); s.feed(half, 0, half.length); s.reset();
        byte[] rest = b(GGA + "\n"); s.feed(rest, 0, rest.length);
        ok(got.size() == 1 && got.get(0).equals(GGA), "reset() jette la ligne en cours (nouvelle liaison)", null);
    }

    /* ---------------- file d'écriture BLE ---------------- */
    static void queue() throws Exception {
        System.out.println("\n── File d'écriture BLE ──");
        ChunkQueue q = new ChunkQueue(20, 100);
        byte[] data = new byte[45]; for (int i = 0; i < data.length; i++) data[i] = (byte) i;
        q.put(data, data.length);
        byte[] c1 = q.take(100), c2 = q.take(100), c3 = q.take(100);
        ok(c1.length == 20 && c2.length == 20 && c3.length == 5 && c1[0] == 0 && c2[0] == 20 && c3[0] == 40, "45 octets → morceaux de 20, 20 et 5, dans l'ordre", null);
        ok(q.take(60) == null && q.queuedBytes() == 0, "file vide : take() rend null après le délai", null);
        ChunkQueue mtu = new ChunkQueue(20, 4096);
        mtu.setChunk(244);
        mtu.put(new byte[300], 300);
        ok(mtu.take(10).length == 244 && mtu.take(10).length == 56, "MTU négocié (247 − 3) : morceaux de 244 puis 56 octets", null);
        ChunkQueue tiny = new ChunkQueue(20, 100);
        tiny.put(new byte[300], 300);
        ok(tiny.queuedBytes() <= 100 && tiny.droppedBytes() >= 200, "une rafale plus grosse que la file : le début est abandonné, la fin conservée", tiny.queuedBytes() + " en file, " + tiny.droppedBytes() + " abandonnés");

        ChunkQueue big = new ChunkQueue(20, 100);
        for (int i = 0; i < 10; i++) big.put(new byte[]{(byte) i, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}, 20);
        ok(big.queuedBytes() <= 100 && big.droppedBytes() == 100, "file bornée à 100 octets : les 5 plus anciens morceaux abandonnés", big.queuedBytes() + " en file, " + big.droppedBytes() + " abandonnés");
        ok(big.take(10)[0] == 5, "on garde les corrections les plus récentes (le premier restant porte le n° 5)", null);

        ChunkQueue c = new ChunkQueue(20, 100);
        final byte[][] holder = new byte[1][];
        Thread t = new Thread(() -> { try { holder[0] = c.take(5000); } catch (InterruptedException ignored) { } });
        t.start(); Thread.sleep(100); c.put(new byte[]{1, 2, 3}, 3); t.join(2000);
        ok(!t.isAlive() && holder[0] != null && holder[0].length == 3, "take() bloquant réveillé par put()", null);
        Thread t2 = new Thread(() -> { try { holder[0] = c.take(5000); } catch (InterruptedException ignored) { } });
        holder[0] = new byte[0]; t2.start(); Thread.sleep(100); c.close(); t2.join(2000);
        ok(!t2.isAlive() && holder[0] == null, "close() réveille le fil en attente et rend null", null);
        c.put(new byte[5], 5);
        ok(c.queuedBytes() == 0, "après close(), put() n'accepte plus rien", null);
    }

    /* ---------------- profils BLE ---------------- */
    static BleUartProfiles.Chr chr(String svc, String ch, int p) { return new BleUartProfiles.Chr(u(svc), u(ch), p); }
    static void profiles() {
        System.out.println("\n── Choix du port série BLE ──");
        final int N = BleUartProfiles.P_NOTIFY, W = BleUartProfiles.P_WRITE, C = BleUartProfiles.P_WRITE_NO_RESPONSE, R = BleUartProfiles.P_READ;
        List<BleUartProfiles.Chr> nus = Arrays.asList(
            chr("00001800" + BASE, "00002a00" + BASE, R),
            chr("6e400001-b5a3-f393-e0a9-e50e24dcca9e", "6e400002-b5a3-f393-e0a9-e50e24dcca9e", W | C),
            chr("6e400001-b5a3-f393-e0a9-e50e24dcca9e", "6e400003-b5a3-f393-e0a9-e50e24dcca9e", N));
        BleUartProfiles.Pick p = BleUartProfiles.pick(nus);
        ok(p != null && p.profile.equals("Nordic UART") && p.notify.toString().startsWith("6e400003") && p.write.toString().startsWith("6e400002"), "Nordic UART : notification sur …0003, écriture sur …0002", p == null ? null : p.profile);
        ok(p.writeNoResponse, "écriture sans réponse retenue quand elle existe (plus rapide)", null);

        List<BleUartProfiles.Chr> hm = Arrays.asList(chr("0000ffe0" + BASE, "0000ffe1" + BASE, R | C | N));
        p = BleUartProfiles.pick(hm);
        ok(p != null && p.profile.startsWith("HM-10") && p.notify.equals(p.write) && p.writeNoResponse, "HM-10 / FFE0 : une seule caractéristique pour les deux sens", p == null ? null : p.profile);

        List<BleUartProfiles.Chr> sps = Arrays.asList(
            chr("2456e1b9-26e2-8f83-e744-f34f01e9d701", "2456e1b9-26e2-8f83-e744-f34f01e9d703", N | W | C),
            chr("2456e1b9-26e2-8f83-e744-f34f01e9d701", "2456e1b9-26e2-8f83-e744-f34f01e9d704", N | W));
        p = BleUartProfiles.pick(sps);
        ok(p != null && p.profile.equals("u-blox SPS") && p.notify.toString().endsWith("d703"), "u-blox SPS : caractéristique FIFO (…d703)", p == null ? null : p.profile);

        List<BleUartProfiles.Chr> mc = Arrays.asList(
            chr("49535343-fe7d-4ae5-8fa9-9fafd205e455", "49535343-1e4d-4bd9-ba61-23c647249616", N),
            chr("49535343-fe7d-4ae5-8fa9-9fafd205e455", "49535343-8841-43f4-a8d4-ecbe34729bb3", W | C));
        p = BleUartProfiles.pick(mc);
        ok(p != null && p.profile.startsWith("Microchip"), "Microchip transparent UART reconnu", null);

        List<BleUartProfiles.Chr> gen = Arrays.asList(
            chr("0000180a" + BASE, "00002a29" + BASE, R),
            chr("12345678-0000-1000-8000-00805f9b34fb", "12345678-0001-1000-8000-00805f9b34fb", N),
            chr("12345678-0000-1000-8000-00805f9b34fb", "12345678-0002-1000-8000-00805f9b34fb", W),
            chr("12345678-0000-1000-8000-00805f9b34fb", "12345678-0003-1000-8000-00805f9b34fb", C));
        p = BleUartProfiles.pick(gen);
        ok(p != null && p.profile.equals("Port série générique") && p.notify.toString().startsWith("12345678-0001") && p.write.toString().startsWith("12345678-0003") && p.writeNoResponse, "service inconnu : notification + écriture sans réponse préférée, service d'information ignoré", null);

        ok(BleUartProfiles.pick(Arrays.asList(chr("00001800" + BASE, "00002a00" + BASE, R | W | N), chr("0000180f" + BASE, "00002a19" + BASE, R | N))) == null, "seulement des services normalisés (accès générique, batterie) : aucun port série", null);
        ok(BleUartProfiles.pick(Arrays.asList(chr("6e400001-b5a3-f393-e0a9-e50e24dcca9e", "6e400003-b5a3-f393-e0a9-e50e24dcca9e", N))) == null, "Nordic UART sans caractéristique d'écriture : refusé", null);
        ok(BleUartProfiles.pick(new ArrayList<BleUartProfiles.Chr>()) == null, "aucun service : null", null);
        ok(BleUartProfiles.isStandardService(u("0000180f" + BASE)) && !BleUartProfiles.isStandardService(u("0000ffe0" + BASE)), "0x180F normalisé ; 0xFFE0 (HM-10) ne l'est pas", null);
        String d = BleUartProfiles.describe(nus);
        ok(d.contains("1800") && d.contains("6e400001") && d.contains("6e400003-b5a3-f393-e0a9-e50e24dcca9e:n") && d.contains(":wc"), "description pour le diagnostic : services et propriétés (r, w, c, n)", d);
        ok(BleUartProfiles.describe(new ArrayList<BleUartProfiles.Chr>()).equals("aucun service"), "description d'une liste vide", null);
    }

    /* ---------------- client NTRIP ---------------- */
    static class FakeCaster extends Thread {
        final ServerSocket ss; final String reply; final boolean stream; final int connections;
        final StringBuilder received = new StringBuilder(); volatile int accepted = 0, sent = 0;
        FakeCaster(String reply, boolean stream, int connections) throws IOException { ss = new ServerSocket(0); this.reply = reply; this.stream = stream; this.connections = connections; setDaemon(true); }
        int port() { return ss.getLocalPort(); }
        public void run() {
            for (int c = 0; c < connections; c++) {
                try (Socket s = ss.accept()) {
                    accepted++;
                    s.setSoTimeout(200);
                    InputStream in = s.getInputStream(); OutputStream out = s.getOutputStream();
                    long end = System.currentTimeMillis() + (connections > 1 ? 900 : 2500); boolean replied = false; byte[] b = new byte[1024];
                    while (System.currentTimeMillis() < end) {
                        try { int k = in.read(b); if (k < 0) break; synchronized (received) { received.append(new String(b, 0, k, StandardCharsets.US_ASCII)); } } catch (SocketTimeoutException te) { }
                        if (!replied && received.indexOf("\r\n\r\n") >= 0) { out.write(reply.getBytes(StandardCharsets.US_ASCII)); out.flush(); replied = true; if (!stream) { Thread.sleep(150); break; } }
                        if (replied && stream) { byte[] rtcm = new byte[]{(byte) 0xD3, 0x00, 0x13, 0x3E, (byte) 0xD0, 0x00, 0x03}; out.write(rtcm); out.flush(); sent += rtcm.length; Thread.sleep(20); }
                    }
                } catch (Exception ignored) { }
            }
        }
    }

    static class Rec implements NtripClient.Listener {
        final List<String> states = new CopyOnWriteArrayList<>(); volatile long data = 0, lastTotal = 0;
        public void onState(String s, String m) { states.add(s + ":" + m); }
        public void onData(byte[] buf, int len) { data += len; }
        public void onBytes(long t) { lastTotal = t; }
        boolean has(String prefix) { for (String s : states) if (s.startsWith(prefix)) return true; return false; }
        String find(String prefix) { for (String s : states) if (s.startsWith(prefix)) return s; return ""; }
    }

    static NtripClient.Config cfg(int port, String mount, String auth) {
        NtripClient.Config c = new NtripClient.Config();
        c.host = "127.0.0.1"; c.port = port; c.mount = mount; c.basicAuth = auth; c.ggaIntervalS = 1; c.retryDelayMs = 250;
        return c;
    }

    static void ntrip() throws Exception {
        String GGA = cs("GNGGA,101530.00,4710.99800,N,00105.64000,E,4,20,0.50,72.100,M,47.000,M,1.0,0412");
        String auth = "Basic " + Base64.getEncoder().encodeToString("centipede:centipede".getBytes(StandardCharsets.UTF_8));

        System.out.println("\n── NTRIP : flux ICY 200 OK ──");
        FakeCaster fc = new FakeCaster("ICY 200 OK\r\n", true, 1); fc.start();
        Rec r = new Rec();
        NtripClient c = new NtripClient(cfg(fc.port(), "LHER", auth), () -> GGA, r);
        c.start(); Thread.sleep(2300); c.stop(); ok(c.join(5000), "arrêt propre : le fil se termine", null);
        String req; synchronized (fc.received) { req = fc.received.toString(); }
        ok(req.startsWith("GET /LHER HTTP/1.0\r\n"), "requête NTRIP v1 sur le point de montage", req.split("\r\n")[0]);
        ok(req.contains("Authorization: " + auth + "\r\n"), "authentification Basic transmise telle que fournie", null);
        ok(req.contains("User-Agent: NTRIP "), "en-tête User-Agent au format NTRIP", null);
        ok(req.split(java.util.regex.Pattern.quote(GGA), -1).length - 1 >= 1, "GGA envoyée au caster (intervalle 1 s)", null);
        ok(r.data > 0 && r.data <= fc.sent && c.bytes() == r.data, "octets RTCM remis à l'appelant et comptés", r.data + " / " + fc.sent + " émis");
        ok(r.has("connected:LHER") && r.has("stopped"), "états « connected » puis « stopped »", null);
        ok(r.lastTotal > 0, "compteur d'octets publié périodiquement", r.lastTotal);

        System.out.println("\n── NTRIP : HTTP/1.1 200 OK (réponse observée avec Centipede) ──");
        FakeCaster fh = new FakeCaster("HTTP/1.1 200 OK\r\nContent-Type: gnss/data\r\n\r\n", true, 1); fh.start();
        Rec rh = new Rec();
        NtripClient ch = new NtripClient(cfg(fh.port(), "NEAR", null), () -> null, rh);
        ch.start(); Thread.sleep(1200); ch.stop(); ch.join(5000);
        ok(rh.has("connected:NEAR") && rh.data > 0, "réponse HTTP 200 sans « chunked » acceptée, corrections reçues", rh.data + " octets");
        String reqh; synchronized (fh.received) { reqh = fh.received.toString(); }
        ok(!reqh.contains("Authorization"), "aucun en-tête Authorization si pas d'identifiants", null);

        System.out.println("\n── NTRIP : erreurs de réglage (arrêt, pas de nouvel essai) ──");
        FakeCaster f3 = new FakeCaster("SOURCETABLE 200 OK\r\nServer: fake\r\n\r\nENDSOURCETABLE\r\n", false, 1); f3.start();
        Rec r3 = new Rec(); NtripClient c3 = new NtripClient(cfg(f3.port(), "XXXX", null), () -> null, r3);
        c3.start();
        ok(c3.join(6000), "point de montage inconnu : la boucle s'arrête d'elle-même", null);
        ok(r3.find("error:").contains("XXXX") && r3.find("error:").contains("inconnu") && !c3.isRunning(), "message « Point de montage … inconnu » et aucune reconnexion", r3.find("error:"));

        FakeCaster f4 = new FakeCaster("HTTP/1.0 401 Unauthorized\r\n\r\n", false, 1); f4.start();
        Rec r4 = new Rec(); NtripClient c4 = new NtripClient(cfg(f4.port(), "LHER", "Basic eDp5"), () -> null, r4);
        c4.start();
        ok(c4.join(6000) && r4.find("error:").contains("Identifiants refusés"), "401 → « Identifiants refusés », arrêt", null);

        FakeCaster f5 = new FakeCaster("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n", false, 1); f5.start();
        Rec r5 = new Rec(); NtripClient c5 = new NtripClient(cfg(f5.port(), "LHER", null), () -> null, r5);
        c5.start();
        ok(c5.join(6000) && r5.find("error:").contains("NTRIP v2"), "réponse chunked (NTRIP v2) : refusée avec un message clair", null);

        System.out.println("\n── NTRIP : coupure puis reconnexion ──");
        FakeCaster f6 = new FakeCaster("ICY 200 OK\r\n", true, 2); f6.start();
        Rec r6 = new Rec(); NtripClient c6 = new NtripClient(cfg(f6.port(), "LHER", null), () -> GGA, r6);
        c6.start(); Thread.sleep(2600); c6.stop(); c6.join(5000);
        ok(f6.accepted == 2, "le caster coupe la première connexion : seconde connexion établie", f6.accepted + " connexion(s)");
        ok(r6.has("reconnecting:") && r6.find("reconnecting:").contains("1 s"), "état « reconnecting » annoncé", r6.find("reconnecting:"));
        long conn = r6.states.stream().filter(s -> s.startsWith("connected:")).count();
        ok(conn >= 2, "« connected » émis à chaque connexion", conn + " fois");

        System.out.println("\n── NTRIP : caster injoignable ──");
        ServerSocket dead = new ServerSocket(0); int deadPort = dead.getLocalPort(); dead.close();
        Rec r7 = new Rec(); NtripClient c7 = new NtripClient(cfg(deadPort, "LHER", null), () -> null, r7);
        c7.start(); Thread.sleep(900); c7.stop(); ok(c7.join(5000), "arrêt possible pendant les essais", null);
        ok(r7.has("error:") && r7.has("reconnecting:") && c7.bytes() == 0, "connexion refusée : erreur puis nouvel essai, zéro octet", r7.find("error:"));
    }

    public static void main(String[] a) throws Exception {
        nmea(); queue(); profiles(); ntrip();
        System.out.println("\n" + (fails == 0 ? "✅ " + n + " assertions vertes." : "❌ " + fails + "/" + n + " en échec."));
        System.exit(fails == 0 ? 0 : 1);
    }
}
