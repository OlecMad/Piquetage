/* Tests du noyau RTK (www/rtk-core.js) — exécution : node tools/test-rtk-core.js

   Faux plugin GnssBridge + horloge simulée : aucune attente réelle, aucun
   navigateur. Trames NMEA authentiques (sommes de contrôle calculées).
   Les valeurs attendues (Lambert-93, RAF20) viennent de geo.js, lui-même
   validé contre PROJ 9.5.1 dans Diagnostic Fluvial.

   Ne remplace pas l'essai avec la vraie canne : voir README, « Essai terrain ». */
const fs = require('fs');
const path = require('path');
const G = require('../www/geo.js');
eval(fs.readFileSync(path.join(__dirname, '../www/raf20.js'), 'utf8').replace('window.RAF20', 'globalThis.RAF20'));
G.loadGeoid(globalThis.RAF20);
const RtkCore = require('../www/rtk-core.js');

let fails = 0, n = 0;
function ok(c, label, detail) {
  n++;
  console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : ''));
  if (!c) fails++;
}

const LAT = 47.1833, LON = 1.0940, H_ELL = 100.000, SEP = 47.000;

/* ---- horloge simulée ---- */
function makeClock() {
  let t = 1000000, id = 0;
  const timers = new Map();
  return {
    now: () => t,
    setTimeout: (f, ms) => { const h = ++id; timers.set(h, { f, at: t + ms, every: 0 }); return h; },
    clearTimeout: (h) => timers.delete(h),
    setInterval: (f, ms) => { const h = ++id; timers.set(h, { f, at: t + ms, every: ms }); return h; },
    clearInterval: (h) => timers.delete(h),
    pending: () => timers.size,
    advance(ms) {
      const end = t + ms;
      for (;;) {
        let nextH = null, next = null;
        for (const [h, x] of timers) if (x.at <= end && (next === null || x.at < next.at)) { next = x; nextH = h; }
        if (next === null) break;
        t = next.at;
        if (next.every) next.at += next.every; else timers.delete(nextH);
        next.f();
      }
      t = end;
    }
  };
}
const flush = async () => { for (let i = 0; i < 6; i++) await Promise.resolve(); };

/* ---- faux plugin GnssBridge ---- */
function makePlugin(opts) {
  opts = opts || {};
  const listeners = {};
  const calls = { connect: [], startNtrip: [], stopNtrip: 0, disconnect: 0, list: 0 };
  const plugin = {
    failConnect: !!opts.failConnect,
    devices: opts.devices || [
      { name: 'Galaxy Buds', address: 'AA:AA:AA:AA:AA:AA', type: 1 },
      { name: 'RTK_GNSS_4F2A', address: '00:11:22:33:44:55', type: 1 }
    ],
    addListener: (evt, cb) => { (listeners[evt] = listeners[evt] || []).push(cb); return Promise.resolve({ remove: () => Promise.resolve() }); },
    bleDevices: opts.bleDevices || [
      { name: 'Montre', address: 'BB:BB:BB:BB:BB:01', rssi: -50, rtk: false, services: [] },
      { name: 'RTK_GNSS_BLE', address: 'BB:BB:BB:BB:BB:02', rssi: -61, rtk: true, services: ['6e400001-b5a3-f393-e0a9-e50e24dcca9e'] }
    ],
    usbDevices: opts.usbDevices || [
      { id: '1546:01a9', name: 'u-blox GNSS receiver', manufacturer: 'u-blox AG', supported: true, chip: 'CdcAcm', hasPermission: false },
      { id: '0951:1666', name: 'Clé USB', manufacturer: '', supported: false, chip: '', hasPermission: true }
    ],
    scanError: null, usbError: null,
    listDevices: () => { calls.list++; return Promise.resolve({ devices: plugin.devices }); },
    scanBle: (o) => { calls.scan = (calls.scan || 0) + 1; calls.scanArgs = o; return plugin.scanError ? Promise.reject(new Error(plugin.scanError)) : Promise.resolve({ devices: plugin.bleDevices }); },
    listUsb: () => { calls.usb = (calls.usb || 0) + 1; return plugin.usbError ? Promise.reject(new Error(plugin.usbError)) : Promise.resolve({ devices: plugin.usbDevices }); },
    connect: (o) => { calls.connect.push(o); return plugin.failConnect ? Promise.reject(new Error('échec simulé')) : Promise.resolve({ address: o.address, transport: o.transport, info: 'info-' + o.transport }); },
    disconnect: () => { calls.disconnect++; return Promise.resolve(); },
    startNtrip: (o) => { calls.startNtrip.push(o); return Promise.resolve(); },
    stopNtrip: () => { calls.stopNtrip++; return Promise.resolve(); },
    emit: (evt, data) => (listeners[evt] || []).forEach((cb) => cb(data))
  };
  plugin.calls = calls;
  return plugin;
}

/* ---- trames NMEA ---- */
function cs(b) { let c = 0; for (const ch of b) c ^= ch.charCodeAt(0); return '$' + b + '*' + c.toString(16).toUpperCase().padStart(2, '0'); }
function dm(v, w) { const d = Math.floor(Math.abs(v)); const m = (Math.abs(v) - d) * 60; return String(d).padStart(w, '0') + m.toFixed(7).padStart(10, '0'); }
let tick = 0;
function nmea(plugin, q, opt) {
  opt = opt || {};
  const lat = opt.lat !== undefined ? opt.lat : LAT, lon = opt.lon !== undefined ? opt.lon : LON, hEll = opt.hEll !== undefined ? opt.hEll : H_ELL;
  tick++;
  const s = tick % 60;
  const time = '120' + String(Math.floor(tick / 60) % 10) + String(s).padStart(2, '0') + '.00';
  plugin.emit('nmea', { line: cs('GNGGA,' + time + ',' + dm(lat, 2) + ',N,' + dm(lon, 3) + ',E,' + q + ',20,0.50,' + (hEll - SEP).toFixed(4) + ',M,' + SEP.toFixed(4) + ',M,1.0,0412') });
  if (opt.gst !== false) plugin.emit('nmea', { line: cs('GNGST,' + time + ',0.012,0.010,0.008,45.0,0.009,0.008,0.015') });
}

function memStore() { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, _m: m }; }

async function setup(opts) {
  opts = opts || {};
  const clock = makeClock();
  const plugin = makePlugin(opts.plugin);
  const store = opts.store || memStore();
  const rtk = RtkCore.create({ geo: G, plugin: opts.noPlugin ? null : plugin, storage: store, timers: clock });
  const msgs = [];
  rtk.on('message', (m) => msgs.push(m));
  return { clock, plugin, store, rtk, msgs };
}

/* =========================================================== */
(async () => {
  console.log('\n── Démarrage et appareils ──');
  {
    const { rtk, plugin, store } = await setup();
    const st = rtk.status();
    ok(st.code === 'OFF' && st.label === 'Non reliée' && st.available, 'état initial « Non reliée »');
    ok(!st.heights.complete && st.heights.missing.length === 2, 'hauteurs non saisies : aucune valeur par défaut');
    ok(rtk.settings.transport === 'ble' && st.transport === 'ble', 'liaison par défaut : Bluetooth LE');
    rtk.set('transport', 'classic');
    const devs = await rtk.refreshDevices();
    ok(devs.length === 2 && plugin.calls.list === 1, 'appareils Bluetooth Classic appairés listés');
    ok(rtk.settings.sel.classic.address === '00:11:22:33:44:55' && rtk.settings.sel.classic.name === 'RTK_GNSS_4F2A', 'récepteur RTK_GNSS_* présélectionné');
    ok(JSON.parse(store._m['piquetage.rtk']).sel.classic.address === '00:11:22:33:44:55', 'sélection mémorisée');
  }
  {
    const { rtk } = await setup({ noPlugin: true });
    ok(!rtk.status().available && (await rtk.refreshDevices()).length === 0, 'sans plugin (navigateur) : lecture seule');
    let err = null; await rtk.connect().catch((e) => { err = e; });
    ok(err && /application Android/.test(err.message), 'connexion refusée avec un message clair', err && err.message);
  }

  console.log('\n── Connexion et NTRIP ──');
  const ctx = await setup();
  const { rtk, plugin, clock, msgs } = ctx;
  rtk.set('transport', 'classic');
  await rtk.refreshDevices();
  await rtk.connect();
  await flush();
  ok(plugin.calls.connect.length === 1 && plugin.calls.connect[0].address === '00:11:22:33:44:55' && plugin.calls.connect[0].transport === 'classic', 'connexion Bluetooth Classic à la bonne adresse');
  ok(rtk.status().linkInfo === 'info-classic', 'détails de la liaison relayés par le plugin');
  const nt = plugin.calls.startNtrip[0] || {};
  ok(nt.host === 'crtk.net' && nt.port === 2101 && nt.mountpoint === 'NEAR' && nt.user === 'centipede' && nt.password === 'centipede' && nt.ggaInterval === 10,
    'NTRIP : paramètres Centipede par défaut', JSON.stringify(nt));
  ok(rtk.status().connected && rtk.status().code === 'NONE' && rtk.status().label === 'Aucune trame', 'relié, en attente de trames');
  plugin.emit('ntrip', { state: 'connected', bytes: 4096 });
  ok(rtk.status().ntrip.state === 'connected' && rtk.status().ntrip.bytes === 4096, 'état NTRIP et octets reçus relayés');
  plugin.emit('ntrip', { state: 'error', message: 'refusé' });
  ok(msgs.some((m) => m === 'NTRIP : refusé'), 'erreur NTRIP signalée une fois');

  console.log('\n── Position en direct ──');
  nmea(plugin, 4);
  let st = rtk.status();
  ok(st.code === 'FIX' && st.label === 'RTK FIX' && st.fresh, 'RTK FIX');
  ok(st.sats === 20 && st.hdop === 0.5 && st.diffAge === 1, '20 satellites, HDOP 0,50, âge des corrections 1,0 s');
  ok(st.gstAvailable && rtk.cm(st.sdH) === '1,2 cm' && rtk.cm(st.sdV) === '1,5 cm', 'σ horizontal 1,2 cm et vertical 1,5 cm issus de la GST');
  const exp = G.toLambert93(LAT, LON), N = G.geoidN(LAT, LON);
  ok(Math.abs(st.point.x93 - exp.x) < 1e-3 && Math.abs(st.point.y93 - exp.y) < 1e-3, 'Lambert-93 en direct', st.point.x93.toFixed(3) + ' ; ' + st.point.y93.toFixed(3));
  ok(st.point.hNgfGround === null && Math.abs(st.point.hNgfAntenna - (H_ELL - N)) < 1e-4, 'sans hauteurs saisies : altitude de l’antenne seule', st.point.hNgfAntenna.toFixed(4));
  rtk.set('pole', '2,000'); rtk.set('apc', '0,0615');
  st = rtk.status();
  ok(rtk.settings.pole === '2.000' && st.heights.complete, 'virgule décimale acceptée');
  ok(Math.abs(st.point.hNgfGround - (H_ELL - N - 2 - 0.0615)) < 1e-4, 'H sol = h − N(RAF20) − canne − centre de phase', st.point.hNgfGround.toFixed(4));
  nmea(plugin, 5);
  ok(rtk.status().code === 'FLOAT', 'RTK FLOAT');
  nmea(plugin, 1);
  ok(rtk.status().code === 'GPS', 'GPS autonome');
  clock.advance(3100);
  ok(rtk.status().code === 'NONE' && !rtk.status().fresh, 'sans trame pendant 3 s : « Aucune trame »');

  console.log('\n── Levé d’un point ──');
  {
    rtk.set('avg', 5); rtk.set('requireFix', true);
    nmea(plugin, 5);
    let err = null; await rtk.capture().catch((e) => { err = e; });
    ok(err && /RTK FIX exigé/.test(err.message), 'point refusé en FLOAT quand le FIX est exigé', err && err.message);

    nmea(plugin, 4);
    clock.advance(10);          // l'époque précédente est antérieure au début de la mesure
    const prom = rtk.capture();
    for (let i = 0; i < 5; i++) { clock.advance(1000); nmea(plugin, 4, { hEll: H_ELL + i * 0.002 }); }
    clock.advance(1000);       // dernier passage de l'intervalle, puis attente de la GST (350 ms)
    clock.advance(400);
    const p = await prom;
    ok(p.epochsRequested === 5 && Math.abs(p.x93 - exp.x) < 1e-3 && Math.abs(p.y93 - exp.y) < 1e-3, 'point moyenné sur 5 époques, Lambert-93 exact', p.x93.toFixed(3) + ' ; ' + p.y93.toFixed(3));
    ok(Math.abs(p.hNgfGround - (H_ELL + 0.004 - N - 2 - 0.0615)) < 1e-3, 'altitude moyennée = moyenne des hauteurs − N − hauteurs saisies', p.hNgfGround.toFixed(4));
    ok(p.receiver === 'RTK_GNSS_4F2A' && p.mountpoint === 'NEAR' && p.acc !== null && /^\d{4}-/.test(p.t), 'récepteur, point de montage, précision et date enregistrés');
    ok(msgs.some((m) => /5 \/ 5 époques/.test(m)), 'progression « n / 5 époques » annoncée');

    // une mesure ne peut pas en chevaucher une autre
    nmea(plugin, 4);
    const a = rtk.capture(); let dup = null; await rtk.capture().catch((e) => { dup = e; });
    ok(dup && /déjà en cours/.test(dup.message), 'deuxième mesure refusée pendant la première');
    clock.advance(2000); nmea(plugin, 4); clock.advance(15000); clock.advance(400);
    await a.catch(() => {});

    // FLOAT en cours de mesure : époques écartées et comptées
    rtk.set('avg', 1);
    nmea(plugin, 4);
    const one = rtk.capture();
    clock.advance(300); clock.advance(400);
    const p1 = await one;
    ok(p1.epochsRequested === 1 && Math.abs(p1.x93 - exp.x) < 1e-3, 'mesure instantanée (1 époque) : Lambert-93 exact');
  }

  console.log('\n── Perte de liaison et reconnexion ──');
  {
    const c = plugin.calls.connect.length, stops = plugin.calls.stopNtrip;
    plugin.emit('bluetooth', { state: 'disconnected', message: 'perdu' });
    ok(!rtk.status().connected && rtk.status().label === 'Reconnexion…', 'liaison perdue : « Reconnexion… »');
    ok(plugin.calls.stopNtrip === stops + 1 && msgs.some((m) => /reconnexion automatique/.test(m)), 'NTRIP arrêté et opérateur prévenu');
    clock.advance(4900);
    ok(plugin.calls.connect.length === c, 'pas de nouvelle tentative avant 5 s');
    clock.advance(200);
    await flush();
    ok(plugin.calls.connect.length === c + 1, 'reconnexion automatique après 5 s');
    ok(rtk.status().connected && plugin.calls.startNtrip.length >= 2, 'reliée de nouveau, NTRIP relancé');

    plugin.failConnect = true;
    plugin.emit('bluetooth', { state: 'disconnected' });
    clock.advance(5100); await flush();
    const c2 = plugin.calls.connect.length;
    clock.advance(5100); await flush();
    ok(plugin.calls.connect.length === c2 + 1, 'échec de reconnexion : nouvel essai programmé');

    rtk.disconnect();
    const c3 = plugin.calls.connect.length;
    clock.advance(30000); await flush();
    ok(plugin.calls.connect.length === c3 && plugin.calls.disconnect >= 1, 'déconnexion volontaire : plus aucune reconnexion');
    ok(rtk.status().label === 'Non reliée', 'état « Non reliée » après déconnexion');
  }

  console.log('\n── Liaison Bluetooth LE ──');
  {
    const { rtk: r, plugin: p } = await setup();
    ok(r.settings.transport === 'ble', 'Bluetooth LE par défaut');
    const pr = r.scanBle(); const pr2 = r.scanBle();
    ok(r.status().scanning && p.calls.scan === 1, 'recherche en cours signalée ; un second appel ne relance pas la recherche');
    const devs = await pr; await pr2;
    ok(!r.status().scanning && devs.length === 2 && devs[1].rtk && devs[1].rssi === -61, 'appareils trouvés avec leur puissance (RSSI)');
    ok(p.calls.scanArgs.duration === 6000, 'durée de recherche : 6 s');
    ok(r.settings.sel.ble.address === 'BB:BB:BB:BB:BB:02' && r.settings.sel.ble.name === 'RTK_GNSS_BLE', 'un seul appareil de type RTK trouvé : présélectionné');
    await r.connect(); await flush();
    const c = p.calls.connect[p.calls.connect.length - 1];
    ok(c.transport === 'ble' && c.address === 'BB:BB:BB:BB:BB:02' && c.usbId === undefined && c.baud === undefined, 'connexion BLE : transport et adresse seulement', JSON.stringify(c));
    ok(r.status().connected && r.status().linkInfo === 'info-ble' && r.status().transport === 'ble', 'relié en BLE, détails de la liaison conservés');
    p.emit('bluetooth', { state: 'connected', transport: 'ble', info: 'Bluetooth LE · Nordic UART · MTU 247' });
    ok(r.status().linkInfo.includes('Nordic UART'), 'événement « connected » : détails mis à jour (profil BLE, MTU)');
    const n0 = p.calls.connect.length;
    p.emit('bluetooth', { state: 'disconnected', message: 'perdu' });
    ok(r.status().label === 'Reconnexion…', 'liaison BLE perdue : reconnexion annoncée');
    r.disconnect();
    p.failConnect = false;
    ok(p.calls.connect.length === n0, 'déconnexion volontaire : pas de reconnexion');
  }
  {
    const { rtk: r, plugin: p, msgs } = await setup({ plugin: { bleDevices: [
      { name: 'Montre', address: 'BB:BB:BB:BB:BB:01', rssi: -50, rtk: false, services: [] },
      { name: 'Casque', address: 'BB:BB:BB:BB:BB:03', rssi: -70, rtk: false, services: [] }] } });
    await r.scanBle();
    ok(r.settings.sel.ble.address === '' , 'aucun appareil de type RTK : rien n’est présélectionné');
    const res = await r.connect();
    ok(res === false && p.calls.connect.length === 0 && msgs.some((m) => /recherche BLE/.test(m)), 'connexion sans appareil choisi : message, aucun appel au plugin');
    r.select('BB:BB:BB:BB:BB:03');
    ok(r.settings.sel.ble.address === 'BB:BB:BB:BB:BB:03' && r.settings.sel.ble.name === 'Casque', 'choix manuel dans la liste : nom retrouvé');
    p.scanError = 'Échec de la recherche BLE (code 2) : trop de recherches rapprochées, attendre 30 s';
    const none = await r.scanBle();
    ok(none.length === 0 && !r.status().scanning && msgs.some((m) => /trop de recherches/.test(m)), 'échec de la recherche : message du plugin, état « recherche » rétabli');
  }
  {
    const { rtk: r } = await setup({ plugin: { bleDevices: [] } });
    const none = await r.scanBle();
    ok(none.length === 0, 'aucun appareil BLE : liste vide, message à l’opérateur');
  }

  console.log('\n── Liaison USB ──');
  {
    const { rtk: r, plugin: p, msgs } = await setup();
    r.set('transport', 'usb');
    const devs = await r.refreshUsb();
    ok(devs.length === 2 && devs[0].supported && devs[0].chip === 'CdcAcm' && !devs[1].supported, 'appareils USB listés avec le pilote reconnu');
    ok(r.settings.sel.usb.id === '1546:01a9' && r.settings.sel.usb.name === 'u-blox GNSS receiver', 'un seul appareil reconnu : présélectionné');
    await r.connect(); await flush();
    const c = p.calls.connect[p.calls.connect.length - 1];
    ok(c.transport === 'usb' && c.usbId === '1546:01a9' && c.baud === 115200 && c.address === undefined, 'connexion USB : identifiant et vitesse', JSON.stringify(c));
    ok(r.status().linkInfo === 'info-usb' && p.calls.startNtrip.length >= 1, 'relié en USB, corrections NTRIP lancées');
    r.disconnect();
    r.set('baud', '460800');
    ok(r.settings.baud === 460800, 'vitesse USB : 460 800 bauds');
    await r.connect(); await flush();
    ok(p.calls.connect[p.calls.connect.length - 1].baud === 460800, 'la vitesse choisie est transmise');
    let bad = null; try { r.set('baud', '12345'); } catch (e) { bad = e; }
    ok(bad && r.settings.baud === 460800, 'vitesse hors liste refusée, réglage inchangé');
    p.usbError = 'Cet appareil n’a pas de port USB hôte';
    await r.refreshUsb();
    ok(msgs.some((m) => /port USB hôte/.test(m)), 'erreur USB du plugin affichée');
  }
  {
    const { rtk: r, msgs } = await setup({ plugin: { usbDevices: [] } });
    r.set('transport', 'usb');
    await r.refreshUsb();
    ok(msgs.some((m) => /câble OTG/.test(m)), 'aucun appareil USB : conseil sur le câble OTG et l’alimentation');
    const res = await r.connect();
    ok(res === false && msgs.some((m) => /appareil USB/.test(m)), 'connexion USB sans appareil choisi : message');
  }
  {
    const { rtk: r } = await setup({ plugin: { usbDevices: [
      { id: '0951:1666', name: 'Clé USB', manufacturer: '', supported: false, chip: '', hasPermission: true }] } });
    r.set('transport', 'usb');
    await r.refreshUsb();
    ok(r.settings.sel.usb.id === '', 'seul appareil USB non reconnu : jamais présélectionné');
  }

  console.log('\n── Un récepteur mémorisé par mode, anciens réglages ──');
  {
    const { rtk: r, store } = await setup();
    r.set('transport', 'ble'); await r.scanBle();
    r.set('transport', 'usb'); await r.refreshUsb();
    r.set('transport', 'classic'); await r.refreshDevices();
    ok(r.settings.sel.ble.address === 'BB:BB:BB:BB:BB:02' && r.settings.sel.usb.id === '1546:01a9' && r.settings.sel.classic.address === '00:11:22:33:44:55', 'chaque mode garde son propre récepteur');
    r.set('transport', 'usb');
    ok(r.current().id === '1546:01a9', 'changer de mode retrouve le récepteur de ce mode');
    const r2 = RtkCore.create({ geo: G, plugin: null, storage: store, timers: makeClock() });
    ok(r2.settings.transport === 'usb' && r2.settings.sel.ble.address === 'BB:BB:BB:BB:BB:02' && r2.settings.sel.classic.name === 'RTK_GNSS_4F2A', 'mode et récepteurs relus au redémarrage');
    let bad = null; try { r.set('transport', 'wifi'); } catch (e) { bad = e; }
    ok(bad && r.settings.transport === 'usb', 'mode de liaison inconnu refusé');
    const old = memStore(); old.setItem('piquetage.rtk', JSON.stringify({ address: '00:11:22:33:44:55', name: 'RTK_GNSS_OLD', avg: 10, ntrip: { mount: 'LHER' } }));
    const r3 = RtkCore.create({ geo: G, plugin: null, storage: old, timers: makeClock() });
    ok(r3.settings.transport === 'classic' && r3.settings.sel.classic.address === '00:11:22:33:44:55' && r3.settings.sel.classic.name === 'RTK_GNSS_OLD', 'réglages d’une version antérieure : repris en Bluetooth Classic');
    ok(r3.settings.avg === 10 && r3.settings.ntrip.mount === 'LHER', 'autres réglages conservés');
    const weird = memStore(); weird.setItem('piquetage.rtk', JSON.stringify({ transport: 'wifi', baud: 7 }));
    const r4 = RtkCore.create({ geo: G, plugin: null, storage: weird, timers: makeClock() });
    ok(r4.settings.transport === 'ble' && r4.settings.baud === 115200, 'valeurs inconnues relues : retour aux valeurs par défaut');
  }
  {
    const { rtk: r } = await setup({ noPlugin: true });
    ok((await r.scanBle()).length === 0 && (await r.refreshUsb()).length === 0 && (await r.refresh()).length === 0, 'sans plugin (navigateur) : listes vides, pas d’erreur');
  }

  console.log('\n── Réglages ──');
  {
    const { rtk: r, store } = await setup();
    r.set('ntrip.mount', ' LHER '); r.set('ntrip.port', '2102'); r.set('ntrip.gga', 'abc'); r.set('avg', '10'); r.set('requireFix', false);
    ok(r.settings.ntrip.mount === 'LHER' && r.settings.ntrip.port === 2102, 'point de montage nettoyé, port numérique');
    ok(r.settings.ntrip.gga === 10, 'valeur invalide : retour à la valeur par défaut');
    const r2 = RtkCore.create({ geo: G, plugin: null, storage: store, timers: makeClock() });
    ok(r2.settings.ntrip.mount === 'LHER' && r2.settings.avg === 10 && r2.settings.requireFix === false, 'réglages relus au redémarrage');
    let bad = null; try { r.set('inconnu', 1); } catch (e) { bad = e; }
    ok(!!bad, 'réglage inconnu refusé');
    const corrupt = memStore(); corrupt.setItem('piquetage.rtk', '{pas du json');
    const r3 = RtkCore.create({ geo: G, plugin: null, storage: corrupt, timers: makeClock() });
    ok(r3.settings.ntrip.host === 'crtk.net', 'stockage corrompu : réglages par défaut');
  }

  console.log('\n── Nettoyage ──');
  {
    const { rtk: r, clock: c } = await setup();
    r.dispose();
    ok(c.pending() === 0, 'dispose() arrête toutes les horloges');
  }

  console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
