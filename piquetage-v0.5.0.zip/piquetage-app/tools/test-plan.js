/* Tests de l'import de plans GeoPackage (www/plan.js) — exécution : node tools/test-plan.js
   · géométries WKB (ISO, EWKB, gros/petit boutiste, enveloppes, vides) ;
   · couches synthétiques fabriquées avec sql.js ;
   · votre vrai plan si le fichier est présent (PIQ_GPKG ou /mnt/user-data/uploads/…).
   Écrit /tmp/piq-fixtures/synthetique.gpkg pour tools/verify-import.js. */
const fs = require('fs');
const path = require('path');
const initSqlJs = require('../www/vendor/sqljs/sql-wasm.js');
const P = require('../www/plan.js');

let fails = 0, n = 0;
function ok(c, label, detail) { n++; console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : '')); if (!c) fails++; }
const near = (a, b, t) => typeof a === 'number' && Math.abs(a - b) <= (t === undefined ? 1e-9 : t);

/* ---------- encodage WKB / GeoPackage pour les tests ---------- */
function w() {
  const parts = [];
  return {
    u8: (v) => parts.push(Buffer.from([v])),
    u32: (v, le) => { const b = Buffer.alloc(4); le ? b.writeUInt32LE(v >>> 0) : b.writeUInt32BE(v >>> 0); parts.push(b); },
    i32: (v, le) => { const b = Buffer.alloc(4); le ? b.writeInt32LE(v) : b.writeInt32BE(v); parts.push(b); },
    f64: (v, le) => { const b = Buffer.alloc(8); le ? b.writeDoubleLE(v) : b.writeDoubleBE(v); parts.push(b); },
    raw: (b) => parts.push(Buffer.from(b)),
    done: () => Buffer.concat(parts)
  };
}
// mode : 'iso' (1001…), 'ewkb' (indicateur 0x80000000), 'xy' (sans Z)
function wkb(g, o) {
  o = Object.assign({ le: true, mode: 'iso', z: true }, o);
  const out = w();
  function head(base) {
    out.u8(o.le ? 1 : 0);
    let t = base;
    if (o.z && o.mode === 'iso') t += 1000;
    if (o.z && o.mode === 'ewkb') t = (t | 0x80000000) >>> 0;
    out.u32(t, o.le);
  }
  function pt(p) { out.f64(p[0], o.le); out.f64(p[1], o.le); if (o.z) out.f64(p[2] === null || p[2] === undefined ? NaN : p[2], o.le); }
  function pts(a) { out.u32(a.length, o.le); a.forEach(pt); }
  function geom(x) {
    switch (x.type) {
      case 'Point': head(1); pt(x.c); break;
      case 'LineString': head(2); pts(x.c); break;
      case 'Polygon': head(3); out.u32(x.c.length, o.le); x.c.forEach(pts); break;
      case 'MultiPolygon': head(6); out.u32(x.c.length, o.le); x.c.forEach((c) => geom({ type: 'Polygon', c })); break;
      case 'MultiPoint': head(4); out.u32(x.c.length, o.le); x.c.forEach((c) => geom({ type: 'Point', c })); break;
      default: throw new Error('type de test ?');
    }
  }
  geom(g);
  return out.done();
}
// en-tête GeoPackage ; env : 0 aucune, 1 XY (32 o), 3 XYZM? (48 o)
function gp(wkbBuf, srs, o) {
  o = Object.assign({ le: true, env: 0, empty: false }, o);
  const out = w();
  out.raw([0x47, 0x50, 0]);
  out.u8((o.le ? 1 : 0) | (o.env << 1) | (o.empty ? 0x10 : 0));
  out.i32(srs, o.le);
  const size = [0, 32, 48, 48, 64][o.env];
  out.raw(Buffer.alloc(size));
  if (!o.empty) out.raw(wkbBuf);
  return out.done();
}

/* ---------- décodage direct ---------- */
console.log('\n── Décodage des géométries ──');
{
  const pz = { type: 'Point', c: [555700.1234, 6677600.9876, 50.4321] };
  let d = P.decode(gp(wkb(pz), 2154));
  ok(d.srs === 2154 && d.g.type === 'Point' && near(d.g.c[0], 555700.123) && near(d.g.c[1], 6677600.988) && near(d.g.c[2], 50.432), 'point Z (ISO 1001) : arrondi au millimètre', JSON.stringify(d.g.c));
  d = P.decode(gp(wkb(pz, { mode: 'ewkb' }), 2154));
  ok(d.g.type === 'Point' && near(d.g.c[2], 50.432), 'point Z au format EWKB (indicateur 0x80000000)');
  d = P.decode(gp(wkb(pz, { le: false }), 2154, { le: false }));
  ok(d.srs === 2154 && d.g.type === 'Point' && near(d.g.c[0], 555700.123), 'gros boutiste (en-tête et WKB)');
  d = P.decode(gp(wkb({ type: 'Point', c: [1, 2] }, { z: false }), 2154));
  ok(d.g.c[2] === null, 'point sans Z : Z = null (jamais 0)');
  d = P.decode(gp(wkb({ type: 'Point', c: [1, 2, null] }, { z: true }), 2154));
  ok(d.g.c[2] === null, 'Z codé NaN : null');
  for (const env of [1, 3]) {
    d = P.decode(gp(wkb({ type: 'Point', c: [5, 6, 7] }), 2154, { env }));
    ok(d.g.type === 'Point' && d.g.c[0] === 5 && d.g.c[2] === 7, 'enveloppe de ' + [0, 32, 48, 48][env] + ' octets sautée');
  }
  d = P.decode(gp(null, 2154, { empty: true }));
  ok(d.empty === true && !d.g, 'géométrie vide (indicateur)');
  const nanPt = w(); nanPt.u8(1); nanPt.u32(1, true); nanPt.f64(NaN, true); nanPt.f64(NaN, true);
  d = P.decode(gp(nanPt.done(), 2154));
  ok(d.g.type === 'Point' && d.g.c === null, 'point vide (NaN)');
  const ln = { type: 'LineString', c: [[0, 0, 1], [10, 0, 2], [10, 10, 3]] };
  d = P.decode(gp(wkb(ln), 2154));
  ok(d.g.type === 'LineString' && d.g.c.length === 3 && d.g.c[2][2] === 3, 'ligne Z de 3 sommets');
  const poly = { type: 'Polygon', c: [[[0, 0, 5], [10, 0, 5], [10, 10, 5], [0, 0, 5]], [[2, 2, 5], [3, 2, 5], [3, 3, 5], [2, 2, 5]]] };
  d = P.decode(gp(wkb(poly), 2154));
  ok(d.g.type === 'Polygon' && d.g.c.length === 2 && d.g.c[1].length === 4, 'polygone avec un trou');
  const mp = { type: 'MultiPolygon', c: [poly.c, [[[20, 20, 5], [30, 20, 5], [30, 30, 5], [20, 20, 5]]]] };
  d = P.decode(gp(wkb(mp, { le: false }), 2154, { le: false }));
  ok(d.g.type === 'MultiPolygon' && d.g.c.length === 2 && d.g.c[0].length === 2, 'multipolygone gros boutiste');
  ok(P.vertices(d.g).length === 4 + 4 + 4, 'sommets d’un multipolygone : 12', P.vertices(d.g).length);
  const bad = w(); bad.u8(1); bad.u32(8, true); bad.u32(0, true);   // CircularString : non pris en charge
  d = P.decode(gp(bad.done(), 2154));
  ok(d.error && /non pris en charge/.test(d.error), 'courbes : refusées avec un message', d.error);
  ok(P.decode(Buffer.from('pas un blob')).error && P.decode(null).error, 'blob invalide : erreur, pas de plantage');
  ok(P.zQuality(0) === 'zero' && P.zQuality(-9999) === 'nodata' && P.zQuality(null) === 'absent' && P.zQuality(NaN) === 'absent' && P.zQuality(120.5) === 'ok' && P.zQuality(-3.2) === 'ok', 'qualité du Z : 0 et -9999 signalés');
}

(async () => {
  const SQL = await initSqlJs({ locateFile: (f) => path.join(__dirname, '../www/vendor/sqljs', f) });

  /* ---------- GeoPackage synthétique ---------- */
  function fixture() {
    const db = new SQL.Database();
    db.run('CREATE TABLE gpkg_spatial_ref_sys (srs_name TEXT, srs_id INTEGER PRIMARY KEY, organization TEXT, organization_coordsys_id INTEGER, definition TEXT)');
    db.run("INSERT INTO gpkg_spatial_ref_sys VALUES ('RGF93 / Lambert-93', 2154, 'EPSG', 2154, 'x'), ('WGS 84', 4326, 'EPSG', 4326, 'x'), ('WGS 84 / Pseudo-Mercator', 3857, 'EPSG', 3857, 'x'), ('Undefined', 0, 'NONE', 0, 'x')");
    db.run('CREATE TABLE gpkg_contents (table_name TEXT PRIMARY KEY, data_type TEXT, identifier TEXT, srs_id INTEGER)');
    db.run('CREATE TABLE gpkg_geometry_columns (table_name TEXT, column_name TEXT, geometry_type_name TEXT, srs_id INTEGER, z TINYINT, m TINYINT)');
    function layer(name, gtype, srs, z, cols, rowsData) {
      db.run(`CREATE TABLE "${name}" (fid INTEGER PRIMARY KEY AUTOINCREMENT, geom BLOB, ${cols})`);
      db.run('INSERT INTO gpkg_contents VALUES (?,?,?,?)', [name, 'features', name + ' (titre)', srs]);
      db.run('INSERT INTO gpkg_geometry_columns VALUES (?,?,?,?,?,0)', [name, 'geom', gtype, srs, z]);
      const colNames = cols.split(',').map((c) => c.trim().split(' ')[0]);
      rowsData.forEach((r) => db.run(`INSERT INTO "${name}" (geom, ${colNames.join(',')}) VALUES (${['?'].concat(colNames.map(() => '?')).join(',')})`, [r[0]].concat(r.slice(1))));
    }
    const B = (x) => new Uint8Array(x);
    layer('arbres_z', 'POINT', 2154, 1, 'num TEXT, hauteur REAL', [
      [B(gp(wkb({ type: 'Point', c: [555700, 6677600, 120.5] }), 2154)), 'A1', 3.5],
      [B(gp(wkb({ type: 'Point', c: [555701, 6677600, 0] }), 2154)), 'A2', 3.5],
      [B(gp(wkb({ type: 'Point', c: [555702, 6677600, -9999] }), 2154)), 'A3', 3.5]]);
    layer('arbres_2d', 'POINT', 2154, 0, 'num INTEGER, z_terrain REAL, nom TEXT, pente REAL', [
      [B(gp(wkb({ type: 'Point', c: [555710, 6677610] }, { z: false }), 2154)), 1, 121.2, 'chêne', 2],
      [B(gp(wkb({ type: 'Point', c: [555711, 6677610] }, { z: false }), 2154)), 2, null, 'érable', 2],
      [B(gp(wkb({ type: 'Point', c: [555712, 6677610] }, { z: false }), 2154)), 3, '122,5', 'tilleul', 2]]);
    layer('haies', 'LINESTRING', 2154, 1, 'nom TEXT, z_haie REAL', [
      [B(gp(wkb({ type: 'LineString', c: [[555700, 6677620, 100], [555710, 6677620, 101], [555720, 6677620, 102]] }), 2154)), 'H1', 100.5],
      [B(gp(wkb({ type: 'LineString', c: [[555700, 6677625, 100], [555710, 6677625, 0], [555720, 6677625, 102]] }), 2154)), 'H2', 100.5]]);
    layer('mares', 'MULTIPOLYGON', 2154, 0, 'nom TEXT, profondeur_m REAL, z_fond_ngf REAL', [
      [B(gp(wkb({ type: 'MultiPolygon', c: [[[[555730, 6677630], [555740, 6677630], [555740, 6677640], [555730, 6677630]]]] }, { z: false, le: false }), 2154, { le: false })), 'M1', 0.5, 119.8]]);
    layer('wgs', 'POINT', 4326, 0, 'nom TEXT', [[B(gp(wkb({ type: 'Point', c: [1.09, 47.18] }, { z: false }), 4326)), 'W1']]);
    layer('merc', 'POINT', 3857, 0, 'nom TEXT', [[B(gp(wkb({ type: 'Point', c: [121000, 6000000] }, { z: false }), 3857)), 'X1']]);
    layer('inconnue', 'POINT', 0, 0, 'nom TEXT', [[B(gp(wkb({ type: 'Point', c: [1, 2] }, { z: false }), 0)), 'I1']]);
    const circ = w(); circ.u8(1); circ.u32(8, true); circ.u32(0, true);
    layer('melange', 'GEOMETRY', 2154, 0, 'nom TEXT', [
      [B(gp(wkb({ type: 'Point', c: [555750, 6677650] }, { z: false }), 2154)), 'P'],
      [null, 'sans géométrie'],
      [B(gp(null, 2154, { empty: true })), 'vide'],
      [B(gp(circ.done(), 2154)), 'courbe'],
      [B(gp(wkb({ type: 'LineString', c: [[0, 0], [1, 1]] }, { z: false }), 2154)), 'ligne dans une couche de points'],
      [B(gp(wkb({ type: 'Point', c: [555751, 6677651] }, { z: false }), 2154)), 'P2']]);
    return db;
  }

  console.log('\n── Lecture d’un GeoPackage synthétique ──');
  const fx = fixture();
  const bytes = fx.export();
  fs.mkdirSync('/tmp/piq-fixtures', { recursive: true });
  fs.writeFileSync('/tmp/piq-fixtures/synthetique.gpkg', Buffer.from(bytes));
  const g = P.open(SQL, bytes);
  const L = Object.fromEntries(g.layers.map((l) => [l.table, l]));
  ok(g.layers.length === 8, 'huit couches d’objets détectées', g.layers.map((l) => l.table).join(', '));
  ok(L.arbres_z.epsg === 2154 && !L.arbres_z.refused && L.arbres_z.count === 3, 'couche en EPSG:2154 acceptée, 3 objets');
  ok(L.arbres_z.geomZ === true && L.arbres_2d.geomZ === false && L.haies.geomZ === true, 'Z réellement présent dans les géométries détecté');
  ok(L.arbres_2d.zCandidates.join() === 'z_terrain', 'colonnes d’altitude proposées : z_terrain seulement', L.arbres_2d.zCandidates.join());
  ok(!L.arbres_2d.zCandidates.includes('pente') && !L.arbres_z.zCandidates.includes('hauteur') && !L.mares.zCandidates.includes('profondeur_m'), 'pente, hauteur et profondeur ne sont pas prises pour des altitudes');
  ok(L.mares.zCandidates.join() === 'z_fond_ngf' && L.haies.zCandidates.join() === 'z_haie', 'z_fond_ngf et z_haie proposées');
  ok(L.arbres_2d.labelDefault === 'num' && L.haies.labelDefault === 'nom' && L.arbres_z.labelDefault === 'num', 'étiquette proposée : num, sinon nom');
  ok(/EPSG:4326/.test(L.wgs.refused) && /EPSG:3857/.test(L.merc.refused) && /inconnue/.test(L.inconnue.refused), 'WGS 84, Mercator et projection inconnue refusés avec un message', L.wgs.refused.slice(0, 40) + '…');
  ok(/EPSG:2154/.test(L.wgs.refused) && /QGIS/.test(L.wgs.refused), 'le message dit comment corriger dans QGIS');
  let threw = null; try { P.loadLayer(g.db, L.wgs, {}); } catch (e) { threw = e; }
  ok(threw && /Projection/.test(threw.message), 'charger une couche refusée : erreur explicite, pas de reprojection approximative');

  console.log('\n── Chargement et qualité du Z ──');
  let l = P.loadLayer(g.db, L.arbres_z, { zField: '__geom' });
  ok(l.kind === 'point' && l.features.length === 3 && l.features[0].z === 120.5 && l.features[0].q === 'ok', 'Z de la géométrie : 120,5 ok');
  ok(l.features[1].q === 'zero' && l.features[2].q === 'nodata' && l.zStats.ok === 1 && l.zStats.zero === 1 && l.zStats.nodata === 1, 'Z = 0 et Z = -9999 signalés', JSON.stringify(l.zStats));
  ok(l.features[0].l === 'A1' && l.features[0].p.hauteur === 3.5, 'étiquette et attributs conservés');
  l = P.loadLayer(g.db, L.arbres_2d, { zField: 'z_terrain' });
  ok(l.features[0].z === 121.2 && l.features[1].z === null && l.features[1].q === 'absent' && l.features[2].z === 122.5, 'Z d’une colonne : valeur nulle → absente ; « 122,5 » (texte, virgule) lu', l.features.map((f) => f.z).join(' | '));
  ok(l.features[1].l === '2' && l.features[2].p.nom === 'tilleul', 'étiquette numérique lue, accents conservés');
  l = P.loadLayer(g.db, L.arbres_2d, { zField: null });
  ok(l.features.every((f) => f.z === null && f.q === 'absent'), 'sans colonne de Z : tout est « absent »');
  l = P.loadLayer(g.db, L.haies, { zField: '__geom' });
  ok(l.kind === 'line' && l.features[0].q === 'ok' && l.features[1].q === 'zero' && l.features[0].z === null, 'ligne Z : qualité de la pire altitude, Z par sommet conservé', JSON.stringify(l.zStats));
  l = P.loadLayer(g.db, L.haies, { zField: 'z_haie' });
  ok(l.features[0].z === 100.5 && l.features[0].g.c[0][2] === 100, 'colonne Z choisie : altitude de l’objet ; Z des sommets conservé aussi');
  l = P.loadLayer(g.db, L.mares, { zField: 'z_fond_ngf' });
  ok(l.kind === 'polygon' && l.features[0].z === 119.8 && l.features[0].g.type === 'MultiPolygon' && l.features[0].g.c[0][0][0][2] === null, 'multipolygone sans Z + altitude de fond d’une colonne');
  l = P.loadLayer(g.db, L.melange, { zField: null });
  ok(l.features.length === 2 && l.kind === 'point', 'couche mêlée : 2 points retenus', l.features.map((f) => f.l).join(', '));
  ok(l.skipped.empty === 2 && l.skipped.unsupported === 1 && l.skipped.otherKind === 1, 'ignorés et comptés : 2 vides, 1 courbe, 1 ligne', JSON.stringify(l.skipped));

  console.log('\n── Plan : emprise, statistiques, enregistrement ──');
  const plan = P.build('essai.gpkg', [
    P.loadLayer(g.db, L.arbres_z, { zField: '__geom' }), P.loadLayer(g.db, L.haies, { zField: '__geom' }), P.loadLayer(g.db, L.mares, { zField: 'z_fond_ngf' })]);
  const b = P.bounds(plan);
  ok(b.minX === 555700 && b.maxX === 555740 && b.minY === 6677600 && b.maxY === 6677640, 'emprise de tous les objets', JSON.stringify(b));
  plan.layers[2].on = false; P.invalidate(plan);
  ok(P.bounds(plan).maxX === 555720, 'emprise : seules les couches affichées comptent');
  ok(P.bounds(plan, true).maxX === 555740, 'emprise de toutes les couches sur demande');
  const st = P.stats(plan);
  ok(st.layers === 3 && st.features === 3 + 2 + 1 && st.byKind.point === 3 && st.byKind.line === 2 && st.byKind.polygon === 1, 'statistiques par type', JSON.stringify(st.byKind));
  const back = P.parse(P.serialize(plan));
  ok(back && back.layers.length === 3 && back.layers[0].features[0].z === 120.5 && back.epsg === 2154, 'plan relu après enregistrement');
  ok(!('__bvis' in JSON.parse(P.serialize(plan))), 'le cache d’emprise n’est pas enregistré');
  ok(P.parse('{pas du json') === null && P.parse('null') === null && P.parse('{"v":9}') === null, 'plan corrompu ou d’une autre version : refusé');
  ok(P.parse(JSON.stringify({ v: 1, layers: [{ kind: 'point', zStats: {}, features: [{ g: { type: 'Autre', c: [] } }] }] })) === null, 'géométrie inconnue dans un plan enregistré : refusé');

  console.log('\n── Fichiers qui ne sont pas des GeoPackage ──');
  let e1 = null; try { P.open(SQL, new Uint8Array(Buffer.from('ceci est du texte, pas SQLite'))); } catch (e) { e1 = e; }
  ok(e1 && /SQLite|illisible/.test(e1.message), 'fichier texte : message clair', e1 && e1.message);
  const plain = new SQL.Database(); plain.run('CREATE TABLE t (a)');
  let e2 = null; try { P.open(SQL, plain.export()); } catch (e) { e2 = e; }
  ok(e2 && /pas un GeoPackage/.test(e2.message), 'base SQLite quelconque : « pas un GeoPackage »', e2 && e2.message);

  /* ---------- votre vrai plan ---------- */
  const real = process.env.PIQ_GPKG || '/mnt/user-data/uploads/Plan_plantation_L_Gaudron_v5.gpkg';
  if (fs.existsSync(real)) {
    console.log('\n── Votre vrai plan : ' + path.basename(real) + ' ──');
    const rb = new Uint8Array(fs.readFileSync(real));
    const t0 = Date.now();
    const rg = P.open(SQL, rb);
    ok(rg.layers.length === 20, 'vingt couches d’objets', rg.layers.length + ' en ' + (Date.now() - t0) + ' ms');
    ok(rg.layers.every((x) => x.epsg === 2154 && !x.refused), 'toutes en EPSG:2154');
    ok(rg.layers.every((x) => x.geomZ === false), 'aucune géométrie ne porte de Z (comme annoncé)');
    const R = Object.fromEntries(rg.layers.map((x) => [x.table, x]));
    ok(R.plants_A_270.count === 270 && R.plants_B_300.count === 300, 'plants_A_270 : 270 ; plants_B_300 : 300');
    ok(R.plants_A_270.zCandidates.includes('z_terrain') && !R.plants_A_270.zCandidates.includes('h_ref_m'), 'z_terrain proposée ; h_ref_m (hauteur d’arbre) non', R.plants_A_270.zCandidates.join(', '));
    ok(['z_fond_ngf', 'z_eau_max_ngf', 'z_crete_ngf'].every((c) => R.baissieres_axes.zCandidates.includes(c)) && !R.baissieres_axes.zCandidates.includes('vidange_h'), 'baissières : fond, eau max et crête proposés ; la durée de vidange (vidange_h) ne l’est pas', R.baissieres_axes.zCandidates.join(', '));
    const pa = P.loadLayer(rg.db, R.plants_A_270, { zField: 'z_terrain' });
    ok(pa.features.length === 270 && pa.kind === 'point' && pa.zStats.ok === 270, '270 plants lus, tous avec un Z valide', JSON.stringify(pa.zStats));
    const zs = pa.features.map((f) => f.z);
    ok(near(Math.min.apply(null, zs), 119.45, 1e-9) && near(Math.max.apply(null, zs), 123.72, 1e-9), 'z_terrain de 119,45 à 123,72 m (comme dans le fichier)');
    const ref = rg.db.exec('SELECT rowid, x_l93, y_l93 FROM plants_A_270')[0].values;
    const byId = Object.fromEntries(pa.features.map((f) => [f.i, f]));
    let dmax = 0;
    ref.forEach(([id, x, y]) => { const f = byId[id]; dmax = Math.max(dmax, Math.abs(f.g.c[0] - x), Math.abs(f.g.c[1] - y)); });
    ok(dmax <= 0.0006, 'coordonnées décodées = colonnes x_l93 / y_l93 du fichier (au millimètre près)', dmax.toFixed(6) + ' m');
    const pb = P.loadLayer(rg.db, R.plants_B_300, { zField: 'z_terrain' });
    ok(pb.features.length === 300 && pb.zStats.ok === 300, '300 plants de la variante B lus');
    const bx = P.loadLayer(rg.db, R.baissieres_axes, { zField: 'z_fond_ngf' });
    ok(bx.kind === 'line' && bx.features.length === 2 && bx.features.every((f) => f.z > 100 && f.z < 200), 'axes de baissière : 2 lignes avec leur altitude de fond', bx.features.map((f) => f.z).join(' ; '));
    const mare = P.loadLayer(rg.db, R.mare_tampon_variante_A, { zField: null });
    ok(mare.kind === 'polygon' && mare.features.length === 1, 'mare : 1 polygone');
    let total = 0, skipped = 0;
    const all = rg.layers.map((x) => { const r = P.loadLayer(rg.db, x, { zField: x.zCandidates[0] || null }); total += r.features.length; skipped += r.skipped.empty + r.skipped.unsupported + r.skipped.otherKind; return r; });
    ok(total > 570 && skipped === 0, 'les 20 couches se chargent : ' + total + ' objets, aucun ignoré', 'ignorés : ' + skipped);
    const rp = P.build(path.basename(real), all);
    const ser = P.serialize(rp);
    ok(ser.length < 3.5e6, 'plan complet enregistrable en local (< 3,5 Mo)', (ser.length / 1048576).toFixed(2) + ' Mo');
    const sel = P.build('plants', [pa, pb, bx, mare]);
    ok(P.serialize(sel).length < 1.5e6, 'sélection typique (plants, baissières, mare) : taille raisonnable', (P.serialize(sel).length / 1024).toFixed(0) + ' Ko');
    const rb2 = P.bounds(sel);
    ok(rb2.minX > 5.0e5 && rb2.maxX < 6.0e5 && rb2.minY > 6.6e6 && rb2.maxY < 6.7e6 && rb2.maxX - rb2.minX < 500 && rb2.maxY - rb2.minY < 500, 'emprise en Lambert-93 cohérente : un site d’une centaine de mètres', JSON.stringify(rb2));
  } else {
    console.log('\n(votre plan n’est pas présent : tests sur le vrai fichier ignorés)');
  }

  console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
