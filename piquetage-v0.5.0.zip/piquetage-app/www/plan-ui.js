/* ==================================================================
   Piquetage — interface d'import du plan GeoPackage

   Choisir un .gpkg → lister ses couches → pour chacune : cocher, choisir la
   source de l'altitude Z (géométrie ou colonne) et l'étiquette → importer.
   SQLite (sql.js, WebAssembly) n'est chargé qu'à la demande.
   Aucun innerHTML : tout passe par textContent.
   ================================================================== */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var A = window.PIQUETAGE.api, P = window.PiqPlan;
  var PALETTE = ['#a1887f', '#6c8cf0', '#43a047', '#ef8a3a', '#b05cc9', '#26a0b5', '#d6456f', '#8a949c'];
  var KIND_FR = { point: 'point', line: 'ligne', polygon: 'polygone' };

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }
  function plural(n, one, many) { return n + ' ' + (n > 1 ? many : one); }

  /* ---------------- SQLite à la demande ---------------- */

  var sqlPromise = null;
  function getSql() {
    if (sqlPromise) return sqlPromise;
    sqlPromise = new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = 'vendor/sqljs/sql-wasm.js';
      s.onload = function () {
        window.initSqlJs({ locateFile: function (f) { return 'vendor/sqljs/' + f; } }).then(resolve, function (e) {
          sqlPromise = null; reject(new Error('Impossible de démarrer SQLite : ' + (e && e.message ? e.message : e)));
        });
      };
      s.onerror = function () { sqlPromise = null; reject(new Error('Bibliothèque SQLite introuvable dans l’application')); };
      document.head.appendChild(s);
    });
    return sqlPromise;
  }

  /* ---------------- Section « Plan » du panneau Projet ---------------- */

  function zSummary(z) {
    var parts = [];
    if (z.ok) parts.push(z.ok + ' valide' + (z.ok > 1 ? 's' : ''));
    if (z.zero) parts.push(z.zero + ' à 0');
    if (z.nodata) parts.push(z.nodata + ' à -9999');
    if (z.absent) parts.push(z.absent + ' absent' + (z.absent > 1 ? 's' : ''));
    return parts.join(' · ') || 'aucun objet';
  }

  function paintPlan() {
    var plan = A.getPlan();
    var st = $('plan-status'), box = $('plan-layers');
    box.textContent = '';
    $('plan-remove').disabled = !plan;
    $('plan-show').checked = A.getView().showPlan;
    $('plan-show').disabled = !plan;
    if (!plan) { st.textContent = 'Aucun plan importé.'; return; }
    var s = P.stats(plan);
    st.textContent = plan.name + ' — ' + plural(s.layers, 'couche', 'couches') + ', ' + plural(s.features, 'objet', 'objets') +
      ' · Z : ' + zSummary(s.z);
    plan.layers.forEach(function (l, i) {
      var row = el('div', 'lay' + (l.on ? '' : ' off'));
      var h = el('div', 'lay-h');
      var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = l.on; cb.setAttribute('aria-label', 'Afficher ' + l.title);
      cb.addEventListener('change', function () { l.on = cb.checked; P.invalidate(plan); A.savePlan(); A.redraw(); row.className = 'lay' + (l.on ? '' : ' off'); });
      var dot = el('span', 'dot'); dot.style.background = PALETTE[i % PALETTE.length];
      var t = el('div');
      t.appendChild(el('div', 'lay-t', l.title));
      t.appendChild(el('div', 'lay-s', plural(l.features.length, KIND_FR[l.kind], KIND_FR[l.kind] + 's') +
        ' · Z : ' + (l.zField === '__geom' ? 'géométrie' : (l.zField || 'aucun')) + ' (' + zSummary(l.zStats) + ')'));
      h.appendChild(cb); h.appendChild(dot); h.appendChild(t);
      row.appendChild(h);
      box.appendChild(row);
    });
  }

  $('plan-show').addEventListener('change', function () { A.setView({ showPlan: $('plan-show').checked }); });
  A.armed($('plan-remove'), 'Retirer le plan', 'Confirmer : retirer le plan', function () { A.setPlan(null); paintPlan(); A.say('Plan retiré'); });

  /* ---------------- Import ---------------- */

  var cur = null;       // { db, name, layers, sel }

  function closeDb() { if (cur && cur.db) { try { cur.db.close(); } catch (e) {} } cur = null; }

  $('plan-pick').addEventListener('click', function () { $('plan-file').click(); });

  $('plan-file').addEventListener('change', function () {
    var f = this.files && this.files[0];
    this.value = '';
    if (!f) return;
    A.say('Lecture de ' + f.name + '…');
    Promise.all([getSql(), f.arrayBuffer()]).then(function (r) {
      closeDb();
      var info = P.open(r[0], new Uint8Array(r[1]));
      cur = { db: info.db, name: f.name, layers: info.layers, sel: {} };
      info.layers.forEach(function (l) {
        cur.sel[l.table] = {
          on: false,
          zField: l.geomZ ? '__geom' : (l.zCandidates[0] || ''),
          labelField: l.labelDefault || ''
        };
      });
      renderImport();
      A.openSheet('sheet-import');
    }).catch(function (e) { A.say(e && e.message ? e.message : 'Fichier illisible'); });
  });

  function option(v, text, selected) { var o = document.createElement('option'); o.value = v; o.textContent = text; if (selected) o.selected = true; return o; }

  function renderImport() {
    var box = $('imp-layers'), W = $('imp-warn');
    box.textContent = '';
    var usable = cur.layers.filter(function (l) { return !l.refused; }).length;
    $('imp-file').textContent = cur.name + ' — ' + plural(cur.layers.length, 'couche', 'couches') + ' d’objets, ' + usable + ' importable' + (usable > 1 ? 's' : '') + '.';
    cur.layers.forEach(function (l, i) {
      var sel = cur.sel[l.table];
      var row = el('div', 'lay' + (l.refused ? ' off' : ''));
      var h = el('div', 'lay-h');
      var cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = sel.on && !l.refused; cb.disabled = !!l.refused;
      cb.setAttribute('aria-label', 'Importer ' + l.title);
      cb.addEventListener('change', function () { sel.on = cb.checked; updateWarn(); });
      var dot = el('span', 'dot'); dot.style.background = PALETTE[i % PALETTE.length];
      var t = el('div');
      t.appendChild(el('div', 'lay-t', l.title));
      var kind = l.geomType.indexOf('POINT') >= 0 ? 'point' : (l.geomType.indexOf('LINE') >= 0 ? 'ligne' : (l.geomType.indexOf('POLYGON') >= 0 ? 'polygone' : 'géométrie'));
      t.appendChild(el('div', 'lay-s', plural(l.count, kind, kind === 'géométrie' ? 'géométries' : kind + 's') + ' · ' + (l.epsg ? 'EPSG:' + l.epsg : 'projection inconnue') +
        (l.geomZ ? ' · Z dans la géométrie' : '')));
      h.appendChild(cb); h.appendChild(dot); h.appendChild(t);
      row.appendChild(h);
      if (l.refused) { row.appendChild(el('div', 'lay-r', l.refused)); box.appendChild(row); return; }

      var f = el('div', 'lay-f');
      var zWrap = el('div'); zWrap.appendChild(el('label', '', 'Altitude Z'));
      var zs = document.createElement('select');
      zs.setAttribute('aria-label', 'Altitude Z de ' + l.title);
      if (l.geomZ) zs.appendChild(option('__geom', 'Z de la géométrie', sel.zField === '__geom'));
      zs.appendChild(option('', 'Aucune altitude', sel.zField === ''));
      var seen = {};
      l.zCandidates.forEach(function (c) { seen[c] = 1; zs.appendChild(option(c, c, sel.zField === c)); });
      l.columns.forEach(function (c) { if (!seen[c.name] && !c.pk) zs.appendChild(option(c.name, c.name + ' (autre colonne)', sel.zField === c.name)); });
      zs.addEventListener('change', function () { sel.zField = zs.value; updateWarn(); });
      zWrap.appendChild(zs);
      var lWrap = el('div'); lWrap.appendChild(el('label', '', 'Étiquette'));
      var ls = document.createElement('select');
      ls.setAttribute('aria-label', 'Étiquette de ' + l.title);
      ls.appendChild(option('', 'Numéro de l’objet', sel.labelField === ''));
      l.columns.forEach(function (c) { if (!c.pk) ls.appendChild(option(c.name, c.name, sel.labelField === c.name)); });
      ls.addEventListener('change', function () { sel.labelField = ls.value; });
      lWrap.appendChild(ls);
      f.appendChild(zWrap); f.appendChild(lWrap);
      row.appendChild(f);
      if (!l.geomZ && l.zCandidates.length === 0) row.appendChild(el('div', 'lay-s', 'Aucune colonne d’altitude reconnue : on peut en choisir une dans la liste, ou importer sans Z.'));
      box.appendChild(row);
    });
    updateWarn();
  }

  function updateWarn() {
    var W = $('imp-warn'), msgs = [];
    var picked = cur.layers.filter(function (l) { return cur.sel[l.table].on && !l.refused; });
    var noZ = picked.filter(function (l) { return cur.sel[l.table].zField === ''; });
    if (noZ.length) msgs.push('Sans altitude : ' + noZ.map(function (l) { return l.title; }).join(', ') + '.');
    var attr2 = picked.filter(function (l) { return cur.sel[l.table].zField && cur.sel[l.table].zField !== '__geom' && /LINE|POLYGON/.test(l.geomType); });
    if (attr2.length) msgs.push('Une colonne d’altitude donne une seule valeur par ligne ou polygone, pas une altitude par sommet : ' + attr2.map(function (l) { return l.title; }).join(', ') + '.');
    msgs.push('Z égal à 0 ou à -9999 : valeurs « par défaut » de QGIS, signalées après l’import.');
    W.textContent = msgs.join(' ');
    W.hidden = false;
    $('imp-go').disabled = !picked.length;
    $('imp-go').textContent = picked.length ? 'Importer ' + plural(picked.length, 'couche', 'couches') : 'Cocher au moins une couche';
  }

  $('imp-all').addEventListener('click', function () { cur.layers.forEach(function (l) { if (!l.refused) cur.sel[l.table].on = true; }); renderImport(); });
  $('imp-none').addEventListener('click', function () { cur.layers.forEach(function (l) { cur.sel[l.table].on = false; }); renderImport(); });
  $('close-import').addEventListener('click', function () { A.closeSheet(); closeDb(); });

  $('imp-go').addEventListener('click', function () {
    if (!cur) return;
    var out = [], problems = [];
    cur.layers.forEach(function (l) {
      var s = cur.sel[l.table];
      if (!s.on || l.refused) return;
      try { out.push(P.loadLayer(cur.db, l, { zField: s.zField === '' ? null : s.zField, labelField: s.labelField === '' ? null : s.labelField })); }
      catch (e) { problems.push(l.title + ' : ' + e.message); }
    });
    if (!out.length) { A.say(problems[0] || 'Aucune couche importée'); return; }
    var plan = P.build(cur.name, out);
    var st = P.stats(plan);
    A.setPlan(plan);
    closeDb();
    A.closeSheet();
    paintPlan();
    var bad = st.z.zero + st.z.nodata;
    A.say('Plan importé : ' + plural(st.features, 'objet', 'objets') + (bad ? ' · ' + bad + ' Z suspect' + (bad > 1 ? 's' : '') + ' (0 ou -9999)' : '') + (problems.length ? ' · ' + problems.length + ' couche(s) en erreur' : ''));
  });

  paintPlan();
  window.PIQUETAGE.paintPlan = paintPlan;
})();
