/* ==================================================================
   Piquetage — écran principal (disposition C)

   Bandeau (projet, lieu, date, heure) · pastille de qualité · un instrument
   en gros chiffres (altitude NGF, points levés, cap de marche) · tracé en
   direct sur le plan Lambert-93 · profil altimétrique qui se dessine au fil
   de la marche · barre d'actions.

   S'appuie sur : window.PIQUETAGE.rtk (rtk-core.js, créé par diag.js),
   session.js (données), views.js (dessin). Aucun innerHTML.
   ================================================================== */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var rtk = window.PIQUETAGE.rtk;
  var GEO = window.GEO, Sess = window.PiqSession, V = window.PiqViews, X = window.PiqExport;

  var storage = null;
  try { storage = window.localStorage; } catch (e) { /* stockage indisponible */ }

  /* ---------------- Session ---------------- */

  var session = Sess.create(storage ? Sess.parse(storage.getItem(Sess.KEY)) : null);
  var saveTimer = null, saveWarned = false;

  function save() {
    if (!storage) return;
    try { storage.setItem(Sess.KEY, session.serialize()); saveWarned = false; }
    catch (e) { if (!saveWarned) { saveWarned = true; say('Sauvegarde impossible (stockage plein) — effacer des tracés'); } }
  }
  function scheduleSave() { if (saveTimer) return; saveTimer = setTimeout(function () { saveTimer = null; save(); }, 1000); }

  /* ---------------- Plan importé et cadrage ---------------- */

  var PP = window.PiqPlan;
  var plan = null;
  try { var pt = storage && storage.getItem(PP.KEY); plan = pt ? PP.parse(pt) : null; } catch (e) { plan = null; }
  var SPANS = V.SPANS;                     // crans « ici » : 60, 20, 15, 10, 5 m
  var viewState = { showPlan: true, mode: 'all', span: 60, showDone: false };
  try {
    var vs = storage && JSON.parse(storage.getItem('piquetage.view') || 'null');
    if (vs) {
      viewState.showPlan = vs.showPlan !== false; viewState.mode = vs.mode === 'here' ? 'here' : 'all';
      viewState.span = SPANS.indexOf(vs.span) >= 0 ? vs.span : 60; viewState.showDone = vs.showDone === true;
    }
  } catch (e) { /* réglages d'affichage par défaut */ }
  function saveView() { try { if (storage) storage.setItem('piquetage.view', JSON.stringify(viewState)); } catch (e) {} }

  // Centre du cadrage « ici » (non enregistré). Il ne suit PAS la position à chaque trame : il n'est
  // déplacé (recentré sur la position) que lorsque celle-ci sort de la zone centrale du cadre
  // (DEADBAND × largeur du cadre de part et d'autre du centre). Une trame manquante ou en retard
  // ne le change pas : le plan ne saute plus vers le centre du chantier à chaque coupure de liaison.
  var DEADBAND = 0.3;
  var viewCenter = null, lastLive = null;
  function updateCenter(live) {
    if (live) lastLive = { x: live.x, y: live.y };
    if (viewState.mode !== 'here') return null;
    var lim = viewState.span * DEADBAND;
    if (live && (!viewCenter || Math.abs(live.x - viewCenter.x) > lim || Math.abs(live.y - viewCenter.y) > lim)) {
      viewCenter = { x: live.x, y: live.y };
    }
    if (!viewCenter) {
      var tr = session.lastTrack(), lv = tr && tr.v.length ? tr.v[tr.v.length - 1] : null;
      var pb = plan && viewState.showPlan ? PP.bounds(plan) : null;
      viewCenter = lastLive ? { x: lastLive.x, y: lastLive.y } : (lv ? { x: lv.x, y: lv.y } : (pb ? { x: (pb.minX + pb.maxX) / 2, y: (pb.minY + pb.maxY) / 2 } : null));
    }
    return viewCenter;
  }

  /* ---------------- Messages ---------------- */

  var msgTimer = null;
  function say(text) {
    var el = $('m-msg');
    el.textContent = text; el.hidden = false;
    clearTimeout(msgTimer);
    msgTimer = setTimeout(function () { el.hidden = true; }, 4500);
  }
  rtk.on('message', say);

  /* ---------------- Formats ---------------- */

  function num(v, d) {
    return v.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d }).replace(/[\u202f\u00a0]/g, ' ');
  }

  /* ---------------- Position en direct ---------------- */

  var recent = [];            // positions récentes éligibles, pour le cap de marche
  var RECENT_MS = 20000, HEADING_MIN_M = 3;

  function eligible(ep) { return !rtk.settings.requireFix || ep.gga.quality === 4; }

  rtk.on('epoch', function (ep) {
    var S = rtk.settings;
    var sp = GEO.surveyPoint([{ gga: ep.gga, gst: null }], { poleHeight: S.pole, apcOffset: S.apc });
    if (!sp || !eligible(ep)) return;
    sp.t = new Date(ep.at).toISOString();
    recent.push({ x: sp.x93, y: sp.y93, at: ep.at });
    while (recent.length && ep.at - recent[0].at > RECENT_MS) recent.shift();
    if (session.isTracking() && session.addEpoch(sp) === 'added') scheduleSave();
  });

  /* ---------------- Onglets ---------------- */

  var tab = 'alt';
  Array.prototype.forEach.call(document.querySelectorAll('#tabs button'), function (b) {
    b.addEventListener('click', function () {
      tab = b.getAttribute('data-tab');
      Array.prototype.forEach.call(document.querySelectorAll('#tabs button'), function (x) {
        x.setAttribute('aria-selected', x === b ? 'true' : 'false');
      });
      paint();
    });
  });

  /* ---------------- Affichage ---------------- */

  function paintBanner() {
    var D = session.data, now = new Date();
    var pj = $('m-project'), pl = $('m-place');
    pj.textContent = D.project || 'Projet sans nom'; pj.className = D.project ? '' : 'ph muted';
    pl.textContent = D.place || 'Lieu à renseigner'; pl.className = D.place ? '' : 'ph';
    $('m-time').textContent = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    $('m-date').textContent = now.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  }

  function paintInstrument(st) {
    var label = $('big-label'), value = $('big-value'), sub = $('big-sub');
    var p = st.point;
    if (tab === 'alt') {
      var ground = p && p.hNgfGround !== null;
      var h = p ? (ground ? p.hNgfGround : p.hNgfAntenna) : null;
      var warn = false;
      if (!p) label.textContent = 'Altitude NGF-IGN69';
      else if (ground && p.apcMissing) { label.textContent = 'Altitude NGF-IGN69 · sol, centre de phase non corrigé'; warn = true; }
      else if (ground) label.textContent = 'Altitude NGF-IGN69 · sol';
      else { label.textContent = 'Altitude NGF-IGN69 · ANTENNE (hauteur de canne non saisie)'; warn = true; }
      value.textContent = h !== null && h !== undefined ? num(h, 2) + ' m' : '—';
      if (!p) sub.textContent = '';
      else if (h === null) sub.textContent = 'Séparation géoïdale absente de la GGA ou position hors grille RAF20';
      else if (!ground) sub.textContent = 'Altitude de l’antenne, donc trop haute de la hauteur de canne : la saisir dans Canne › Réglages';
      else if (p.apcMissing) sub.textContent = 'h − N (RAF20) − hauteur de canne. Décalage du centre de phase non saisi : à renseigner dans Canne (0 pour l’ignorer)';
      else sub.textContent = 'h − N (RAF20) − hauteur de canne − centre de phase';
      label.className = warn ? 'warn' : '';
      sub.className = warn ? 'warn' : '';
    } else if (tab === 'pts') {
      var pts = session.data.points, lastP = pts[pts.length - 1];
      label.className = ''; sub.className = '';
      label.textContent = 'Points levés';
      value.textContent = String(pts.length);
      sub.textContent = lastP ? 'P' + lastP.n + ' · X ' + num(lastP.x, 2) + ' · Y ' + num(lastP.y, 2) : 'Aucun point levé';
    } else {
      var now = Date.now();
      var hd = st.fresh ? Sess.heading(recent.filter(function (r) { return now - r.at <= RECENT_MS; }), HEADING_MIN_M) : null;
      label.className = ''; sub.className = '';
      label.textContent = 'Cap de marche · nord du plan Lambert-93';
      value.textContent = hd === null ? '—' : String(Math.round(hd) % 360).padStart(3, '0') + '° ' + Sess.cardinal(hd);
      sub.textContent = hd === null ? 'À l’arrêt, ou moins de ' + HEADING_MIN_M + ' m parcourus'
        : 'Calculé sur la marche récente (≥ ' + HEADING_MIN_M + ' m) · pas le nord géographique';
    }
  }

  function paintInfo() {
    var s = session.stats();
    var tr = s.tracking ? 'Tracé en cours' : (s.vertices ? 'Dernier tracé' : 'Tracé');
    $('tr-info').textContent = tr + (s.vertices ? ' · ' + num(s.length, s.length < 100 ? 1 : 0) + ' m · ' + s.vertices + ' sommet' + (s.vertices > 1 ? 's' : '') : '') +
      (s.points ? ' · ' + s.points + ' pt' + (s.points > 1 ? 's' : '') : '');
    var pr = session.profile();
    $('pr-info').textContent = s.vertices > 1 && pr.some(function (q) { return q.h !== null; })
      ? 'Profil · D+ ' + num(s.up, 1) + ' m · D− ' + num(s.down, 1) + ' m' : 'Profil';
  }

  function liveOf(st) {
    return st.point && st.fresh ? { x: st.point.x93, y: st.point.y93, fix: st.code === 'FIX' } : null;
  }

  var raf = 0, lastT = null;
  function redraw() {
    if (raf) return;
    raf = requestAnimationFrame(function () {
      raf = 0;
      var st = rtk.status(), live = liveOf(st);
      var ctr = updateCenter(live);
      lastT = V.drawTrack($('cv-track'), session, live, {
        plan: plan, showPlan: viewState.showPlan, mode: viewState.mode, span: viewState.span,
        center: ctr, keep: lastLive, showDone: viewState.showDone, sel: sel
      });
      V.drawProfile($('cv-prof'), session);
      paintSel(st);
    });
  }

  function paint() {
    var st = rtk.status();
    var pill = $('m-pill');
    pill.className = 'q-' + st.code;
    pill.textContent = st.label;

    var acc = [];
    if (st.fresh) {
      acc.push(st.gstAvailable ? '±' + rtk.cm(st.sdH) + ' H · ±' + rtk.cm(st.sdV) + ' V' : 'σ n.d.');
      if (st.sats !== null) acc.push(st.sats + ' sat.');
    }
    $('m-acc').textContent = acc.join(' · ');

    paintInstrument(st);
    $('m-xy').textContent = st.point ? 'X ' + num(st.point.x93, 2) + '   Y ' + num(st.point.y93, 2) : 'X —   Y —';

    var tracking = session.isTracking();
    var bt = $('b-track');
    bt.setAttribute('aria-pressed', tracking ? 'true' : 'false');
    bt.textContent = tracking ? 'Arrêter' : 'Tracé';
    $('b-point').disabled = !st.connected || capturing;

    paintBanner();
    paintInfo();
    redraw();
  }
  rtk.on('change', paint);

  /* ---------------- Actions ---------------- */

  var capturing = false;
  $('b-point').addEventListener('click', function () {
    if (capturing) return;
    capturing = true; paint();
    rtk.capture().then(function (p) {
      var pt = session.addPoint(p);
      if (pt) { save(); say('P' + pt.n + ' enregistré · ' + p.qualityLabel + (p.acc !== null ? ' · ±' + rtk.cm(p.acc) : '')); }
    }).catch(function (e) {
      say(e.message);
    }).then(function () { capturing = false; paint(); });
  });

  $('b-track').addEventListener('click', function () {
    if (session.isTracking()) { session.stopTrack(); save(); say('Tracé arrêté'); }
    else {
      session.startTrack(); save();
      var st = rtk.status();
      say(st.fresh ? 'Tracé démarré' : 'Tracé démarré — en attente de position');
    }
    paint();
  });

  // Cadrage : tout · ici 60 m · 20 m · 15 m · 10 m · 5 m.  « + » rapproche (jusqu’à 5 m), « − » éloigne ; le bouton du
  // milieu bascule entre « tout » et le dernier cadrage « ici ». Chaque changement recentre sur la position.
  function paintFit() {
    var here = viewState.mode === 'here';
    $('b-fit').textContent = here ? 'Ici ' + viewState.span + ' m' : 'Vue : tout';
    $('b-zin').disabled = here && viewState.span === SPANS[SPANS.length - 1];
    $('b-zout').disabled = !here;
  }
  function setFit(mode, span) {
    viewState.mode = mode; if (span) viewState.span = span;
    viewCenter = null;                        // recentrage sur la position (ou le dernier point connu)
    saveView(); paintFit(); redraw();
  }
  $('b-zin').addEventListener('click', function () {
    if (viewState.mode !== 'here') setFit('here', SPANS[0]);
    else { var i = SPANS.indexOf(viewState.span); if (i < SPANS.length - 1) setFit('here', SPANS[i + 1]); }
  });
  $('b-zout').addEventListener('click', function () {
    if (viewState.mode !== 'here') return;
    var i = SPANS.indexOf(viewState.span);
    if (i <= 0) setFit('all'); else setFit('here', SPANS[i - 1]);
  });
  $('b-fit').addEventListener('click', function () { setFit(viewState.mode === 'here' ? 'all' : 'here'); });

  /* ---------------- Point du plan sélectionné : « implanté » ---------------- */

  var sel = null;              // { li, fi, k } : point du plan touché
  var selUndo = null;          // dernier marquage, annulable depuis la carte pendant quelques secondes
  var selTimer = null;

  function selFeature(s) {
    var l = plan && s && plan.layers[s.li], f = l && l.features[s.fi];
    if (!f) return null;
    var c = f.g.type === 'Point' ? f.g.c : (f.g.type === 'MultiPoint' ? f.g.c[s.k] : null);
    return c ? { layer: l, f: f, c: c } : null;
  }
  function stakeCount() { var d = PP.doneStats(plan); return d.done + ' / ' + d.total; }

  function paintSel(st) {
    var card = $('selcard');
    if (selUndo) return;                     // la carte affiche l'annulation possible
    var it = sel && selFeature(sel);
    if (!it) { sel = null; card.hidden = true; return; }
    var done = V.doneOf(it.f, sel.k);
    $('sel-l').textContent = it.f.l;
    var live = liveOf(st || rtk.status()), parts = [it.layer.title];
    if (live) {
      var d = Math.sqrt(Math.pow(it.c[0] - live.x, 2) + Math.pow(it.c[1] - live.y, 2));
      parts.push('à ' + num(d, d < 10 ? 2 : 1) + ' m');
    }
    if (done) parts.push('implanté le ' + new Date(done.t).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }));
    $('sel-s').textContent = parts.join(' · ');
    $('sel-act').textContent = done ? 'Rétablir' : 'Implanté ✓';
    $('sel-act').className = done ? '' : 'primary';
    card.hidden = false;
  }

  $('cv-track').addEventListener('click', function (e) {
    if (!plan || !viewState.showPlan || !lastT) return;
    var r = this.getBoundingClientRect();
    var hit = V.hitPlan(plan, lastT, e.clientX - r.left, e.clientY - r.top, { showDone: viewState.showDone, tol: 26 });
    clearTimeout(selTimer); selUndo = null;
    sel = hit ? { li: hit.li, fi: hit.fi, k: hit.k } : null;
    redraw();
  });
  $('sel-x').addEventListener('click', function () { clearTimeout(selTimer); selUndo = null; sel = null; redraw(); });

  function markDone(s) {
    var st = rtk.status(), p = st.point && st.fresh ? st.point : null;
    var rec = {
      t: new Date().toISOString(),
      x: p ? Math.round(p.x93 * 1000) / 1000 : null, y: p ? Math.round(p.y93 * 1000) / 1000 : null,
      h: p && p.hNgfGround !== null && p.hNgfGround !== undefined ? Math.round(p.hNgfGround * 1000) / 1000 : null,
      q: p ? st.code : null
    };
    PP.setDone(plan, s.li, s.fi, s.k, rec);
    window.PIQUETAGE.api.savePlan();
    return rec;
  }

  $('sel-act').addEventListener('click', function () {
    if (selUndo) {                                          // « Annuler » juste après un marquage
      PP.setDone(plan, selUndo.li, selUndo.fi, selUndo.k, null);
      window.PIQUETAGE.api.savePlan();
      sel = { li: selUndo.li, fi: selUndo.fi, k: selUndo.k }; selUndo = null; clearTimeout(selTimer);
      say('Marquage annulé · ' + stakeCount() + ' implantés');
      if (window.PIQUETAGE.paintPlan) window.PIQUETAGE.paintPlan();
      redraw(); return;
    }
    var it = sel && selFeature(sel);
    if (!it) return;
    if (V.doneOf(it.f, sel.k)) {                            // point implanté affiché grisé : le rétablir
      PP.setDone(plan, sel.li, sel.fi, sel.k, null);
      window.PIQUETAGE.api.savePlan();
      say(it.f.l + ' rétabli (à implanter) · ' + stakeCount() + ' implantés');
    } else {
      var rec = markDone(sel);
      selUndo = sel; sel = null;
      $('sel-l').textContent = it.f.l + ' implanté ✓';
      $('sel-s').textContent = stakeCount() + ' implantés' + (rec.x === null ? ' · sans position de canne (aucune trame fraîche)' : '');
      $('sel-act').textContent = 'Annuler'; $('sel-act').className = '';
      $('selcard').hidden = false;
      clearTimeout(selTimer);
      selTimer = setTimeout(function () { selUndo = null; redraw(); }, 6000);
    }
    if (window.PIQUETAGE.paintPlan) window.PIQUETAGE.paintPlan();
    redraw();
  });

  /* ---------------- Panneaux ---------------- */

  var stack = [];
  function openSheet(id) {
    if (stack.indexOf(id) >= 0) return;
    $(id).hidden = false; stack.push(id);
    try { history.pushState({ sheet: id }, ''); } catch (e) { /* historique indisponible */ }
    $(id).scrollTop = 0;
  }
  function hideSheet() {
    var id = stack.pop();
    if (!id) return;
    $(id).hidden = true;
    paint();
  }
  function closeSheet() {
    if (!stack.length) return;
    if (history.state && history.state.sheet) history.back(); else hideSheet();
  }
  window.addEventListener('popstate', hideSheet);

  $('b-link').addEventListener('click', function () { openSheet('sheet-link'); });
  $('close-link').addEventListener('click', closeSheet);
  $('close-proj').addEventListener('click', closeSheet);

  function openProject() {
    var D = session.data;
    $('p-name').value = D.project; $('p-place').value = D.place;
    $('p-interval').value = String(D.interval); $('p-display').value = D.display; $('p-decimal').value = D.decimal; $('p-origin').value = D.origin;
    $('p-export-out').textContent = '';
    paintProjectStats();
    openSheet('sheet-proj');
  }
  $('b-proj').addEventListener('click', openProject);
  $('banner').addEventListener('click', openProject);
  $('banner').addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openProject(); } });

  function paintProjectStats() {
    var s = session.stats();
    $('p-stats').textContent = s.vertices || s.points
      ? s.points + ' point' + (s.points > 1 ? 's' : '') + ' levé' + (s.points > 1 ? 's' : '') + ' · ' + s.tracks + ' tracé' + (s.tracks > 1 ? 's' : '') +
        (s.vertices ? ' · dernier tracé ' + num(s.length, 1) + ' m sur le plan Lambert-93 (distance de grille, pas de terrain)' : '')
      : 'Aucune donnée dans cette session.';
  }

  $('p-name').addEventListener('input', function () { session.setMeta({ project: $('p-name').value }); save(); paintBanner(); });
  $('p-place').addEventListener('input', function () { session.setMeta({ place: $('p-place').value }); save(); paintBanner(); });
  $('p-interval').addEventListener('change', function () { session.setMeta({ interval: $('p-interval').value }); save(); });
  $('p-origin').addEventListener('change', function () { session.setMeta({ origin: $('p-origin').value }); save(); });
  $('p-decimal').addEventListener('change', function () { session.setMeta({ decimal: $('p-decimal').value }); save(); });
  $('p-display').addEventListener('change', function () { session.setMeta({ display: $('p-display').value }); save(); redraw(); });

  /* ---------------- Export CSV + DXF ---------------- */

  var CAP = window.Capacitor || null;
  function plug(name) {
    if (!CAP || !CAP.Plugins) return null;
    if (typeof CAP.isPluginAvailable === 'function' && !CAP.isPluginAvailable(name)) return null;
    return CAP.Plugins[name] || null;
  }

  function showExport(text) { $('p-export-out').textContent = text; }

  function browserDownload(files) {
    files.forEach(function (f, i) {
      setTimeout(function () {
        var blob = new Blob([f.content], { type: f.mime + ';charset=utf-8' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = f.name;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      }, i * 400);
    });
  }

  function exportSession() {
    var btn = $('p-export');
    var res = X.build(session.data, { decimal: session.data.decimal, origin: session.data.origin, now: new Date(), plan: plan });
    if (res.error) { showExport(res.error); say(res.error); return; }
    var names = res.files.map(function (f) { return f.name; });
    var warn = res.warnings.length ? '\nÀ vérifier :\n· ' + res.warnings.join('\n· ') : '';
    var F = plug('Filesystem'), S = plug('Share');

    if (!F) {                                    // navigateur : téléchargement direct
      browserDownload(res.files);
      showExport(res.files.length + ' fichiers téléchargés :\n' + names.join('\n') + warn);
      say('Export : ' + res.files.length + ' fichiers');
      return;
    }

    btn.disabled = true;
    var uris = [];
    // Un nom horodaté à la minute : jamais d'écrasement d'un fichier d'une session précédente (Android 11+).
    res.files.reduce(function (chain, f) {
      return chain.then(function () {
        return F.writeFile({ path: 'Piquetage/' + f.name, data: f.content, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true });
      }).then(function () {
        return F.getUri({ path: 'Piquetage/' + f.name, directory: 'DOCUMENTS' });
      }).then(function (r) { if (r && r.uri) uris.push(r.uri); });
    }, Promise.resolve()).then(function () {
      showExport(res.files.length + ' fichiers enregistrés dans Documents › Piquetage :\n' + names.join('\n') + warn);
      say('Export enregistré dans Documents › Piquetage');
      if (S && uris.length) {
        return S.share({ title: 'Piquetage — ' + (session.data.project || 'export'), files: uris, dialogTitle: 'Partager l’export' })
          .catch(function () { /* partage annulé : les fichiers sont écrits */ });
      }
    }).catch(function (e) {
      var m = 'Export impossible : ' + ((e && e.message) || 'erreur');
      showExport(m); say(m);
    }).then(function () { btn.disabled = false; });
  }
  $('p-export').addEventListener('click', exportSession);

  // Effacement en deux temps : un premier appui arme le bouton, le second confirme.
  function armed(btn, label, armedLabel, action) {
    var timer = null;
    btn.addEventListener('click', function () {
      if (btn.getAttribute('data-armed') === '1') {
        clearTimeout(timer); btn.removeAttribute('data-armed'); btn.className = ''; btn.textContent = label;
        action();
      } else {
        btn.setAttribute('data-armed', '1'); btn.className = 'danger'; btn.textContent = armedLabel;
        timer = setTimeout(function () { btn.removeAttribute('data-armed'); btn.className = ''; btn.textContent = label; }, 4000);
      }
    });
  }
  armed($('p-undo'), 'Annuler le dernier point', 'Confirmer : retirer le dernier point', function () {
    var p = session.removeLastPoint();
    save(); paintProjectStats(); paint();
    say(p ? 'P' + p.n + ' retiré' : 'Aucun point à retirer');
  });
  armed($('p-clear'), 'Effacer les tracés', 'Confirmer : effacer les tracés', function () {
    session.clearTracks(); save(); paintProjectStats(); paint(); say('Tracés effacés');
  });
  armed($('p-new'), 'Nouveau projet (efface tracés et points)', 'Confirmer : tout effacer', function () {
    session.reset({}); recent = []; save(); openProject(); paint(); say('Nouveau projet');
  });

  /* ---------------- Démarrage ---------------- */

  if (typeof ResizeObserver === 'function') {
    var ro = new ResizeObserver(redraw);
    ro.observe($('cv-track')); ro.observe($('cv-prof'));
  }
  window.addEventListener('resize', redraw);
  setInterval(paintBanner, 10000);
  document.addEventListener('visibilitychange', function () { if (document.hidden) save(); });
  window.addEventListener('pagehide', save);

  paintFit();
  paint();
  window.PIQUETAGE.session = session;      // inspection et tests
  window.PIQUETAGE.paint = paint;
  window.PIQUETAGE.api = {
    say: say, openSheet: openSheet, closeSheet: closeSheet, redraw: redraw, armed: armed, num: num,
    getPlan: function () { return plan; },
    getSel: function () { return sel; },
    getTransform: function () { return lastT; },
    getView: function () { return viewState; },
    setView: function (v) {
      if (v.showPlan !== undefined) viewState.showPlan = v.showPlan !== false;
      if (v.showDone !== undefined) viewState.showDone = !!v.showDone;
      saveView(); redraw();
    },
    setPlan: function (p) {
      plan = p; sel = null; selUndo = null; viewCenter = null;
      try {
        if (!storage) return;
        if (!p) { storage.removeItem(PP.KEY); return; }
        var txt = PP.serialize(p);
        if (txt.length > 3.5e6) { say('Plan trop volumineux pour l’enregistrement local : il ne sera pas conservé au redémarrage'); storage.removeItem(PP.KEY); }
        else storage.setItem(PP.KEY, txt);
      } catch (e) { say('Plan non enregistré (stockage plein) : il ne sera pas conservé au redémarrage'); }
      redraw();
    },
    savePlan: function () { try { if (storage && plan) storage.setItem(PP.KEY, PP.serialize(plan)); } catch (e) {} }
  };
})();
