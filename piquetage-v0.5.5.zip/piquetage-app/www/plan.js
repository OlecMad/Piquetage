/* ==================================================================
   Piquetage — plan importé d'un GeoPackage (.gpkg) de QGIS (sans interface)

   · open(SQL, octets)        lit les couches d'objets d'un GeoPackage (sql.js)
   · loadLayer(db, couche, …) décode les géométries (WKB GeoPackage) et les attributs
   · build / bounds / stats / serialize / parse

   Repère : RGF93 / Lambert-93 (EPSG:2154) uniquement. Une couche dans un autre
   système est REFUSÉE avec un message — jamais reprojetée de façon approximative
   (WGS 84 et RGF93 diffèrent de l'ordre du mètre).

   Altitude Z : prise dans la géométrie (point Z, ligne Z…) ou dans une colonne que
   l'on désigne. Jamais estimée : null si absente. Les valeurs exactement 0 ou
   ≤ -9000 sont signalées (valeurs « par défaut » de QGIS et de ses outils).

   Fonctionne dans la WebView (window.PiqPlan) et sous Node (tests).
   ================================================================== */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PiqPlan = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = 1;
  var KEY = 'piquetage.plan';
  var MAX_PROPS = 12;               // attributs conservés par objet
  var MAX_TEXT = 60;                // longueur maximale d'un texte conservé

  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function q(name) { return '"' + String(name).replace(/"/g, '""') + '"'; }
  function mm(v) { return Math.round(v * 1000) / 1000; }

  /* ---------------- Géométries (WKB de GeoPackage) ---------------- */

  // En-tête GeoPackage : 'GP', version, indicateurs, srs_id, enveloppe facultative, puis WKB.
  var ENV_BYTES = [0, 32, 48, 48, 64];

  function readWkb(r) {
    var dv = r.dv;
    var le = dv.getUint8(r.pos++) === 1;
    var t = dv.getUint32(r.pos, le); r.pos += 4;
    var hasZ, hasM, base;
    if (t & 0xE0000000) {                         // EWKB : indicateurs dans les bits de poids fort
      hasZ = !!(t & 0x80000000); hasM = !!(t & 0x40000000);
      if (t & 0x20000000) r.pos += 4;             // SRID incorporé : ignoré, le srs_id de l'en-tête fait foi
      base = t & 0x0FFFFFFF;
    } else {                                      // ISO : 1000 = Z, 2000 = M, 3000 = ZM
      base = t % 1000;
      var dim = Math.floor(t / 1000);
      hasZ = dim === 1 || dim === 3; hasM = dim === 2 || dim === 3;
    }
    function pt() {
      var x = dv.getFloat64(r.pos, le), y = dv.getFloat64(r.pos + 8, le), z = null;
      r.pos += 16;
      if (hasZ) { z = dv.getFloat64(r.pos, le); r.pos += 8; }
      if (hasM) r.pos += 8;
      return [mm(x), mm(y), (z !== null && isFinite(z)) ? mm(z) : null];
    }
    function pts() { var n = dv.getUint32(r.pos, le); r.pos += 4; var a = []; for (var i = 0; i < n; i++) a.push(pt()); return a; }
    function rings() { var n = dv.getUint32(r.pos, le); r.pos += 4; var a = []; for (var i = 0; i < n; i++) a.push(pts()); return a; }
    function parts() { var n = dv.getUint32(r.pos, le); r.pos += 4; var a = []; for (var i = 0; i < n; i++) a.push(readWkb(r)); return a; }

    switch (base) {
      case 1: {
        var x = dv.getFloat64(r.pos, le);
        if (isNaN(x)) { r.pos += 16 + (hasZ ? 8 : 0) + (hasM ? 8 : 0); return { type: 'Point', c: null }; }   // point vide
        return { type: 'Point', c: pt() };
      }
      case 2: return { type: 'LineString', c: pts() };
      case 3: return { type: 'Polygon', c: rings() };
      case 4: return { type: 'MultiPoint', c: parts().map(function (g) { return g.c; }).filter(Boolean) };
      case 5: return { type: 'MultiLineString', c: parts().map(function (g) { return g.c; }) };
      case 6: return { type: 'MultiPolygon', c: parts().map(function (g) { return g.c; }) };
      case 7: return { type: 'GeometryCollection', parts: parts() };
      default: throw new Error('type de géométrie non pris en charge (WKB ' + t + ')');
    }
  }

  /** Décode un BLOB de géométrie GeoPackage → { srs, empty, g } ou { error }. */
  function decode(blob) {
    if (!blob || blob.length < 8 || blob[0] !== 0x47 || blob[1] !== 0x50) return { error: 'en-tête GeoPackage absent' };
    var flags = blob[3], le = (flags & 1) === 1, empty = ((flags >> 4) & 1) === 1, env = (flags >> 1) & 7;
    if (env > 4) return { error: 'enveloppe inconnue' };
    var dv = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
    var srs = dv.getInt32(4, le);
    if (empty) return { srs: srs, empty: true };
    try {
      return { srs: srs, g: readWkb({ dv: dv, pos: 8 + ENV_BYTES[env] }) };
    } catch (e) {
      return { srs: srs, error: e.message };
    }
  }

  function kindOf(type) {
    if (type === 'Point' || type === 'MultiPoint') return 'point';
    if (type === 'LineString' || type === 'MultiLineString') return 'line';
    if (type === 'Polygon' || type === 'MultiPolygon') return 'polygon';
    return null;
  }

  /** Tous les sommets d'une géométrie normalisée : [[x, y, z|null], …]. */
  function vertices(g) {
    var out = [];
    function walk(c, depth) {
      if (!c) return;
      if (depth === 0) out.push(c); else c.forEach(function (s) { walk(s, depth - 1); });
    }
    var depth = { Point: 0, MultiPoint: 1, LineString: 1, MultiLineString: 2, Polygon: 2, MultiPolygon: 3 }[g.type];
    walk(g.c, depth);
    return out;
  }

  /** Qualité d'une altitude : ok | zero | nodata | absent. */
  function zQuality(z) {
    if (!isNum(z)) return 'absent';
    if (z === 0) return 'zero';
    if (z <= -9000) return 'nodata';
    return 'ok';
  }

  /** Qualité des altitudes portées par la géométrie : la pire des qualités rencontrées. */
  function geomZQuality(g) {
    var vs = vertices(g), rank = { ok: 0, absent: 1, zero: 2, nodata: 3 }, worst = 'ok';
    if (!vs.length) return 'absent';
    vs.forEach(function (v) { var k = zQuality(v[2]); if (rank[k] > rank[worst]) worst = k; });
    return worst;
  }

  /* ---------------- Lecture d'un GeoPackage ---------------- */

  var Z_NAME = /(^z$|^z_|_z$|alt|cote|cot[eé]|ngf|elev|niveau|^h$|^h_)/i;
  var Z_EXCLUDE = /(hauteur|h_ref|profond|pente|largeur|volume|surface|longueur|revanche|espacement|pas_|diam|vidange|duree|durée)/i;
  var LABEL_PREF = ['num', 'numero', 'nom', 'name', 'code', 'label', 'libelle', 'id'];

  function rows(db, sql) {
    var res = db.exec(sql);
    if (!res.length) return [];
    var cols = res[0].columns;
    return res[0].values.map(function (v) { var o = {}; cols.forEach(function (c, i) { o[c] = v[i]; }); return o; });
  }

  function epsgOf(srsRow) {
    if (!srsRow) return null;
    if (String(srsRow.organization).toUpperCase() === 'EPSG') return +srsRow.organization_coordsys_id;
    return null;
  }

  /** Ouvre un GeoPackage. Lève une Error au message clair si le fichier n'en est pas un. */
  function open(SQL, bytes) {
    var db;
    try { db = new SQL.Database(bytes); } catch (e) { throw new Error('Fichier illisible : ce n’est pas une base SQLite (' + e.message + ')'); }
    var hasContents;
    try { hasContents = rows(db, "SELECT name FROM sqlite_master WHERE name = 'gpkg_contents'").length > 0; }
    catch (e) { db.close(); throw new Error('Fichier illisible : ce n’est pas une base SQLite (' + e.message + ')'); }
    if (!hasContents) { db.close(); throw new Error('Ce fichier n’est pas un GeoPackage (table gpkg_contents absente)'); }

    var srsMap = {};
    rows(db, 'SELECT srs_id, organization, organization_coordsys_id FROM gpkg_spatial_ref_sys').forEach(function (r) { srsMap[r.srs_id] = r; });

    var layers = rows(db,
      "SELECT c.table_name AS t, c.identifier AS ident, g.column_name AS gcol, g.geometry_type_name AS gtype, g.srs_id AS srs, g.z AS z " +
      "FROM gpkg_contents c JOIN gpkg_geometry_columns g ON g.table_name = c.table_name WHERE c.data_type = 'features' ORDER BY c.table_name"
    ).map(function (l) {
      var cols = rows(db, 'PRAGMA table_info(' + q(l.t) + ')').filter(function (c) { return c.name !== l.gcol; })
        .map(function (c) { return { name: c.name, type: String(c.type || '').toUpperCase(), pk: !!c.pk }; });
      var count = rows(db, 'SELECT COUNT(*) AS n FROM ' + q(l.t))[0].n;
      var epsg = epsgOf(srsMap[l.srs]);
      var zc = cols.filter(function (c) { return Z_NAME.test(c.name) && !Z_EXCLUDE.test(c.name) && !c.pk; }).map(function (c) { return c.name; });
      var names = cols.map(function (c) { return c.name; });
      var label = LABEL_PREF.filter(function (n) { return names.indexOf(n) >= 0; })[0] || null;

      // Z réellement présent dans la géométrie ? (la déclaration du fichier peut être inexacte)
      var geomZ = false, sample = rows(db, 'SELECT ' + q(l.gcol) + ' AS g FROM ' + q(l.t) + ' WHERE ' + q(l.gcol) + ' IS NOT NULL LIMIT 200');
      for (var i = 0; i < sample.length && !geomZ; i++) {
        var d = decode(sample[i].g);
        if (d.g && d.g.type !== 'GeometryCollection' && vertices(d.g).some(function (v) { return v[2] !== null; })) geomZ = true;
      }
      var refused = epsg === 2154 ? null
        : 'Projection ' + (epsg ? 'EPSG:' + epsg : 'inconnue') + ' non prise en charge. Reprojeter la couche en EPSG:2154 (Lambert-93) dans QGIS : clic droit › Exporter › Enregistrer les objets sous.';
      return {
        table: l.t, title: l.ident || l.t, geomCol: l.gcol, geomType: String(l.gtype || '').toUpperCase(),
        zDeclared: l.z, geomZ: geomZ, epsg: epsg, count: count, columns: cols,
        zCandidates: zc, labelDefault: label, refused: refused
      };
    });
    return { db: db, layers: layers };
  }

  /**
   * Charge une couche.
   * opts : { zField: '__geom' | nom de colonne | null, labelField: nom | null, on: true }
   */
  function loadLayer(db, layer, opts) {
    opts = opts || {};
    if (layer.refused) throw new Error(layer.refused);
    var zField = opts.zField === undefined ? null : opts.zField;
    var labelField = opts.labelField === undefined ? layer.labelDefault : opts.labelField;
    var keep = [];
    function add(n) { if (n && keep.indexOf(n) < 0 && layer.columns.some(function (c) { return c.name === n; })) keep.push(n); }
    add(labelField); layer.zCandidates.forEach(add);
    layer.columns.forEach(function (c) { if (keep.length < MAX_PROPS && !c.pk) add(c.name); });

    var stmt = db.prepare('SELECT rowid AS __rid, * FROM ' + q(layer.table));
    var feats = [], skipped = { empty: 0, unsupported: 0, otherKind: 0 }, kindCount = { point: 0, line: 0, polygon: 0 };
    var decoded = [];
    try {
      while (stmt.step()) {
        var row = stmt.getAsObject();
        if (row[layer.geomCol] === null || row[layer.geomCol] === undefined) { skipped.empty++; continue; }   // pas de géométrie
        var d = decode(row[layer.geomCol]);
        if (d.empty || (d.g && d.g.type === 'Point' && d.g.c === null)) { skipped.empty++; continue; }
        if (d.error || !d.g || !kindOf(d.g.type)) { skipped.unsupported++; continue; }
        kindCount[kindOf(d.g.type)]++;
        decoded.push({ row: row, g: d.g });
      }
    } finally { stmt.free(); }
    var kind = ['point', 'line', 'polygon'].sort(function (a, b) { return kindCount[b] - kindCount[a]; })[0];
    if (!decoded.length) kind = layer.geomType.indexOf('POINT') >= 0 ? 'point' : (layer.geomType.indexOf('LINE') >= 0 ? 'line' : 'polygon');

    var zs = { ok: 0, zero: 0, nodata: 0, absent: 0 };
    decoded.forEach(function (it) {
      if (kindOf(it.g.type) !== kind) { skipped.otherKind++; return; }
      var row = it.row, g = it.g, z = null, zq;
      if (zField === '__geom') {
        if (g.type === 'Point') { z = g.c[2]; zq = zQuality(z); } else { zq = geomZQuality(g); }
      } else if (zField) {
        var raw = row[zField];
        var v = raw === null || raw === undefined || raw === '' ? NaN : Number(String(raw).replace(',', '.'));
        z = isFinite(v) ? v : null; zq = zQuality(z);
      } else { zq = 'absent'; }
      zs[zq]++;
      var p = {};
      keep.forEach(function (n) {
        var v = row[n];
        if (typeof v === 'string' && v.length > MAX_TEXT) v = v.slice(0, MAX_TEXT);
        p[n] = v === undefined ? null : v;
      });
      var lab = labelField && row[labelField] !== null && row[labelField] !== undefined && row[labelField] !== '' ? String(row[labelField]) : 'F' + row.__rid;
      feats.push({ i: row.__rid, l: lab, z: z, q: zq, g: g, p: p });
    });

    return {
      table: layer.table, title: layer.title, kind: kind, zField: zField, labelField: labelField, on: opts.on !== false,
      features: feats, skipped: skipped, zStats: zs
    };
  }

  /* ---------------- Plan complet ---------------- */

  function build(name, layers) {
    return { v: VERSION, name: String(name || ''), imported: new Date().toISOString(), epsg: 2154, layers: layers };
  }

  /** Emprise des couches visibles (ou de toutes si all). Mise en cache non sérialisée. */
  function bounds(plan, all) {
    var key = all ? '__ball' : '__bvis';
    if (plan[key] !== undefined) return plan[key];
    var xs = Infinity, ys = Infinity, xe = -Infinity, ye = -Infinity, n = 0;
    plan.layers.forEach(function (l) {
      if (!all && !l.on) return;
      l.features.forEach(function (f) {
        vertices(f.g).forEach(function (v) {
          if (v[0] < xs) xs = v[0]; if (v[0] > xe) xe = v[0];
          if (v[1] < ys) ys = v[1]; if (v[1] > ye) ye = v[1];
          n++;
        });
      });
    });
    var b = n ? { minX: xs, maxX: xe, minY: ys, maxY: ye } : null;
    Object.defineProperty(plan, key, { value: b, enumerable: false, configurable: true, writable: true });
    return b;
  }

  function invalidate(plan) { delete plan.__bvis; delete plan.__ball; }

  function stats(plan) {
    var s = { layers: plan.layers.length, features: 0, z: { ok: 0, zero: 0, nodata: 0, absent: 0 }, byKind: { point: 0, line: 0, polygon: 0 } };
    plan.layers.forEach(function (l) {
      s.features += l.features.length; s.byKind[l.kind] += l.features.length;
      Object.keys(l.zStats).forEach(function (k) { s.z[k] += l.zStats[k]; });
    });
    return s;
  }

  /* ---------------- Implantation : points posés (0.5.4) ----------------
     Chaque point du plan peut être marqué « implanté » : f.dp[k] = { t, x, y, h, q }
     (k = rang de la partie dans un MultiPoint, 0 pour un Point ; t = date ISO ; x, y, h = position
     mesurée par la canne au moment du marquage, null si aucune position fraîche ; q = qualité). */

  function pointParts(g) {
    if (g.type === 'Point') return g.c ? [g.c] : [];
    if (g.type === 'MultiPoint') return g.c;
    return [];
  }

  /** Nombre de points (parties) du plan et nombre de points implantés. */
  function doneStats(plan) {
    var total = 0, done = 0;
    plan.layers.forEach(function (l) {
      l.features.forEach(function (f) {
        pointParts(f.g).forEach(function (p, k) { total++; if (f.dp && f.dp[k]) done++; });
      });
    });
    return { total: total, done: done };
  }

  function setDone(plan, li, fi, k, rec) {
    var f = plan.layers[li] && plan.layers[li].features[fi];
    if (!f) return false;
    if (rec) { if (!f.dp) f.dp = {}; f.dp[k] = rec; }
    else if (f.dp) { delete f.dp[k]; if (!Object.keys(f.dp).length) delete f.dp; }
    return true;
  }

  /** Liste des points implantés, du plus ancien au plus récent. */
  function doneList(plan) {
    var out = [];
    plan.layers.forEach(function (l, li) {
      l.features.forEach(function (f, fi) {
        if (!f.dp) return;
        var parts = pointParts(f.g);
        Object.keys(f.dp).forEach(function (k) {
          var p = parts[+k];
          if (p) out.push({ li: li, fi: fi, k: +k, layer: l.title, label: f.l, id: f.i, z: isNum(f.z) ? f.z : (isNum(p[2]) ? p[2] : null), px: p[0], py: p[1], rec: f.dp[k] });
        });
      });
    });
    out.sort(function (a, b) { return String(a.rec.t).localeCompare(String(b.rec.t)); });
    return out;
  }

  /** Réimport du même fichier : reprend les points déjà implantés (même table, même objet). */
  function carryDone(oldPlan, newPlan) {
    if (!oldPlan || !newPlan || oldPlan.name !== newPlan.name) return 0;
    var n = 0;
    newPlan.layers.forEach(function (nl) {
      var ol = oldPlan.layers.filter(function (l) { return l.table === nl.table; })[0];
      if (!ol) return;
      var byId = {};
      ol.features.forEach(function (f) { if (f.dp) byId[f.i] = f.dp; });
      nl.features.forEach(function (f) {
        var dp = byId[f.i];
        if (!dp) return;
        var parts = pointParts(f.g), keep = {};
        Object.keys(dp).forEach(function (k) { if (parts[+k]) { keep[k] = dp[k]; n++; } });
        if (Object.keys(keep).length) f.dp = keep;
      });
    });
    return n;
  }

  function serialize(plan) { return JSON.stringify(plan); }

  function validGeom(g) {
    return g && typeof g === 'object' && ['Point', 'MultiPoint', 'LineString', 'MultiLineString', 'Polygon', 'MultiPolygon'].indexOf(g.type) >= 0 && Array.isArray(g.c);
  }

  /** Relit un plan enregistré ; null si inexploitable. */
  function parse(text) {
    try {
      var p = JSON.parse(text);
      if (!p || p.v !== VERSION || !Array.isArray(p.layers)) return null;
      var ok = p.layers.every(function (l) {
        return l && Array.isArray(l.features) && ['point', 'line', 'polygon'].indexOf(l.kind) >= 0 && l.zStats &&
          l.features.every(function (f) { return f && validGeom(f.g); });
      });
      if (!ok) return null;
      p.layers.forEach(function (l) {
        if (l.on === undefined) l.on = true;
        l.features.forEach(function (f) { if (f.dp !== undefined && (!f.dp || typeof f.dp !== 'object')) delete f.dp; });
      });
      return p;
    } catch (e) { return null; }
  }

  return {
    open: open, loadLayer: loadLayer, build: build, bounds: bounds, invalidate: invalidate, stats: stats,
    serialize: serialize, parse: parse, decode: decode, vertices: vertices, zQuality: zQuality,
    doneStats: doneStats, setDone: setDone, doneList: doneList, carryDone: carryDone,
    KEY: KEY, VERSION: VERSION
  };
});
