/* Banc d'essai sans navigateur : index.html + scripts de l'application dans jsdom,
   canvas réel (@napi-rs/canvas), faux pont Capacitor repris de tools/verify-screen.js. */
const fs = require('fs'), path = require('path');
const { JSDOM } = require('jsdom');
const { createCanvas } = require('@napi-rs/canvas');

function load(root, opts) {
  opts = opts || {};
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  const scripts = [...html.matchAll(/<script src="([^"]+)"><\/script>/g)].map((m) => m[1]);
  const dom = new JSDOM(html.replace(/<script src="[^"]+"><\/script>/g, ''), { url: 'http://localhost/', pretendToBeVisual: true, runScripts: 'outside-only' });
  const w = dom.window;
  if (opts.storage) Object.keys(opts.storage).forEach((k) => w.localStorage.setItem(k, opts.storage[k]));
  const W = opts.w || 340, H = opts.h || 300;
  Object.defineProperty(w.HTMLCanvasElement.prototype, 'clientWidth', { get() { return this.id === 'cv-prof' ? W : W; } });
  Object.defineProperty(w.HTMLCanvasElement.prototype, 'clientHeight', { get() { return this.id === 'cv-prof' ? 140 : (this.__h || H); } });
  w.HTMLCanvasElement.prototype.getContext = function () {
    const cw = this.width || 1, ch = this.height || 1;
    if (!this._c || this._c.width !== cw || this._c.height !== ch) { this._c = createCanvas(cw, ch); this._x = this._c.getContext('2d'); }
    return this._x;
  };
  w.devicePixelRatio = 2;
  const vs = fs.readFileSync(path.join(root, '../tools/verify-screen.js'), 'utf8');
  const fake = vs.slice(vs.indexOf('const FAKE = () => {') + 'const FAKE = '.length, vs.indexOf('\n};\n', vs.indexOf('const FAKE')) + 2);
  w.eval('(' + fake + ')()');
  const errors = [];
  w.addEventListener('error', (e) => errors.push(e.message));
  for (const s of scripts) {
    let code = fs.readFileSync(path.join(root, s), 'utf8');
    try { w.eval(code + '\n//# sourceURL=' + s); } catch (e) { errors.push(s + ': ' + e.stack); }
  }
  return { dom, w, errors };
}
const tick = (ms) => new Promise((r) => setTimeout(r, ms || 60));
module.exports = { load, tick };
