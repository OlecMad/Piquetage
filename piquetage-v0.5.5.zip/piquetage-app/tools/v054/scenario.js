/* Scénario commun : plan synthétique de chantier + marche RTK, avec une coupure de 4 s. */
const LAT0 = 47.1833, LON0 = 1.0940;
function makePlan(w, x0, y0) {
  const P = w.PiqPlan, layers = [];
  const defs = [
    { t: 'grands_arbres', title: 'Grands arbres', code: 'Qpu', col: '#1B5E20', dx: 0, dy: 0 },
    { t: 'petits_arbres', title: 'Petits arbres', code: 'Psp', col: '#EF6C00', dx: 1.25, dy: 0.8 },
    { t: 'arbustes', title: 'Arbustes', code: 'Cav', col: '#AD1457', dx: 0.6, dy: 1.7 },
  ];
  let n = 0;
  defs.forEach((d) => {
    const feats = [];
    for (let i = 0; i < 24; i++) for (let j = 0; j < 14; j++) {
      n++;
      const x = Math.round((x0 - 10 + i * 2.5 + d.dx) * 1000) / 1000, y = Math.round((y0 - 6 + j * 2.5 + d.dy) * 1000) / 1000;
      feats.push({ i: n, l: d.code + ' ' + n, z: 120, q: 'ok', g: { type: 'Point', c: [x, y, 120] }, p: { couleur_qgis: d.col } });
    }
    layers.push({ table: d.t, title: d.title, kind: 'point', zField: null, labelField: 'code', on: true, features: feats, skipped: {}, zStats: { ok: feats.length, zero: 0, nodata: 0, absent: 0 } });
  });
  layers.push({ table: 'fosse', title: 'Fossé', kind: 'line', zField: null, labelField: null, on: true,
    features: [{ i: 1, l: 'F1', z: null, q: 'absent', g: { type: 'LineString', c: [[x0 - 12, y0 + 3, null], [x0 + 50, y0 + 5, null]] }, p: {} }],
    skipped: {}, zStats: { ok: 0, zero: 0, nodata: 0, absent: 1 } });
  return P.build('Implantation_test.gpkg', layers);
}
// position à (dx, dy) mètres de l'origine (approximation locale suffisante pour un essai)
function nmeaAt(w, dx, dy, q) {
  const lat = LAT0 + dy / 111132, lon = LON0 + dx / (111320 * Math.cos(LAT0 * Math.PI / 180));
  w.__nmea(lat, lon, 100, 47, q === undefined ? 4 : q);
}
module.exports = { makePlan, nmeaAt, LAT0, LON0 };
