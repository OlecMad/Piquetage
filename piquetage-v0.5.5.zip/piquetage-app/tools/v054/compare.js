/* Mesure, sur la même marche, la stabilité de l'affichage : v0.5.3 (avant) et v0.5.4 (après). */
const { load, tick } = require('./harness');
const { makePlan, nmeaAt } = require('./scenario');
const fs = require('fs');

async function run(root, span, tag) {
  // première ouverture pour connaître l'origine Lambert-93 et fabriquer le plan
  let A = load(root); let w = A.w; await tick(50);
  nmeaAt(w, 0, 0); await tick(30);
  const st0 = w.PIQUETAGE.rtk.status(), x0 = st0.point.x93, y0 = st0.point.y93;
  const plan = makePlan(w, x0, y0);
  const storage = { 'piquetage.plan': w.PiqPlan.serialize(plan), 'piquetage.view': JSON.stringify({ showPlan: true, mode: 'here', span: span }) };
  A.dom.window.close();
  A = load(root, { storage }); w = A.w; await tick(80);
  const labelsSet = new Set(); plan.layers.forEach((l) => l.features.forEach((f) => labelsSet.add(f.l)));
  const anchor = {}; plan.layers.forEach((l) => l.features.forEach((f) => { if (f.g.type === 'Point') anchor[f.l] = f.g.c; }));
  // journal des textes écrits et des points dessinés sur le canvas du tracé
  const cv = w.document.getElementById('cv-track');
  let frame = null; const frames = [];
  const origGet = w.HTMLCanvasElement.prototype.getContext;
  cv.getContext = function () {
    const ctx = origGet.call(this);
    if (!ctx.__wrapped) {
      const ft = ctx.fillText.bind(ctx), cr = ctx.clearRect.bind(ctx);
      ctx.fillText = function (t, x, y) { if (frame && labelsSet.has(t)) frame.labels[t] = [x, y]; return ft(t, x, y); };
      ctx.clearRect = function (a, b, c, d) { frame = { labels: {} }; frames.push(frame); return cr(a, b, c, d); };
      ctx.__wrapped = true;
    }
    return ctx;
  };
  const V = w.PiqViews, od = V.drawTrack;
  V.drawTrack = function () { const r = od.apply(this, arguments); if (frame) frame.T = r; return r; };

  // marche : 0,25 m par époque vers l'est, bruit RTK ±1 cm ; coupure de 4 s au milieu
  let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647 - 0.5) * 0.02;
  const realNow = Date.now; let offset = 0; w.Date.now = () => realNow() + offset;
  const marks = [];
  for (let s = 0; s <= 48; s++) {
    if (s === 24) { offset += 4200; await tick(1150); marks.push(frames.length); }   // trame absente > 3 s : position « non fraîche »
    nmeaAt(w, s * 0.25 + rnd(), 0.4 * Math.sin(s / 6) + rnd()); await tick(25);
  }
  const done = frames.filter((f) => f.T);
  // métriques
  let jumps = 0, flick = 0, viewJumps = 0, pairs = 0, moves = 0;
  const pb = w.PiqPlan.bounds(plan), pcx = (pb.minX + pb.maxX) / 2, pcy = (pb.minY + pb.maxY) / 2;
  for (let i = 1; i < done.length; i++) {
    const a = done[i - 1], b = done[i];
    if (Math.hypot(b.T.cx - pcx, b.T.cy - pcy) < 0.5 && Math.hypot(a.T.cx - pcx, a.T.cy - pcy) >= 0.5) viewJumps++;
    if (Math.hypot(a.T.cx - b.T.cx, a.T.cy - b.T.cy) > 1e-6) moves++;
    const scr = (T, l) => [T.w / 2 + (anchor[l][0] - T.cx) * T.scale, T.h / 2 - (anchor[l][1] - T.cy) * T.scale];
    const inside = (T, p) => p[0] > 25 && p[1] > 25 && p[0] < T.w - 25 && p[1] < T.h - 25;
    Object.keys(anchor).forEach((l) => {
      const pa = scr(a.T, l), pb = scr(b.T, l);
      if (!inside(a.T, pa) || !inside(b.T, pb)) return;
      pairs++;
      const la = a.labels[l], lb = b.labels[l];
      if (!!la !== !!lb) { flick++; return; }
      if (la && lb && Math.hypot((la[0] - pa[0]) - (lb[0] - pb[0]), (la[1] - pa[1]) - (lb[1] - pb[1])) > 1) jumps++;
    });
  }
  const r = { tag, span, images: done.length, deplacements_du_cadre: moves, sauts_au_centre_du_plan: viewJumps, etiquettes_suivies: pairs, etiquettes_qui_changent_de_cote: jumps, etiquettes_qui_clignotent: flick, erreurs: A.errors.length };
  // image avant / pendant / après la coupure
  fs.writeFileSync('/tmp/piq-v054/' + tag + '_' + span + '_avant.png', cv._c.toBuffer('image/png'));
  A.dom.window.close();
  return r;
}

(async () => {
  fs.mkdirSync('/tmp/piq-v054', { recursive: true });
  const res = [];
  for (const span of [60, 20]) {
    res.push(await run(require('path').resolve(process.argv[2]), span, 'avant'));
    res.push(await run(require('path').resolve(process.argv[3] || 'www'), span, 'v054'));
  }
  console.table(res);
  process.exit(0);
})();
