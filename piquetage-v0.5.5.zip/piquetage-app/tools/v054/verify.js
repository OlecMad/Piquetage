/* Banc d'essai 0.5.4 — à lancer depuis le dossier du projet :
     npm i --no-save jsdom@24.1.3 @napi-rs/canvas@0.1.56
     node tools/v054/verify.js www            (vérifications fonctionnelles)
     node tools/v054/compare.js <www 0.5.3> www (stabilité avant / après)
   Images écrites dans /tmp/piq-v054. */
/* Vérification fonctionnelle v0.5.4 (jsdom + canvas réel, faux pont Capacitor). */
const { load, tick } = require('./harness');
const { makePlan, nmeaAt } = require('./scenario');
const fs = require('fs');
let n = 0, fails = 0;
function ok(c, label, detail) { n++; console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : '')); if (!c) fails++; }
const ROOT = require('path').resolve(process.argv[2] || 'www'); require('fs').mkdirSync('/tmp/piq-v054', { recursive: true });

(async () => {
  let A = load(ROOT); let w = A.w; await tick(50);
  nmeaAt(w, 0, 0); await tick(30);
  const st0 = w.PIQUETAGE.rtk.status(), x0 = st0.point.x93, y0 = st0.point.y93;
  const plan = makePlan(w, x0, y0);
  A.dom.window.close();
  A = load(ROOT, { storage: { 'piquetage.plan': w.PiqPlan.serialize(plan) } }); w = A.w; await tick(80);
  const $ = (id) => w.document.getElementById(id);
  const api = w.PIQUETAGE.api, P = w.PiqPlan;
  const click = async (id) => { $(id).click(); await tick(40); };
  nmeaAt(w, 0, 0); await tick(60);

  console.log('── Cadrage');
  ok($('b-fit').textContent === 'Vue : tout' && $('b-zout').disabled && !$('b-zin').disabled, 'départ : « Vue : tout », « − » inactif');
  const seq = [];
  // journal des étiquettes du plan écrites sur le canvas, avec leur couleur
  const colOf = {}; plan.layers.forEach((l) => l.features.forEach((f) => { colOf[f.l] = (f.p && f.p.couleur_qgis || '').toLowerCase(); }));
  let written = {};
  const cv = $('cv-track'), getc = cv.getContext.bind(cv);
  cv.getContext = function () {
    const ctx = getc();
    if (!ctx.__w) { const ft = ctx.fillText.bind(ctx), cr = ctx.clearRect.bind(ctx);
      ctx.fillText = function (t, x, y) { if (colOf[t] !== undefined) written[t] = String(ctx.fillStyle).toLowerCase(); return ft(t, x, y); };
      ctx.clearRect = function (a, b, c, d) { written = {}; return cr(a, b, c, d); };
      ctx.__w = true; }
    return ctx;
  };
  for (let i = 0; i < 6; i++) { await click('b-zin'); seq.push($('b-fit').textContent); }
  ok(seq.join(' | ') === 'Ici 60 m | Ici 20 m | Ici 15 m | Ici 10 m | Ici 5 m | Ici 5 m', '« + » : 60 → 20 → 15 → 10 → 5 m, puis reste à 5 m', seq.join(' | '));
  ok($('b-zin').disabled, '« + » inactif à 5 m');
  let T = api.getTransform();
  ok(Math.abs(T.scale - (Math.min(T.w, T.h) - 44) / 5) < 1e-6, 'à 5 m : échelle = (côté − 44 px) / 5 m', T.scale.toFixed(1) + ' px/m');
  const names = Object.keys(written);
  ok(names.length > 0 && names.every((t) => written[t] === colOf[t]), 'étiquettes écrites dans la couleur de leur point', names.length + ' étiquettes · ' + names.slice(0, 3).map((t) => t + ' ' + written[t]).join(', '));
  fs.writeFileSync('/tmp/piq-v054/v054_5m.png', $('cv-track')._c.toBuffer('image/png'));
  await click('b-zout'); fs.writeFileSync('/tmp/piq-v054/v054_10m.png', $('cv-track')._c.toBuffer('image/png'));
  ok($('b-fit').textContent === 'Ici 10 m' && !$('b-zin').disabled, '« − » : 5 → 10 m, « + » de nouveau actif');
  await click('b-zout'); fs.writeFileSync('/tmp/piq-v054/v054_15m.png', $('cv-track')._c.toBuffer('image/png'));
  await click('b-zout'); fs.writeFileSync('/tmp/piq-v054/v054_20m.png', $('cv-track')._c.toBuffer('image/png'));
  const n20 = Object.keys(written);
  ok(n20.length > 0 && n20.every((t) => written[t] === colOf[t]), 'à 20 m aussi : étiquettes dans la couleur du point', n20.length + ' étiquettes');
  ok($('b-fit').textContent === 'Ici 20 m', '« − » : 10 → 15 → 20 m');
  await click('b-fit'); ok($('b-fit').textContent === 'Vue : tout', 'bouton du milieu : bascule vers « tout »');
  await click('b-fit'); ok($('b-fit').textContent === 'Ici 20 m', 'puis revient au dernier cadrage « ici » (20 m)');
  ok(JSON.parse(w.localStorage.getItem('piquetage.view')).span === 20, 'cadrage mémorisé au redémarrage');
  await click('b-zin'); await click('b-zin');   // 10 m

  console.log('── Centre du cadre (zone morte)');
  const c0 = api.getTransform();
  nmeaAt(w, 1.5, -1.0); await tick(60);
  let c1 = api.getTransform();
  ok(c1.cx === c0.cx && c1.cy === c0.cy, 'déplacement de 1,8 m à 10 m : le plan ne bouge pas');
  nmeaAt(w, 3.6, 0); await tick(60);
  c1 = api.getTransform();
  const st = w.PIQUETAGE.rtk.status();
  ok(Math.abs(c1.cx - st.point.x93) < 1e-6 && Math.abs(c1.cy - st.point.y93) < 1e-6, 'sortie de la zone centrale (> 3 m) : recentrage sur la position');
  const realNow = Date.now; w.Date.now = () => realNow() + 5000; await tick(1150);
  const c2 = api.getTransform();
  ok(!w.PIQUETAGE.rtk.status().fresh && c2 && c2.cx === c1.cx && c2.cy === c1.cy, 'trame absente depuis plus de 3 s : le cadre reste en place (v0.5.3 sautait au centre du plan)');
  w.Date.now = realNow; nmeaAt(w, 3.6, 0); await tick(60);

  console.log('── Toucher un point, le marquer implanté');
  T = api.getTransform();
  // point du plan le plus proche de la position
  const sp = w.PIQUETAGE.rtk.status().point;
  let best = null;
  plan.layers.forEach((l, li) => l.features.forEach((f, fi) => { if (f.g.type !== 'Point') return; const d = Math.hypot(f.g.c[0] - sp.x93, f.g.c[1] - sp.y93); if (!best || d < best.d) best = { li, fi, f, d }; }));
  const sx = T.w / 2 + (best.f.g.c[0] - T.cx) * T.scale, sy = T.h / 2 - (best.f.g.c[1] - T.cy) * T.scale;
  const tap = async (x, y) => { $('cv-track').dispatchEvent(new w.MouseEvent('click', { bubbles: true, clientX: x, clientY: y })); await tick(60); };
  await tap(sx + 9, sy - 7);
  ok(!$('selcard').hidden && $('sel-l').textContent === best.f.l, 'appui à 11 px du point : il est sélectionné', $('sel-l').textContent + ' · ' + $('sel-s').textContent);
  ok(/à \d+,\d{2} m/.test($('sel-s').textContent) && $('sel-act').textContent === 'Implanté ✓', 'carte : couche, distance à la canne, bouton « Implanté ✓ »');
  fs.writeFileSync('/tmp/piq-v054/v054_selection.png', $('cv-track')._c.toBuffer('image/png'));
  await click('sel-act');
  ok($('sel-l').textContent === best.f.l + ' implanté ✓' && $('sel-act').textContent === 'Annuler', 'après « Implanté ✓ » : confirmation et « Annuler » pendant 6 s', $('sel-s').textContent);
  const lp = api.getPlan().layers[best.li].features[best.fi];
  ok(lp.dp && lp.dp[0] && Math.abs(lp.dp[0].x - sp.x93) < 0.002 && lp.dp[0].q !== undefined, 'position de la canne enregistrée avec le marquage', JSON.stringify(lp.dp[0]));
  let saved = P.parse(w.localStorage.getItem(P.KEY));
  ok(saved.layers[best.li].features[best.fi].dp[0].t === lp.dp[0].t, 'marquage enregistré sur l’appareil (relu au redémarrage)');
  T = api.getTransform();
  ok(w.PiqViews.hitPlan(api.getPlan(), T, sx, sy, { tol: 26 }) === null || w.PiqViews.hitPlan(api.getPlan(), T, sx, sy, { tol: 26 }).fi !== best.fi, 'le point implanté n’est plus touchable');
  fs.writeFileSync('/tmp/piq-v054/v054_implante.png', $('cv-track')._c.toBuffer('image/png'));
  await click('sel-act');
  ok(!api.getPlan().layers[best.li].features[best.fi].dp && $('sel-act').textContent === 'Implanté ✓', '« Annuler » : le point redevient à implanter et reste sélectionné');
  await click('sel-act');
  await tick(50);
  // 2e point
  const f2 = plan.layers[0].features[best.li === 0 ? best.fi + 1 : best.fi];
  await click('sel-x');
  ok($('selcard').hidden, '✕ ferme la carte');

  console.log('── Panneau Projet');
  w.PIQUETAGE.paintPlan();
  ok(!$('impl-box').hidden && /Implantation : 1 \/ 1008 points implantés · reste 1007/.test($('impl-status').textContent), 'compteur', $('impl-status').textContent);
  $('impl-show').checked = true; $('impl-show').dispatchEvent(new w.Event('change')); await tick(60);
  T = api.getTransform();
  const h2 = w.PiqViews.hitPlan(api.getPlan(), T, sx, sy, { tol: 26, showDone: true });
  ok(h2 && h2.fi === best.fi && h2.li === best.li, '« Montrer les points implantés » : le point reparaît grisé et redevient touchable');
  fs.writeFileSync('/tmp/piq-v054/v054_implantes_grises.png', $('cv-track')._c.toBuffer('image/png'));
  ok(written[best.f.l] !== undefined && written[best.f.l] !== colOf[best.f.l], 'point implanté affiché : étiquette grise, pas dans la couleur du plant', written[best.f.l]);
  await tap(sx, sy);
  ok($('sel-act').textContent === 'Rétablir' && /implanté le/.test($('sel-s').textContent), 'point implanté touché : bouton « Rétablir », date affichée', $('sel-s').textContent);
  $('impl-show').checked = false; $('impl-show').dispatchEvent(new w.Event('change')); await click('sel-x');

  console.log('── Export');
  const X = w.PiqExport;
  const res = X.build({ project: 'Essai', place: '', points: [], tracks: [] }, { now: new Date(2026, 9, 31, 10, 0), plan: api.getPlan() });
  ok(!res.error && res.files.length === 1 && /_implantation\.csv$/.test(res.files[0].name), 'sans point ni tracé : seul le CSV d’implantation est produit', res.files.map((f) => f.name).join(', '));
  const lines = res.files[0].content.replace('﻿', '').trim().split('\r\n');
  const row = lines[1].split(';'), head = lines[0].split(';');
  const ec = +row[head.indexOf('ecart_plan_m')];
  ok(lines.length === 2 && row[head.indexOf('etiquette')] === best.f.l && Math.abs(ec - best.d) < 0.002, 'ligne exportée : étiquette, position prévue et mesurée, écart', 'écart ' + ec + ' m (attendu ' + best.d.toFixed(3) + ')');
  const empty = X.build({ project: 'Essai', place: '', points: [], tracks: [] }, { now: new Date(), plan: null });
  ok(!!empty.error, 'rien à exporter : message conservé');

  console.log('── Réimport du même fichier');
  const plan2 = makePlan(w, x0, y0);
  const kept = P.carryDone(api.getPlan(), plan2);
  ok(kept === 1 && plan2.layers[best.li].features[best.fi].dp, 'les points déjà implantés sont repris');
  const other = makePlan(w, x0, y0); other.name = 'Autre.gpkg';
  ok(P.carryDone(api.getPlan(), other) === 0, 'autre fichier : rien n’est repris');

  console.log('── Rétablir');
  await click('impl-undo');
  ok(P.doneStats(api.getPlan()).done === 0, '« Rétablir le dernier »');

  ok(A.errors.length === 0, 'aucune erreur JavaScript', A.errors.join(' / '));
  console.log((fails ? '✗ ' + fails + ' échec(s) sur ' : '✓ ') + n + ' vérifications' + (fails ? '' : ' réussies'));
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
