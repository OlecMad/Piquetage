# Piquetage — relevé et implantation RTK

Application Android (Capacitor 8) de relevé et d'implantation, reliée à un récepteur RTK
(ZED-F9P) en **Bluetooth LE, USB ou Bluetooth Classic** et au réseau Centipede.
Calculs en **Lambert-93 (EPSG:2154)**, altitudes **NGF-IGN69** par la grille **RAF20**.

Version **0.5.5 — étape 4** : écran principal (disposition C) avec tracé et profil en direct,
points levés numérotés, projet enregistré sur l'appareil, **export CSV et DXF**, **import d'un plan GeoPackage (.gpkg)**. Le code RTK est repris de Diagnostic
Fluvial 1.6 (validé sur le terrain avec la canne) ; il est ici séparé de toute interface.

## Liaison avec le récepteur

| Mode | Principe | À savoir |
|---|---|---|
| **Bluetooth LE** (défaut) | GATT : notifications pour les trames du récepteur, écritures découpées au MTU pour les corrections RTCM | Profils reconnus : Nordic UART, Microchip, HM-10 / FFE0, u-blox SPS ; à défaut, premier service non normalisé ayant une notification et une écriture. Sinon la connexion échoue avec la liste des services du récepteur. Android ≥ 12 : permission « appareils à proximité » ; Android ≤ 11 : localisation précise activée |
| **USB** | câble USB-OTG, bibliothèque usb-serial-for-android 3.9.0 (MIT, intégrée en source) : CDC-ACM (USB natif du ZED-F9P), FTDI, CP210x, CH34x, Prolific | Autorisation demandée par Android à chaque câble ; vitesse réglable (sans effet sur l'USB natif) |
| **Classique** | SPP, repris de Diagnostic Fluvial | Secours ; appairage préalable dans Android |

Les corrections NTRIP (Centipede, crtk.net:2101) passent par le même lien que les trames. En BLE, les écritures sont mises en file
(16 Ko au plus) : si la liaison ne suit pas, les corrections les plus anciennes sont abandonnées plutôt que d'accumuler du retard ;
le compte des octets abandonnés est affiché sous le bouton « Connecter ».

### Modifié en 0.5.5

| Sujet | Avant (0.5.4) | En 0.5.5 |
|---|---|---|
| Couleur des étiquettes | texte noir pour tous les points | chaque étiquette est écrite **dans la couleur de son point** (colonne `couleur_qgis`, `couleur`, `color` ou `colour`, sinon couleur de la couche), sur un liseré du fond ; gris pour un point implanté affiché |
| Zoom maximal | 10 m | **5 m** : tout · 60 · 20 · 15 · 10 · 5 m (environ 50 px par mètre sur un téléphone) ; à 5 m, le cadre se recentre quand la position s'écarte de plus de 1,5 m du centre |

### Nouveau et corrigé en 0.5.4 (implantation des plants)

| Sujet | Avant (0.5.3) | En 0.5.4 |
|---|---|---|
| Plan qui « saute » et points qui disparaissent | En vue « ici », le cadre suivait la position à chaque trame ; si aucune trame n'arrivait pendant 3 s, la position n'était plus « fraîche » et le cadre partait au **centre du plan**, puis revenait. Le bloc d'instruments changeait aussi de hauteur avec le texte affiché, ce qui redimensionnait le plan | Le cadre ne bouge que si la position sort de la zone centrale (30 % du cadre de part et d'autre du centre) ; une coupure ne le déplace plus. Hauteur du bloc d'instruments fixe (texte sur 2 lignes au plus, libellés sur une ligne) |
| Étiquettes qui changent de côté | Chaque étiquette était repoussée dès qu'elle touchait le bord du cadre, ce qui en déplaçait d'autres en cascade | Ordre de placement fixe, étiquettes rognées au bord au lieu de sauter, mémoire de la position choisie ; zones réservées sous la flèche du nord, l'échelle, le texte d'information et les boutons |
| Cadrage | tout → 60 m → 20 m | Boutons **− / +** : tout · 60 · 20 · 15 · **10 m** ; le bouton du milieu bascule entre « tout » et le dernier cadrage « ici » |
| Points déjà posés | Aucun suivi | **Toucher un point** du plan (tolérance 26 px) : carte avec code, couche et distance à la canne, bouton **« Implanté ✓ »**. Le point est **retiré du plan**, avec « Annuler » pendant 6 s. Projet › Plan : compteur, « Montrer les points implantés » (grisés, touchables pour les rétablir), « Rétablir le dernier », « Tout rétablir » |
| Trace de l'implantation | — | La position de la canne au moment du marquage est conservée et exportée dans `…_implantation.csv` (position prévue, position mesurée, écart, qualité). Un réimport du même fichier .gpkg conserve les points déjà implantés |

### Corrigé en 0.5.3 (codes des plants invisibles sur le téléphone)

Les étiquettes du plan importé n'étaient écrites qu'à partir de 6 px par mètre ; sur un téléphone, la vue
« ici (60 m) » donne environ 5 px/m et la vue « tout » 2 à 3 px/m : aucune étiquette n'apparaissait. Désormais :

| Changement | Détail |
|---|---|
| Étiquettes | écrites dès 2 px/m, en gras 12 px avec un liseré, au-dessus de tout le plan ; une étiquette qui en chevaucherait une autre ou sortirait du cadre est omise (jamais superposée) |
| Cadrage | bouton en trois crans : **tout → ici (60 m) → ici (20 m)** ; à 20 m, environ 16 px/m sur un téléphone : toutes les étiquettes des plants sont lisibles |
| Couleurs | un objet qui porte une colonne `couleur_qgis`, `couleur`, `color` ou `colour` au format `#RRVVBB` est dessiné dans cette couleur ; sinon, couleur de la couche comme avant. La pastille de la couche reprend cette couleur si elle est unique |
| Points | rayon 4,5 px au lieu de 3 dès 10 px/m |

Un plan déjà importé en 0.5.2 n'a pas à être réimporté : les attributs (dont la couleur) sont déjà enregistrés.

### Défaut corrigé en 0.5.2 (altitude 2 m trop haute, comparée à SW Maps)

L'altitude au sol n'était calculée que si la hauteur de canne **et** le décalage du centre de phase étaient saisis ; avec la canne
seule, l'écran affichait l'altitude de l'antenne (la hauteur de canne de trop). Désormais : canne saisie → altitude au sol dès
la canne, le centre de phase non saisi n'étant pas soustrait et l'écran, les exports (CSV, avertissement) et le panneau Canne le
signalent ; canne absente → altitude de l'**antenne**, annoncée en orange avec la raison. Le panneau Canne affiche aussi h ellipsoïdale
et N (RAF20) pour comparer terme à terme avec un autre logiciel.

### Défauts corrigés en 0.5.1 (rapport de plantage du 11 octobre, Fairphone 6, Android 15)

- **Plantage en BLE** : le récepteur négocie un MTU de 517 ; les morceaux d'écriture de 514 octets dépassaient les 512 octets
  qu'Android accepte pour une valeur d'attribut (`IllegalArgumentException` dans le fil d'écriture). Les morceaux sont
  maintenant plafonnés à 512, une taille refusée ramène à 20 octets, et aucune erreur d'écriture ne peut plus s'échapper du fil.
- **NTRIP sans position** : un point de montage « proche » (NEAR) ne diffuse rien tant que le caster n'a pas de position. Le client
  n'envoie plus que les GGA avec position (pas les `$GNGGA,hhmmss,,,,,0,…`) et tolère 2 minutes de silence tant qu'il n'a rien
  à envoyer, au lieu de se reconnecter toutes les 30 s ; le message l'explique.

## Écran principal

Bandeau (projet, lieu, date, heure) · pastille de qualité RTK et précisions · un instrument en
gros chiffres (**Alt.** altitude NGF, **Points** levés, **Cap** de marche) · tracé en direct ·
profil altimétrique · barre **Point / Tracé / Impl. / Canne / Projet**. Sur tablette en paysage,
instruments à gauche, tracé et profil à droite.

| Choix | Détail |
|---|---|
| Repère | RGF93 / Lambert-93 (EPSG:2154), nord **du plan** en haut ; altitudes NGF-IGN69 (grille RAF20) |
| Altitude | « sol » si hauteur de canne et centre de phase sont saisis, sinon « antenne » ; jamais estimée |
| Distances | sur le plan Lambert-93 (distance de grille, pas de terrain) |
| Tracé | un sommet tous les 0,5 / 1 / 2 / 5 m (réglable, 1 m par défaut) ; seulement en RTK FIX si « FIX uniquement » |
| Cap de marche | calculé sur la marche récente (≥ 3 m), par rapport au nord du plan — pas le nord géographique ni une boussole |
| Écran | maintenu allumé pendant l'utilisation (FLAG_KEEP_SCREEN_ON) |
| Session | enregistrée dans le stockage local de l'appareil, relue au lancement |

## Export

| Fichier | Contenu |
|---|---|
| `<projet>_<AAAAMMJJ-HHMM>_points.csv` | un point par ligne : X/Y Lambert-93, H NGF et sa nature (sol / antenne), h ellipsoïdale, hauteur de canne, centre de phase, qualité, précision, époques, satellites, point de montage, récepteur, latitude/longitude RGF93 |
| `…_traces.csv` | un sommet par ligne : trace, rang, date, X, Y, H, nature, distance cumulée sur le plan |
| `….dxf` | DXF R12 ASCII : POINT entouré d'un CIRCLE de 0,15 m, numéros, altitudes, polylignes 3D, cartouche (EPSG:2154, NGF-IGN69) |
| `…_local.dxf` | même dessin en repère local (X, Y diminués d'une origine arrondie au 100 m, inscrite au cartouche) |

CSV : séparateur `;`, UTF-8 avec BOM, fins de ligne CRLF ; décimale **point** par défaut (QGIS), virgule au choix (Excel en français).
Une altitude absente n'est jamais remplacée par une valeur estimée : cellule vide en CSV ; en DXF, Z vaut 0
(imposé par le format) et l'objet est mis dans un calque `PIQ_PT_SANS_Z`. La nature de l'altitude se lit dans
les calques : `PIQ_PT_SOL`, `PIQ_PT_ANTENNE`, `PIQ_TRACE_SOL`, `PIQ_TRACE_ANTENNE` ; un tracé aux altitudes
mélangées ou absentes est exporté en 2D (`PIQ_TRACE_2D`). Un DXF ne porte pas de système de coordonnées :
il est indiqué dans le cartouche. Les fichiers portent un nom horodaté, sans écrasement.

Structure du DXF : mêmes sections, mêmes 8 tables et mêmes 132 variables d'en-tête qu'un DXF R12 écrit par ezdxf (squelette généré par `tools/make_dxf_skeleton.py`), sans poignées (`$HANDLING` = 0), codes de groupe cadrés à droite, fins de ligne CRLF. Un DXF aux sections et tables minimales avait été lu par Affinity, GDAL et ezdxf mais refusé par Vectorworks et DesignCAD.

DXF et logiciels : le R12 ASCII est la version de DXF la mieux prise en charge entre logiciels (source : DANS, archivage des formats CAO). Vectorworks ne lit pas d'unités dans un DXF antérieur à 2000 : choisir le mètre à l'import. Compatibilité avec DesignCAD 10 : non vérifiée (aucune source trouvée pour cette version) ; à tester sur votre poste.

## Import d'un plan QGIS (.gpkg)

Projet › Plan QGIS › Importer un plan : on choisit un GeoPackage, on coche les couches d'objets voulues, et pour
chacune la source de l'altitude Z et l'étiquette. SQLite (sql.js 1.14.2, MIT, WebAssembly) n'est chargé qu'à ce moment.

| Règle | Détail |
|---|---|
| Repère | **EPSG:2154 (Lambert-93) uniquement.** Une couche en WGS 84, Mercator ou projection inconnue est refusée avec un message ; jamais reprojetée de façon approximative (WGS 84 et RGF93 diffèrent de l'ordre du mètre) |
| Géométries | points, lignes, polygones et leurs versions multiples, avec ou sans Z, WKB ISO ou EWKB, petit ou gros boutiste. Géométries vides ou courbes : ignorées et comptées |
| Altitude Z | « Z de la géométrie » si elle existe ; sinon une colonne au choix (proposées : noms évoquant une altitude — `z_terrain`, `z_fond_ngf`… — hors hauteur, profondeur, pente, durée). Une colonne donne **une seule valeur par ligne ou polygone**, pas une par sommet. Jamais estimée : absente = null |
| Z suspect | Z exactement égal à 0 ou ≤ -9000 : valeurs par défaut de QGIS (« valeur Z par défaut » = 0 ; « Drape » : NoData = 0). Comptés et signalés |
| Enregistrement | dans le stockage local de l'appareil (≤ 3,5 Mo, coordonnées au millimètre) ; relu au lancement |
| Affichage | plan sous le tracé, couleur de l’objet (`couleur_qgis`, `couleur`…) sinon de la couche, étiquettes dès 2 px/m sans chevauchement ; couches affichables une à une ; **Vue : tout / ici (60 m) / ici (20 m)** |

Pas encore là : implantation (étape 5), fond IGN (6), boussole par capteur et météo (7).

## Contenu

| Élément | Rôle | Origine |
|---|---|---|
| `android/…/GnssBridgePlugin.java` | pont JavaScript ↔ liaisons ; permissions ; recherche BLE ; liste USB | refait |
| `android/…/BleTransport`, `BleUartProfiles`, `ChunkQueue` | liaison BLE, choix du port série, file d'écriture bornée | nouveau |
| `android/…/UsbTransport` + `com/hoho/android/usbserial/` | liaison USB | nouveau + bibliothèque tierce (MIT, `licenses/`) |
| `android/…/ClassicTransport`, `NtripClient`, `NmeaSplitter` | Bluetooth Classic, client NTRIP v1, découpe NMEA | extraits de l'ancien plugin |
| `android/…/MainActivity`, `PiqApp`, `CrashReporter`, `CrashActivity` | pont Capacitor, rapport de plantage, écran allumé | repris et adapté |
| `www/geo.js`, `www/raf20.js` | NMEA, Lambert-93, altitude NGF | repris tels quels |
| `www/rtk-core.js` | liaison, NTRIP, époques, levé moyenné — sans interface | extrait de `rtk.js` |
| `www/session.js` | tracés, points, statistiques, cap | nouveau |
| `www/views.js` | dessin du tracé et du profil (canvas) | nouveau |
| `www/export.js` | CSV des points, CSV des tracés, DXF R12 | nouveau |
| `www/plan.js`, `www/plan-ui.js` | lecture des GeoPackage (géométries, Z, projection) et interface d'import | nouveau |
| `www/vendor/sqljs/` | sql.js 1.14.2 (MIT) : SQLite en WebAssembly, chargé à la demande | tiers |
| `www/dxf-skeleton.js` | en-tête, tables et blocs d'un DXF R12 (généré) | nouveau |
| `www/diag.js`, `www/app.js`, `www/index.html` | panneau Canne, écran principal | nouveau |
| `tools/make_icons.py` | logo et icônes Android | nouveau |

Permissions : Internet (NTRIP), Bluetooth, stockage pour les exports. Plus de micro, de
caméra ni de localisation : la position vient uniquement de la canne.

## Vérifications

| Commande | Ce qu'elle contrôle |
|---|---|
| `node tools/test-geo.js` | Lambert-93, RAF20, NMEA (32 assertions) |
| `node tools/test-rtk-core.js` | noyau RTK avec faux plugin et horloge simulée, trois modes de liaison, hauteurs de canne (81) |
| `node tools/test-session.js` | tracés, points, profil, cap, relecture (47) |
| `node tools/test-export.js` | CSV et DXF : colonnes, structure R12 complète, calques, cercles, repère local, altitudes absentes, échappements (53) |
| `python3 tools/make_dxf_kit.py FICHIER.dxf DOSSIER` | jeu de fichiers de test DXF (R12, 2000, 2007, mini) pour trouver ce que votre logiciel accepte |
| `python3 tools/check-dxf.py /tmp/piq-export` | relecture indépendante du DXF (ezdxf) et des CSV (csv), après `test-export.js` |
| `node tools/test-plan.js` | import GeoPackage : géométries, Z, projections, et votre vrai plan s'il est présent (63) |
| `node tools/verify-import.js` | import dans Chromium : couches refusées, Z, affichage, relecture, vrai plan, téléphone et tablette (37) |
| `node tools/verify-screen.js` | écran principal dans Chromium : marche simulée, export, modes de liaison, hauteurs de canne, téléphone et tablette (85) |
| `python3 tools/check-android.py .` | cohérence du projet Android avant Gradle |
| `bash tools/java-test/run.sh` | logique Java sans Android : découpe NMEA, GGA avec position, file BLE et MTU, profils BLE, client NTRIP contre un faux caster, silence du caster (57) |
| `bash tools/java-test/compile-android.sh` | tout le code Java compilé contre le **vrai** `android.jar` (API 34) : signatures Bluetooth, BLE, USB, Intent… vérifiées |

Ces vérifications ne remplacent pas l'essai avec la vraie canne sur chaque appareil.

## Compilation

Voir `PROCEDURE_INSTALLATION.md` : dépôt GitHub, workflow `android.yml`, artefact
`piquetage-debug`.
