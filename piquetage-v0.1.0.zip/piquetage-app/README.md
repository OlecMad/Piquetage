# Piquetage — relevé et implantation RTK

Application Android (Capacitor 8) de relevé et d'implantation, reliée à la canne RTK
(ArduSimple Calibrated Surveyor, ZED-F9P, Bluetooth Classic) et au réseau Centipede.
Calculs en **Lambert-93 (EPSG:2154)**, altitudes **NGF-IGN69** par la grille **RAF20**.

Version **0.1.0 — étapes 0 et 1** : squelette installable et essai de liaison.
Le code RTK est repris de Diagnostic Fluvial 1.6 (validé sur le terrain avec la canne) ;
il est ici séparé de toute interface.

## Contenu

| Élément | Rôle | Origine |
|---|---|---|
| `android/…/GnssBridgePlugin.java` | Bluetooth Classic SPP, client NTRIP v1 | repris tel quel (package renommé) |
| `android/…/MainActivity`, `PiqApp`, `CrashReporter`, `CrashActivity` | pont Capacitor, rapport de plantage | repris (PrintBridge retiré) |
| `www/geo.js`, `www/raf20.js` | NMEA, Lambert-93, altitude NGF | repris tels quels |
| `www/rtk-core.js` | liaison, NTRIP, époques, levé moyenné — **sans interface** | extrait de `rtk.js` |
| `www/index.html`, `www/diag.js` | page d'essai de liaison | nouveau |

Permissions : Internet (NTRIP), Bluetooth, stockage pour les exports. Plus de micro, de
caméra ni de localisation : la position vient uniquement de la canne.

## Vérifications

| Commande | Ce qu'elle contrôle |
|---|---|
| `node tools/test-geo.js` | Lambert-93, RAF20, NMEA (32 assertions) |
| `node tools/test-rtk-core.js` | noyau RTK avec faux plugin et horloge simulée (43) |
| `node tools/verify-diag.js` | page d'essai dans Chromium, téléphone et tablette (29) |
| `python3 tools/check-android.py .` | cohérence du projet Android avant Gradle |
| `tools/java-test/run.sh` | plugin GnssBridge contre un faux caster NTRIP (17) |

Ces vérifications ne remplacent pas l'essai avec la vraie canne sur chaque appareil.

## Compilation

Voir `PROCEDURE_INSTALLATION.md` : dépôt GitHub, workflow `android.yml`, artefact
`piquetage-debug`.
