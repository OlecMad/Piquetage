/* Vérification de la page d'essai de liaison (www/index.html + diag.js) dans un
   vrai navigateur, avec un faux pont Capacitor : exécution
     node tools/verify-diag.js
   Ne remplace pas l'essai avec la vraie canne sur le Fairphone et la tablette. */
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');
const G = require('../www/geo.js');
eval(fs.readFileSync(path.join(__dirname, '../www/raf20.js'), 'utf8').replace('window.RAF20', 'globalThis.RAF20'));
G.loadGeoid(globalThis.RAF20);

const LAT = 47.1833, LON = 1.0940, H_ELL = 100.000, SEP = 47.000;
let fails = 0, n = 0;
function ok(c, label, detail) { n++; console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : '')); if (!c) fails++; }

const root = path.join(__dirname, '../www');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.woff2': 'font/woff2', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  const f = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/^\/$/, '/index.html'));
  if (!f.startsWith(root) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});

const FAKE = () => {
  window.__calls = { connect: [], startNtrip: [], stopNtrip: 0, disconnect: 0 };
  window.__listeners = {};
  window.__emit = (evt, data) => (window.__listeners[evt] || []).forEach((cb) => cb(data));
  window.Capacitor = {
    isNativePlatform: () => true, getPlatform: () => 'android',
    isPluginAvailable: (nm) => nm === 'GnssBridge',
    Plugins: { GnssBridge: {
      addListener: (evt, cb) => { (window.__listeners[evt] = window.__listeners[evt] || []).push(cb); return Promise.resolve({ remove: () => Promise.resolve() }); },
      listDevices: () => Promise.resolve({ devices: [
        { name: 'Galaxy Buds', address: 'AA:AA:AA:AA:AA:AA', type: 1 },
        { name: 'RTK_GNSS_4F2A', address: '00:11:22:33:44:55', type: 1 },
        { name: 'Balise <b>BLE</b>', address: 'BB:BB:BB:BB:BB:BB', type: 2 } ] }),
      connect: (o) => { window.__calls.connect.push(o); return Promise.resolve({ address: o.address }); },
      disconnect: () => { window.__calls.disconnect++; return Promise.resolve(); },
      startNtrip: (o) => { window.__calls.startNtrip.push(o); return Promise.resolve(); },
      stopNtrip: () => { window.__calls.stopNtrip++; return Promise.resolve(); },
    } }
  };
  window.__nmea = function (lat, lon, hEll, sep, q) {
    function cs(b) { let c = 0; for (const ch of b) c ^= ch.charCodeAt(0); return '$' + b + '*' + c.toString(16).toUpperCase().padStart(2, '0'); }
    function dm(v, w) { const d = Math.floor(Math.abs(v)); const m = (Math.abs(v) - d) * 60; return String(d).padStart(w, '0') + m.toFixed(7).padStart(10, '0'); }
    const time = new Date().toISOString().substr(11, 8).replace(/:/g, '') + '.00';
    window.__emit('nmea', { line: cs('GNGGA,' + time + ',' + dm(lat, 2) + ',N,' + dm(lon, 3) + ',E,' + q + ',20,0.50,' + (hEll - sep).toFixed(4) + ',M,' + sep.toFixed(4) + ',M,1.0,0412') });
    window.__emit('nmea', { line: cs('GNGST,' + time + ',0.012,0.010,0.008,45.0,0.009,0.008,0.015') });
  };
};

(async () => {
  await new Promise((r) => server.listen(0, r));
  const BASE = 'http://localhost:' + server.address().port;
  const errors = [];

  // Un navigateur par scénario : avec --single-process (conteneur), un second contexte échoue.
  async function run(viewport, label, withPlugin) {
    const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--single-process'] });
    const ctx = await browser.newContext({ viewport, deviceScaleFactor: 2, locale: 'fr-FR' });
    const page = await ctx.newPage();
    page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    if (withPlugin) await page.addInitScript(FAKE);
    await page.goto(BASE + '/index.html', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(400);
    return { browser, ctx, page, label };
  }
  const text = (page, sel) => page.locator(sel).innerText();

  console.log('\n── Fairphone (360 × 780) avec plugin ──');
  const { browser: b1, page } = await run({ width: 360, height: 780 }, 'phone', true);
  ok((await text(page, '#fix')) === 'Non reliée', 'état initial « Non reliée »');
  ok(await page.locator('#dev').inputValue() === '00:11:22:33:44:55', 'récepteur RTK_GNSS_* présélectionné');
  ok((await page.locator('#dev option').allTextContents()).some((t) => t.includes('BLE, non compatible')), 'appareil BLE signalé non compatible');
  ok(await page.locator('#dev b').count() === 0, 'nom d’appareil malveillant affiché comme texte, jamais comme HTML');
  ok((await text(page, '#hnote')).includes('Altitude au sol non calculée'), 'hauteurs non saisies : avertissement, pas de valeur par défaut');
  ok(await page.locator('#capture').isDisabled(), '« Lever un point » inactif tant que la canne n’est pas reliée');
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'aucun débordement horizontal sur 360 px');

  await page.locator('#connect').click();
  await page.waitForTimeout(300);
  const calls = await page.evaluate(() => window.__calls);
  ok(calls.connect.length === 1 && calls.connect[0].address === '00:11:22:33:44:55', 'connexion demandée à la bonne adresse');
  const nt = calls.startNtrip[0] || {};
  ok(nt.host === 'crtk.net' && nt.port === 2101 && nt.mountpoint === 'NEAR', 'NTRIP Centipede lancé', JSON.stringify(nt));
  ok((await text(page, '#connect')) === 'Déconnecter', 'bouton « Déconnecter »');

  await page.evaluate(([a, b, c, d]) => window.__nmea(a, b, c, d, 4), [LAT, LON, H_ELL, SEP]);
  await page.waitForTimeout(150);
  const exp = G.toLambert93(LAT, LON), N = G.geoidN(LAT, LON);
  ok((await text(page, '#fix')) === 'RTK FIX', 'RTK FIX affiché');
  ok((await text(page, '#sats')) === '20' && (await text(page, '#hdop')) === '0.50', '20 satellites, HDOP 0,50');
  ok((await text(page, '#sdh')) === '1,2 cm' && (await text(page, '#sdv')) === '1,5 cm', 'σ issus de la GST');
  ok((await text(page, '#coords')).includes('X ' + exp.x.toFixed(2)) && (await text(page, '#coords')).includes('Y ' + exp.y.toFixed(2)), 'X, Y Lambert-93 en direct', exp.x.toFixed(2) + ' ; ' + exp.y.toFixed(2));
  ok((await text(page, '#coords')).includes('H antenne ' + (H_ELL - N).toFixed(3)), 'sans hauteurs : « H antenne » (NGF-IGN69)', (H_ELL - N).toFixed(3));

  await page.fill('#pole', '2,000');
  await page.fill('#apc', '0,0615');
  await page.waitForTimeout(100);
  ok((await text(page, '#coords')).includes('H sol ' + (H_ELL - N - 2 - 0.0615).toFixed(3)), 'H sol = h − N − canne − centre de phase', (H_ELL - N - 2 - 0.0615).toFixed(3));
  ok((await text(page, '#hnote')).includes('RAF20'), 'formule affichée une fois les hauteurs saisies');

  await page.selectOption('#avg', '1');
  ok(await page.locator('#capture').isEnabled(), '« Lever un point » actif une fois reliée');
  await page.locator('#capture').click();
  await page.waitForTimeout(1000);   // intervalle de 250 ms + attente de la GST (350 ms)
  const res = await text(page, '#result');
  ok(res.includes('RTK FIX') && res.includes(exp.x.toFixed(3)) && res.includes('H sol'), 'point levé affiché', res.replace(/\n/g, ' | '));

  await page.evaluate(([a, b, c, d]) => window.__nmea(a, b, c, d, 5), [LAT, LON, H_ELL, SEP]);
  await page.waitForTimeout(150);
  ok((await text(page, '#fix')) === 'RTK FLOAT', 'RTK FLOAT affiché');
  await page.locator('#capture').click();
  await page.waitForTimeout(300);
  ok((await text(page, '#result')).includes('RTK FIX exigé'), 'point refusé en FLOAT (FIX exigé)');

  await page.evaluate(() => window.__emit('bluetooth', { state: 'disconnected', message: 'perdu' }));
  await page.waitForTimeout(150);
  ok((await text(page, '#fix')) === 'Reconnexion…', 'liaison perdue : « Reconnexion… »');
  ok((await text(page, '#log')).includes('reconnexion automatique'), 'message dans le journal');

  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(300);
  ok(await page.inputValue('#pole') === '2.000' && await page.inputValue('#apc') === '0.0615', 'hauteurs relues après redémarrage');
  await b1.close();

  console.log('\n── Tablette (800 × 1280) avec plugin ──');
  const t = await run({ width: 800, height: 1280 }, 'tablet', true);
  ok(await t.page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'aucun débordement horizontal sur 800 px');
  ok(await t.page.evaluate(() => getComputedStyle(document.querySelector('main')).gridTemplateColumns.split(' ').length === 2), 'deux colonnes sur tablette');
  await t.browser.close();

  console.log('\n── Navigateur sans plugin ──');
  const b = await run({ width: 360, height: 780 }, 'web', false);
  ok(await b.page.locator('#noplugin').isVisible(), 'avertissement « lecture seule »');
  ok(await b.page.locator('#connect').isDisabled(), 'connexion désactivée');
  await b.browser.close();

  ok(errors.length === 0, 'aucune erreur JavaScript', errors.join(' || '));
  server.close();
  console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
