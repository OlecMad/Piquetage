#!/usr/bin/env python3
"""Contrôle préalable du projet Android — sans SDK, sans réseau, bibliothèque standard seule.

Détecte avant Gradle les causes d'échec déjà rencontrées ou prévisibles :
  · version de Java incompatible avec Capacitor (source 21 exigée depuis Capacitor 7) ;
  · package.json et package-lock.json désynchronisés (échec de « npm ci ») ;
  · identifiants, versions et fichiers clés incohérents ;
  · ressources Android invalides (XML mal formé, référence absente, nom illégal, PNG corrompu) ;
  · wrapper Gradle altéré (fins de ligne CRLF, jar absent) ;
  · clé de signature de débogage absente (mises à jour impossibles par-dessus l'APK installé) ;
  · workflow : versions d'actions, procédure désynchronisée.

Usage : python3 tools/check-android.py [dossier_du_projet]
Code retour 0 si aucune erreur (les avertissements ne bloquent pas).
"""
import json
import os
import re
import sys
import zipfile
import xml.etree.ElementTree as ET

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..'))
ERR, WARN, OK = [], [], []


def p(*parts):
    return os.path.join(ROOT, *parts)


def read(*parts):
    with open(p(*parts), encoding='utf-8') as fh:
        return fh.read()


def exists(*parts):
    return os.path.exists(p(*parts))


def err(msg):
    ERR.append(msg)


def warn(msg):
    WARN.append(msg)


def ok(msg):
    OK.append(msg)


# ------------------------------------------------------------------ 1. fichiers clés
REQUIRED = [
    'package.json', 'package-lock.json', 'capacitor.config.json', 'www/index.html',
    'android/gradlew', 'android/gradle/wrapper/gradle-wrapper.jar',
    'android/gradle/wrapper/gradle-wrapper.properties', 'android/settings.gradle',
    'android/build.gradle', 'android/variables.gradle', 'android/app/build.gradle',
    'android/app/src/main/AndroidManifest.xml',
    'android/app/src/main/java/fr/lileauvert/piquetage/MainActivity.java',
    'android/app/src/main/java/fr/lileauvert/piquetage/GnssBridgePlugin.java',
    'android/app/src/main/java/fr/lileauvert/piquetage/PiqApp.java',
    'android/app/src/main/java/fr/lileauvert/piquetage/CrashReporter.java',
    'android/app/src/main/java/fr/lileauvert/piquetage/CrashActivity.java',
    'www/geo.js', 'www/raf20.js', 'www/rtk-core.js', 'www/diag.js',
]
missing = [f for f in REQUIRED if not exists(f)]
for f in missing:
    err(f'Fichier manquant : {f}')
if missing:
    print('\n'.join('✗ ' + e for e in ERR))
    sys.exit(1)
ok(f'{len(REQUIRED)} fichiers clés présents')

pkg = json.loads(read('package.json'))
lock = json.loads(read('package-lock.json'))
cap = json.loads(read('capacitor.config.json'))
app_gradle = read('android', 'app', 'build.gradle')
WF = os.path.join('.github', 'workflows', 'android.yml')
if exists(WF):
    workflow = read(WF)
else:
    workflow = ''
    warn('Pas de .github/workflows/android.yml dans le dossier du projet : contrôles du workflow ignorés '
         '(normal si le workflow a été créé à la main à la racine du dépôt).')

# ------------------------------------------------------------------ 2. npm ci
root_lock = lock.get('packages', {}).get('', {})
if lock.get('lockfileVersion', 0) < 2:
    err('package-lock.json : lockfileVersion < 2 (npm ci de Node 22 le refusera)')
if root_lock.get('dependencies', {}) != pkg.get('dependencies', {}):
    err('package.json et package-lock.json désynchronisés : « npm ci » échouera. '
        'Relancer « npm install » puis renvoyer les deux fichiers.')
else:
    ok('package.json ↔ package-lock.json synchronisés (npm ci)')
for name in pkg.get('dependencies', {}):
    if f'node_modules/{name}' not in lock.get('packages', {}):
        err(f'package-lock.json ne résout pas {name}')

# ------------------------------------------------------------------ 3. identifiants et versions
app_id = re.search(r'applicationId\s+"([^"]+)"', app_gradle)
ns = re.search(r'namespace\s*=\s*"([^"]+)"', app_gradle)
vcode = re.search(r'versionCode\s+(\d+)', app_gradle)
vname = re.search(r'versionName\s+"([^"]+)"', app_gradle)
if not (app_id and ns and vcode and vname):
    err('android/app/build.gradle : applicationId, namespace, versionCode ou versionName introuvable')
else:
    if app_id.group(1) != cap.get('appId'):
        err(f'appId capacitor.config.json ({cap.get("appId")}) ≠ applicationId Gradle ({app_id.group(1)})')
    if ns.group(1) != app_id.group(1):
        warn(f'namespace ({ns.group(1)}) ≠ applicationId ({app_id.group(1)})')
    if vname.group(1) != pkg.get('version'):
        err(f'versionName Gradle ({vname.group(1)}) ≠ version package.json ({pkg.get("version")})')
    else:
        ok(f'identifiant {app_id.group(1)} · version {vname.group(1)} (code {vcode.group(1)})')
web_dir = cap.get('webDir', 'www')
if not exists(web_dir, 'index.html'):
    err(f'webDir « {web_dir} » sans index.html')
if exists('www', 'sw.js') and f'v{pkg.get("version")}' not in read('www', 'sw.js'):
    err(f'www/sw.js : VERSION ne correspond pas à {pkg.get("version")} (cache de l\'ancienne version servi)')

# ------------------------------------------------------------------ 4. Java
java_wf = re.search(r"java-version:\s*'?(\d+)'?", workflow)
if not workflow:
    java_wf = None
need = 21
cap_major = int(re.sub(r'[^0-9.]', '', pkg['dependencies'].get('@capacitor/android', '0')).split('.')[0] or 0)
if cap_major < 7:
    need = 17
nm = p('node_modules')
if os.path.isdir(nm):
    found = set()
    for dirpath, _, files in os.walk(nm):
        if 'build.gradle' in files and (dirpath.endswith(os.sep + 'android') or dirpath.endswith(os.sep + 'capacitor')):
            f = os.path.join(dirpath, 'build.gradle')
            for m in re.finditer(r'JavaVersion\.VERSION_(\d+)', open(f, encoding='utf-8', errors='ignore').read()):
                found.add(int(m.group(1)))
    if found:
        need = max(found)
if not workflow:
    pass
elif not java_wf:
    err('Workflow : java-version introuvable')
elif int(java_wf.group(1)) < need:
    err(f'Workflow : Java {java_wf.group(1)} alors que les modules Capacitor sont compilés en Java {need} '
        f'→ « invalid source release: {need} ». Mettre java-version: \'{need}\'.')
else:
    ok(f'Java {java_wf.group(1)} ≥ Java {need} exigé par Capacitor')

# ------------------------------------------------------------------ 5. Gradle / AGP
agp = re.search(r"com\.android\.tools\.build:gradle:(\d+)\.(\d+)", read('android', 'build.gradle'))
wrap = re.search(r'gradle-(\d+)\.(\d+)(?:\.(\d+))?-(?:all|bin)\.zip', read('android', 'gradle', 'wrapper', 'gradle-wrapper.properties'))
if agp and wrap:
    # AGP 8.x exige Gradle ≥ 8.x (même mineure) — table officielle AGP/Gradle
    if (int(wrap.group(1)), int(wrap.group(2))) < (int(agp.group(1)), int(agp.group(2))):
        err(f'Gradle {wrap.group(1)}.{wrap.group(2)} trop ancien pour AGP {agp.group(1)}.{agp.group(2)}')
    else:
        ok(f'AGP {agp.group(1)}.{agp.group(2)} · Gradle {wrap.group(1)}.{wrap.group(2)}{"." + wrap.group(3) if wrap.group(3) else ""}')
with open(p('android', 'gradlew'), 'rb') as fh:
    gw = fh.read()
if b'\r\n' in gw:
    err('android/gradlew contient des fins de ligne Windows (CRLF) → « /usr/bin/env: sh\\r » sur Linux')
elif not gw.startswith(b'#!'):
    err('android/gradlew n\'est pas un script shell')
else:
    ok('gradlew : script shell, fins de ligne LF')
if not zipfile.is_zipfile(p('android', 'gradle', 'wrapper', 'gradle-wrapper.jar')):
    err('gradle-wrapper.jar corrompu')

# ------------------------------------------------------------------ 6. signature stable
if 'signingConfigs' not in app_gradle or 'debug.keystore' not in app_gradle:
    err('Aucune clé de débogage versionnée : chaque compilation GitHub signerait avec une clé '
        'différente et Android refuserait d\'installer la mise à jour par-dessus l\'APK existant.')
elif not exists('android', 'app', 'debug.keystore'):
    err('android/app/debug.keystore référencé mais absent')
else:
    ok('Clé de débogage stable : mises à jour installables par-dessus la version précédente')

# ------------------------------------------------------------------ 7. MainActivity / plugin
JAVA = ('android', 'app', 'src', 'main', 'java', 'fr', 'lileauvert', 'piquetage')
ma = read(*JAVA, 'MainActivity.java')
code = re.sub(r'//[^\n]*|/\*.*?\*/', '', ma, flags=re.S)
i_sup = code.find('super.onCreate(')
bad = [c for c in ('GnssBridgePlugin',)
       if code.find(f'registerPlugin({c}.class)') < 0 or i_sup < 0 or code.find(f'registerPlugin({c}.class)') > i_sup]
if bad:
    err('MainActivity : registerPlugin(' + ', '.join(b + '.class' for b in bad) + ') doit précéder super.onCreate()')
else:
    ok('MainActivity : plugin local GNSS enregistré avant super.onCreate()')
if 'PrintBridge' in ma:
    err('MainActivity : PrintBridge n\'existe plus dans Piquetage')
plug = read(*JAVA, 'GnssBridgePlugin.java')
pname = re.search(r'@CapacitorPlugin\(\s*name\s*=\s*"([^"]+)"', plug)
if not pname or f'Plugins.{pname.group(1)}' not in read('www', 'diag.js'):
    err('Nom du plugin natif différent de celui appelé par www/diag.js')
else:
    ok(f'Plugin natif « {pname.group(1)} » appelé par www/diag.js sous le même nom')
if not re.search(r'^package fr\.lileauvert\.piquetage;', plug, re.M):
    err('GnssBridgePlugin.java : package différent de fr.lileauvert.piquetage')
for f in sorted(os.listdir(p(*JAVA))):
    if f.endswith('.java') and not re.search(r'^package fr\.lileauvert\.piquetage;', read(*JAVA, f), re.M):
        err(f'{f} : package différent de fr.lileauvert.piquetage')

# ------------------------------------------------------------------ 7 bis. rapport de plantage
man = read('android', 'app', 'src', 'main', 'AndroidManifest.xml')
if 'android:name=".PiqApp"' not in man:
    err('AndroidManifest.xml : <application android:name=".PiqApp"> absent → plantages non consignés')
elif not re.search(r'android:name="\.CrashActivity"[^>]*android:process=":rapport"', man, re.S):
    err('AndroidManifest.xml : CrashActivity absente ou hors du processus « :rapport »')
elif 'addWebViewListener' not in code:
    err('MainActivity : arrêt de la WebView non intercepté (onRenderProcessGone)')
else:
    ok('Rapport de plantage : PiqApp, CrashActivity (processus :rapport), arrêt WebView intercepté')

# ------------------------------------------------------------------ 7 ter. ressources web
idx = read('www', 'index.html')
refs = re.findall(r'<(?:script[^>]*\ssrc|link[^>]*\shref)="([^"#?]+)"', idx)
local = [r for r in refs if not re.match(r'^[a-z]+:', r) and not r.startswith('//')]
absent = [r for r in local if not exists('www/' + r)]
if absent:
    err('www/index.html référence des fichiers absents : ' + ', '.join(absent))
else:
    ok(f'{len(local)} ressources locales référencées par index.html, toutes présentes')
fonts = re.findall(r'url\(([^)]+\.woff2)\)', idx)
miss_f = [f for f in fonts if not exists('www/' + f)]
if miss_f:
    err('Polices absentes : ' + ', '.join(miss_f))
elif fonts:
    ok(f'{len(fonts)} polices locales présentes')
for forbidden in ('RECORD_AUDIO', 'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'android.permission.CAMERA'):
    if forbidden in read('android', 'app', 'src', 'main', 'AndroidManifest.xml'):
        err(f'AndroidManifest.xml : permission {forbidden} inutile dans Piquetage (la position vient de la canne)')
# ------------------------------------------------------------------ 8. ressources Android
res = p('android', 'app', 'src', 'main', 'res')
defined = {}
bad_names = []
n_png = 0
for d in sorted(os.listdir(res)):
    base = d.split('-')[0]
    for f in sorted(os.listdir(os.path.join(res, d))):
        fp = os.path.join(res, d, f)
        if not re.match(r'^[a-z0-9_]+(\.9)?\.(xml|png|webp|jpg)$', f):
            bad_names.append(f'{d}/{f}')
        name = f.split('.')[0]
        if base in ('drawable', 'mipmap', 'xml', 'layout'):
            defined.setdefault(base, set()).add(name)
        if f.endswith('.xml'):
            try:
                tree = ET.parse(fp)
            except ET.ParseError as e:
                err(f'XML mal formé : res/{d}/{f} ({e})')
                continue
            if base == 'values':
                for el in tree.getroot():
                    typ = el.tag if el.tag != 'item' else el.get('type')
                    defined.setdefault(typ, set()).add(el.get('name'))
        elif f.endswith('.png'):
            n_png += 1
            with open(fp, 'rb') as fh:
                if fh.read(8) != b'\x89PNG\r\n\x1a\n':
                    err(f'PNG invalide (extension .png mais autre format) : res/{d}/{f}')
for b in bad_names:
    err(f'Nom de ressource illégal (a-z, 0-9, _ seulement) : res/{b}')
# couleurs fournies par la bibliothèque capacitor-android (colors.xml) — gabarit officiel
lib_colors = {'colorPrimary', 'colorPrimaryDark', 'colorAccent'}
lib_col_file = p('node_modules', '@capacitor', 'android', 'capacitor', 'src', 'main', 'res', 'values', 'colors.xml')
if os.path.exists(lib_col_file):
    lib_colors = {el.get('name') for el in ET.parse(lib_col_file).getroot()}
defined.setdefault('color', set()).update(lib_colors)
try:
    ET.parse(p('android', 'app', 'src', 'main', 'AndroidManifest.xml'))
except ET.ParseError as e:
    err(f'AndroidManifest.xml mal formé ({e})')
n_ref = 0
scan = [os.path.join(dp, f) for dp, _, fs in os.walk(res) for f in fs if f.endswith('.xml')]
scan.append(p('android', 'app', 'src', 'main', 'AndroidManifest.xml'))
for fp in scan:
    txt = open(fp, encoding='utf-8').read()
    for m in re.finditer(r'@(string|color|style|drawable|mipmap|xml|layout|dimen)/([A-Za-z0-9_.]+)', txt):
        n_ref += 1
        if m.group(2) not in defined.get(m.group(1), set()):
            err(f'Référence @{m.group(1)}/{m.group(2)} introuvable ({os.path.relpath(fp, ROOT)})')
ok(f'Ressources : XML bien formés, {n_ref} références résolues, {n_png} PNG valides')

# ------------------------------------------------------------------ 9. workflow
NODE24 = {
    'actions/checkout': 5, 'actions/setup-node': 5, 'actions/setup-java': 5,
    'android-actions/setup-android': 4, 'actions/cache': 5, 'actions/upload-artifact': 6,
    'softprops/action-gh-release': 3,
}
for action, major in re.findall(r'uses:\s*([\w.-]+/[\w.-]+)@v(\d+)', workflow):
    need_major = NODE24.get(action)
    if need_major and int(major) < need_major:
        warn(f'{action}@v{major} tourne sous Node 20 (obsolète) → passer en v{need_major}')
if workflow and re.search(r'cancel-in-progress:\s*true', workflow):
    err('Workflow : cancel-in-progress: true → tout nouvel envoi interrompt la compilation en cours '
        '(« The operation was canceled »). Mettre cancel-in-progress: false.')
tmo = re.search(r'timeout-minutes:\s*(\d+)', workflow)
if workflow and tmo and int(tmo.group(1)) < 45:
    warn(f'Workflow : timeout-minutes {tmo.group(1)} ; une première compilation peut dépasser 30 min sur un serveur chargé')
if workflow and "packages:" not in workflow:
    err('Workflow : setup-android sans « packages » → « Failed to find package \'tools\' »')
proc = read('PROCEDURE_INSTALLATION.md') if exists('PROCEDURE_INSTALLATION.md') else ''
m = re.search(r'^```yaml\n(.*?)^```$', proc, re.S | re.M)
if m and workflow and m.group(1).strip() != workflow.strip():
    err('PROCEDURE_INSTALLATION.md : le workflow recopié diffère de .github/workflows/android.yml')
elif m and workflow:
    ok('Workflow recopié dans la procédure : identique')

# ------------------------------------------------------------------ 10. taille
for dp, dns, fs in os.walk(ROOT):
    dns[:] = [d for d in dns if d not in ('node_modules', '.git', 'build', '.gradle', 'out')]
    for f in fs:
        fp = os.path.join(dp, f)
        if os.path.getsize(fp) > 25 * 1024 * 1024:
            err(f'Fichier > 25 Mo, refusé par le téléversement web GitHub : {os.path.relpath(fp, ROOT)}')

# ------------------------------------------------------------------ bilan
for o in OK:
    print('  ✓ ' + o)
for w in WARN:
    print('  ! ' + w)
for e in ERR:
    print('  ✗ ' + e)
    if os.environ.get('GITHUB_ACTIONS'):
        print(f'::error title=Contrôle préalable::{e}')
print(f'\n{"✗" if ERR else "✅"} Contrôle préalable : {len(ERR)} erreur(s), {len(WARN)} avertissement(s), {len(OK)} point(s) validé(s).')
sys.exit(1 if ERR else 0)
