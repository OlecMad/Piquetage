/* Vérification de l'import de plan (www/plan-ui.js) dans Chromium : exécution
     node tools/test-plan.js && node tools/verify-import.js
   Le serveur sert le .wasm avec un MIME « application/octet-stream » (cas défavorable) : sql.js doit
   retomber sur le chargement par tampon. Votre vrai plan est utilisé s'il est présent.
   Ne remplace pas l'essai sur le Fairphone et la tablette (WebView d'/e/OS). */
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');

let fails = 0, n = 0;
function ok(c, label, detail) { n++; console.log((c ? '  ✓ ' : '  ✗ ') + label + (detail !== undefined ? '  → ' + detail : '')); if (!c) fails++; }

const root = path.join(__dirname, '../www');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.woff2': 'font/woff2', '.png': 'image/png' };   // .wasm : volontairement absent
const server = http.createServer((req, res) => {
  const f = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/^\/$/, '/index.html'));
  if (!f.startsWith(root) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});

const SYN = '/tmp/piq-fixtures/synthetique.gpkg';
const REAL = process.env.PIQ_GPKG || '/mnt/user-data/uploads/Plan_plantation_L_Gaudron_v5.gpkg';

(async () => {
  if (!fs.existsSync(SYN)) { console.error('Lancer d’abord : node tools/test-plan.js'); process.exit(2); }
  await new Promise((r) => server.listen(0, r));
  const BASE = 'http://localhost:' + server.address().port;
  const errors = [];
  async function open(viewport) {
    const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--single-process'] });
    const ctx = await browser.newContext({ viewport, deviceScaleFactor: 2, locale: 'fr-FR', timezoneId: 'Europe/Paris', acceptDownloads: true });
    const page = await ctx.newPage();
    page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message));
    page.on('console', (m) => { if (m.type() === 'error' && !/wasm streaming|MIME type|Failed to load resource|falling back to ArrayBuffer/i.test(m.text())) errors.push(m.text()); });
    await page.goto(BASE + '/index.html', { waitUntil: 'domcontentloaded' });
    await page.evaluate(() => { try { localStorage.clear(); } catch (e) {} });
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(400);
    return { browser, page };
  }
  const text = (page, sel) => page.locator(sel).innerText();
  const ink = (page, sel) => page.evaluate((s) => { const c = document.querySelector(s), x = c.getContext('2d'); const d = x.getImageData(0, 0, c.width, c.height).data; let k = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > 40) k++; return k; }, sel);
  const overflow = (page) => page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);

  console.log('\n── Plan synthétique (Fairphone 360 × 780) ──');
  let { browser, page } = await open({ width: 360, height: 780 });
  await page.locator('#b-proj').click();
  ok((await text(page, '#plan-status')) === 'Aucun plan importé.' && await page.locator('#plan-remove').isDisabled(), 'sans plan : message et bouton « Retirer » inactif');
  const inkBefore = await ink(page, '#cv-track');
  await page.setInputFiles('#plan-file', SYN);
  await page.locator('#sheet-import').waitFor({ state: 'visible', timeout: 15000 });
  ok(await page.locator('#sheet-import').isVisible(), 'le panneau d’import s’ouvre (SQLite chargé malgré un MIME .wasm incorrect)');
  ok((await text(page, '#imp-file')).includes('synthetique.gpkg') && (await text(page, '#imp-file')).includes('8 couches') && (await text(page, '#imp-file')).includes('5 importables'), 'fichier, 8 couches dont 5 importables', await text(page, '#imp-file'));
  ok(await page.locator('.lay-r').count() === 3, 'trois couches refusées (WGS 84, Mercator, inconnue) avec leur message');
  ok((await page.locator('.lay-r').first().innerText()).includes('EPSG:2154') && (await page.locator('.lay-r').first().innerText()).includes('QGIS'), 'le message explique comment reprojeter dans QGIS');
  ok(await page.locator('#imp-layers input[type=checkbox]:disabled').count() === 3, 'couches refusées : case grisée, non cochable');
  ok(await page.locator('#imp-go').isDisabled() && (await text(page, '#imp-go')).includes('Cocher au moins une couche'), 'rien n’est coché par défaut : import impossible');
  ok(!(await overflow(page)), 'aucun débordement horizontal du panneau d’import');
  const zsel = page.locator('select[aria-label="Altitude Z de arbres_z (titre)"]');
  ok((await zsel.inputValue()) === '__geom', 'couche avec Z dans la géométrie : « Z de la géométrie » proposé par défaut');
  ok((await page.locator('select[aria-label="Altitude Z de arbres_2d (titre)"]').inputValue()) === 'z_terrain', 'couche 2D : colonne z_terrain proposée par défaut');
  await page.locator('#imp-all').click();
  ok((await text(page, '#imp-go')) === 'Importer 5 couches', 'tout cocher : 5 couches importables', await text(page, '#imp-go'));
  ok((await text(page, '#imp-warn')).includes('0 ou à -9999'), 'avertissement sur les Z égaux à 0 ou -9999');
  await page.locator('#imp-go').click(); await page.waitForTimeout(500);
  ok(await page.locator('#sheet-import').isHidden() && await page.locator('#sheet-proj').isVisible(), 'import terminé : retour au panneau Projet');
  const st = await text(page, '#plan-status');
  ok(st.includes('synthetique.gpkg') && st.includes('5 couches') && st.includes('à 0') && st.includes('à -9999') && st.includes('absent'), 'résumé : couches, objets et qualité du Z', st);
  ok(await page.locator('#plan-layers .lay').count() === 5, 'liste des 5 couches importées');
  ok((await text(page, '#m-msg')).includes('Z suspect'), 'message de fin : Z suspects signalés', await text(page, '#m-msg'));
  await page.locator('#close-proj').click(); await page.waitForTimeout(250);
  const inkAfter = await ink(page, '#cv-track');
  ok(inkAfter > inkBefore + 500, 'le plan est dessiné sous le tracé', inkBefore + ' → ' + inkAfter);

  const fitBefore = await text(page, '#b-fit');
  await page.locator('#b-fit').click(); await page.waitForTimeout(250);
  ok(fitBefore === 'Vue : tout' && (await text(page, '#b-fit')) === 'Vue : ici (60 m)', 'cadrage « tout » puis « ici (60 m) »');
  await page.locator('#b-fit').click(); await page.waitForTimeout(250);
  ok((await text(page, '#b-fit')) === 'Vue : ici (20 m)', 'troisième cran « ici (20 m) »');
  await page.locator('#b-fit').click(); await page.waitForTimeout(250);
  ok((await text(page, '#b-fit')) === 'Vue : tout', 'retour à « tout »');

  await page.locator('#b-proj').click();
  await page.locator('#plan-layers .lay input[type=checkbox]').first().uncheck(); await page.waitForTimeout(100);
  await page.locator('#close-proj').click(); await page.waitForTimeout(250);
  const inkOff = await ink(page, '#cv-track');
  ok(inkOff < inkAfter, 'décocher une couche la retire du dessin', inkAfter + ' → ' + inkOff);
  await page.locator('#b-proj').click(); await page.locator('#plan-show').uncheck(); await page.locator('#close-proj').click(); await page.waitForTimeout(250);
  ok((await ink(page, '#cv-track')) < inkOff, '« Afficher le plan » décoché : plan masqué');

  await page.reload({ waitUntil: 'domcontentloaded' }); await page.waitForTimeout(400);
  await page.locator('#b-proj').click();
  ok((await text(page, '#plan-status')).includes('synthetique.gpkg') && await page.locator('#plan-layers .lay').count() === 5 && !(await page.locator('#plan-show').isChecked()), 'plan, couches et réglage d’affichage relus au redémarrage');

  await page.setInputFiles('#plan-file', { name: 'notes.txt', mimeType: 'text/plain', buffer: Buffer.from('ceci n’est pas un GeoPackage') });
  await page.waitForTimeout(1200);
  ok(await page.locator('#sheet-import').isHidden() && /SQLite|illisible/.test(await text(page, '#m-msg')), 'fichier non GeoPackage : message clair, aucun panneau', await text(page, '#m-msg'));

  await page.locator('#plan-remove').click();
  ok((await text(page, '#plan-remove')).startsWith('Confirmer') && (await text(page, '#plan-status')).includes('synthetique'), 'retrait armé : rien d’effacé au premier appui');
  await page.locator('#plan-remove').click(); await page.waitForTimeout(200);
  ok((await text(page, '#plan-status')) === 'Aucun plan importé.' && await page.locator('#plan-layers .lay').count() === 0, 'second appui : plan retiré');
  await browser.close();

  if (fs.existsSync(REAL)) {
    console.log('\n── Votre vrai plan (' + path.basename(REAL) + ') ──');
    for (const [label, vp, shot] of [['Fairphone 380 × 800', { width: 380, height: 800 }, '/tmp/import-phone.png'], ['tablette 1280 × 800', { width: 1280, height: 800 }, '/tmp/import-tablet.png']]) {
      ({ browser, page } = await open(vp));
      await page.locator('#b-proj').click();
      await page.setInputFiles('#plan-file', REAL);
      await page.locator('#sheet-import').waitFor({ state: 'visible', timeout: 20000 });
      ok((await text(page, '#imp-file')).includes('20 couches') && (await text(page, '#imp-file')).includes('20 importables'), label + ' : 20 couches, toutes importables', await text(page, '#imp-file'));
      ok(!(await overflow(page)), label + ' : aucun débordement horizontal');
      if (shot.includes('phone')) await page.screenshot({ path: '/tmp/import-sheet-phone.png' });
      const pick = async (title) => { await page.locator(`input[aria-label="Importer ${title}"]`).check(); };
      await pick('plants_A_270'); await pick('baissieres_axes'); await pick('baissieres_emprise_cotee'); await pick('mare_tampon_variante_A');
      ok((await page.locator('select[aria-label="Altitude Z de plants_A_270"]').inputValue()) === 'z_terrain', label + ' : z_terrain proposée pour les plants');
      ok((await page.locator('select[aria-label="Altitude Z de baissieres_axes"]').inputValue()) === 'z_fond_ngf', label + ' : z_fond_ngf proposée pour les baissières');
      await page.locator('#imp-go').click(); await page.waitForTimeout(800);
      const s = await text(page, '#plan-status');
      ok(s.includes('4 couches') && s.includes('275 objets') && s.includes('274 valides') && s.includes('1 absent'), label + ' : 4 couches, 275 objets, Z : 274 valides (270 plants + 2 axes + 2 emprises) et 1 absent (la mare)', s);
      await page.locator('#close-proj').click(); await page.waitForTimeout(400);
      ok((await ink(page, '#cv-track')) > 1500, label + ' : plan dessiné (plants, baissières, mare)');
      await page.screenshot({ path: shot });
      await browser.close();
    }
  } else console.log('\n(votre plan n’est pas présent : essai sur le vrai fichier ignoré)');

  ok(errors.length === 0, 'aucune erreur JavaScript', errors.join(' || '));
  server.close();
  console.log('\n' + (fails ? '✗ ' + fails + ' échec(s) sur ' + n : '✓ ' + n + ' vérifications réussies'));
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
