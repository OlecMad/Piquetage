package fr.lileauvert.piquetage;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.content.Context;
import android.os.Build;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Liaison Bluetooth LE (GATT) vers un module « port série » : notifications pour les trames du récepteur,
 * écritures découpées à la taille du MTU pour les corrections RTCM. Le port série est choisi par
 * {@link BleUartProfiles} parmi les services découverts.
 */
@SuppressLint("MissingPermission")
final class BleTransport implements Transport {

    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final int WANTED_MTU = 247;

    private final Context ctx;
    private final BluetoothDevice dev;
    private final LinkListener listener;
    private final String name;

    private final ChunkQueue queue = new ChunkQueue(20, 16 * 1024);
    private final CountDownLatch ready = new CountDownLatch(1);
    private final Semaphore writeDone = new Semaphore(0);

    private volatile BluetoothGatt gatt;
    private volatile BluetoothGattCharacteristic rx, tx;
    private volatile BleUartProfiles.Pick pick;
    private volatile boolean closed = false;
    private volatile boolean isReady = false;
    private volatile boolean discoveryStarted = false;
    private volatile String failure = null;
    private volatile int mtu = 23;
    private volatile long writtenBytes = 0;
    private volatile long failedWrites = 0;
    private volatile String services = "";
    private Thread writer;

    BleTransport(Context ctx, BluetoothDevice dev, LinkListener listener) {
        this.ctx = ctx;
        this.dev = dev;
        this.listener = listener;
        String n = dev.getName();
        this.name = n != null ? n : dev.getAddress();
    }

    /** Bloque jusqu'à ce que le port série soit prêt (notifications activées) ou que le délai soit écoulé. */
    void connect(long timeoutMs) throws IOException {
        gatt = dev.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE);
        if (gatt == null) throw new IOException("Le système refuse d'ouvrir la liaison BLE");
        try {
            if (!ready.await(timeoutMs, TimeUnit.MILLISECONDS) && failure == null) {
                failure = "Délai dépassé : le récepteur ne répond pas en BLE (éteint, hors de portée, ou déjà connecté à un autre appareil)";
            }
        } catch (InterruptedException e) {
            failure = "Connexion interrompue";
        }
        if (!isReady) {
            String f = failure != null ? failure : "Connexion BLE impossible";
            close();
            throw new IOException(f);
        }
    }

    private void fail(String message) {
        if (failure == null) failure = message;
        ready.countDown();
    }

    private static String statusText(int status) {
        switch (status) {
            case 133: return "échec GATT générique (code 133) : récepteur éteint, hors de portée ou déjà connecté à un autre appareil";
            case 8: return "délai de supervision dépassé (code 8) : récepteur hors de portée";
            case 19: return "le récepteur a mis fin à la liaison (code 19)";
            case 22: return "liaison coupée par l'appareil local (code 22)";
            case 62: return "établissement de la liaison échoué (code 62)";
            default: return "code " + status;
        }
    }

    private void startDiscovery(BluetoothGatt g) {
        if (discoveryStarted) return;
        discoveryStarted = true;
        if (!g.discoverServices()) fail("Impossible de lancer la découverte des services BLE");
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {

        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                try { g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH); } catch (RuntimeException ignored) { }
                if (!g.requestMtu(WANTED_MTU)) startDiscovery(g);
                // certains appareils ne rappellent jamais onMtuChanged : on lance la découverte quand même
                Thread t = new Thread(() -> {
                    try { Thread.sleep(1500); } catch (InterruptedException e) { return; }
                    if (!closed) startDiscovery(g);
                }, "ble-discovery-watchdog");
                t.setDaemon(true);
                t.start();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                if (!isReady) {
                    fail("Connexion BLE refusée : " + statusText(status));
                } else if (!closed) {
                    close();
                    listener.onLost(BleTransport.this, "Liaison BLE perdue avec " + name + " (" + statusText(status) + ")");
                }
            }
        }

        @Override public void onMtuChanged(BluetoothGatt g, int newMtu, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) mtu = newMtu;
            if (isReady) queue.setChunk(ChunkQueue.forMtu(mtu));     // MTU négocié après la mise en service
            startDiscovery(g);
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) { fail("Découverte des services BLE échouée (" + statusText(status) + ")"); return; }
            List<BleUartProfiles.Chr> all = new ArrayList<>();
            for (BluetoothGattService s : g.getServices()) {
                for (BluetoothGattCharacteristic c : s.getCharacteristics()) {
                    all.add(new BleUartProfiles.Chr(s.getUuid(), c.getUuid(), c.getProperties()));
                }
            }
            services = BleUartProfiles.describe(all);
            BleUartProfiles.Pick p = BleUartProfiles.pick(all);
            if (p == null) { fail("Aucun port série BLE reconnu. Services du récepteur : " + services); return; }
            BluetoothGattService svc = g.getService(p.service);
            BluetoothGattCharacteristic n = svc != null ? svc.getCharacteristic(p.notify) : null;
            BluetoothGattCharacteristic w = svc != null ? svc.getCharacteristic(p.write) : null;
            if (n == null || w == null) { fail("Caractéristiques du port série introuvables : " + services); return; }
            pick = p; rx = n; tx = w;
            if (!g.setCharacteristicNotification(n, true)) { fail("Impossible d'activer les notifications BLE"); return; }
            BluetoothGattDescriptor d = n.getDescriptor(CCCD);
            if (d == null) { markReady(); return; }      // module sans descripteur : les données arrivent quand même
            boolean indicate = (n.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) == 0;
            byte[] value = indicate ? BluetoothGattDescriptor.ENABLE_INDICATION_VALUE : BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
            boolean started;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                started = g.writeDescriptor(d, value) == BluetoothStatusCodes.SUCCESS;
            } else {
                d.setValue(value);
                started = g.writeDescriptor(d);
            }
            if (!started) fail("Impossible d'écrire le descripteur de notification BLE");
        }

        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            if (!CCCD.equals(d.getUuid()) || isReady) return;
            if (status == BluetoothGatt.GATT_SUCCESS) markReady();
            else fail("Activation des notifications BLE refusée (" + statusText(status) + ")");
        }

        // Android 13 et au-delà
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            deliver(value);
        }

        // Android 12 et en deçà (la valeur est lue dans la caractéristique)
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) return;   // déjà traité par la variante ci-dessus
            deliver(c.getValue());
        }

        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            writeDone.release();
        }
    };

    private void deliver(byte[] v) {
        if (v == null || v.length == 0) return;
        try {
            listener.onData(this, v, 0, v.length);
        } catch (RuntimeException e) {
            // une erreur de traitement des données ne doit jamais interrompre la pile Bluetooth
        }
    }

    private void markReady() {
        queue.setChunk(ChunkQueue.forMtu(mtu));
        isReady = true;
        writer = new Thread(this::writerLoop, "ble-write");
        writer.setDaemon(true);
        writer.start();
        ready.countDown();
    }

    /** Lance une écriture GATT ; true si Android l'a acceptée. Peut lever IllegalArgumentException / IllegalStateException. */
    @SuppressWarnings("deprecation")
    private boolean tryWrite(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] chunk, int type) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return g.writeCharacteristic(c, chunk, type) == BluetoothStatusCodes.SUCCESS;
        }
        c.setWriteType(type);
        c.setValue(chunk);
        return g.writeCharacteristic(c);
    }

    /**
     * Écrit les morceaux un à un : Android ne tolère qu'une écriture GATT à la fois. Aucune exception ne doit
     * s'échapper de ce fil (elle ferait planter l'application) : une taille refusée ramène les morceaux à 20 octets ;
     * toute autre erreur ferme la liaison, que la page reconnecte.
     */
    private void writerLoop() {
        while (!closed) {
            byte[] chunk;
            try { chunk = queue.take(500); } catch (InterruptedException e) { return; }
            if (chunk == null) continue;
            BluetoothGatt g = gatt;
            BluetoothGattCharacteristic c = tx;
            BleUartProfiles.Pick p = pick;
            if (g == null || c == null || p == null) continue;
            int type = p.writeNoResponse ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
            boolean started = false;
            try {
                for (int attempt = 0; attempt < 6 && !closed && !started; attempt++) {
                    writeDone.drainPermits();
                    started = tryWrite(g, c, chunk, type);
                    if (!started) { try { Thread.sleep(15); } catch (InterruptedException e) { return; } }
                }
            } catch (IllegalArgumentException e) {
                // longueur refusée par la pile (valeur d'attribut trop longue) : on repart sur le minimum garanti
                queue.setChunk(20);
                failedWrites++;
                continue;
            } catch (RuntimeException e) {
                if (!closed) {
                    close();
                    listener.onLost(this, "Écriture BLE impossible : " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName()));
                }
                return;
            }
            if (started) {
                writtenBytes += chunk.length;
                try { writeDone.tryAcquire(400, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { return; }
            } else {
                failedWrites++;
            }
        }
    }

    @Override public void write(byte[] data, int len) throws IOException {
        if (closed) throw new IOException("Liaison BLE fermée");
        queue.put(data, len);
    }

    @Override public void close() {
        if (closed) return;
        closed = true;
        queue.close();
        Thread w = writer;
        if (w != null) w.interrupt();
        BluetoothGatt g = gatt;
        gatt = null;
        if (g != null) {
            try { g.disconnect(); } catch (RuntimeException ignored) { }
            try { g.close(); } catch (RuntimeException ignored) { }
        }
        ready.countDown();
    }

    @Override public String kind() { return "ble"; }
    @Override public String name() { return name; }

    @Override public String info() {
        BleUartProfiles.Pick p = pick;
        if (p == null) return "Bluetooth LE";
        return "Bluetooth LE · " + p.profile + " · MTU " + mtu + " (morceaux de " + queue.chunk() + " o)" + (p.writeNoResponse ? " · écriture sans réponse" : " · écriture avec réponse")
            + " · émis " + writtenBytes + " o · file " + queue.queuedBytes() + " o · abandonnés " + (queue.droppedBytes() + failedWrites) + " o";
    }
}
