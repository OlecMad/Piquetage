package fr.lileauvert.piquetage;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * File d'écriture bornée pour les liaisons lentes (BLE). Découpe les données en morceaux
 * d'au plus {@code chunk} octets. Si la file dépasse {@code maxBytes}, les plus anciens
 * morceaux sont abandonnés : une correction RTCM périmée ne sert plus à rien, mieux vaut
 * envoyer la plus récente que de prendre du retard.
 */
final class ChunkQueue {

    private final ArrayDeque<byte[]> q = new ArrayDeque<>();
    private final int maxBytes;
    private int chunk;
    private int queued = 0;
    private long dropped = 0;
    private boolean closed = false;

    ChunkQueue(int chunk, int maxBytes) {
        this.chunk = Math.max(1, chunk);
        this.maxBytes = maxBytes;
    }

    synchronized void setChunk(int chunk) { this.chunk = Math.max(1, chunk); }
    synchronized int chunk() { return chunk; }

    /**
     * Taille de morceau pour un MTU négocié : MTU − 3 octets d'en-tête ATT, plafonnée à 512 (longueur maximale
     * d'une valeur d'attribut GATT : Android lève IllegalArgumentException au-delà). Un récepteur peut accepter
     * un MTU de 517 : 517 − 3 = 514 dépasserait. Au moins 20, le minimum du BLE (MTU 23).
     */
    static int forMtu(int mtu) { return Math.max(20, Math.min(512, mtu - 3)); }

    synchronized void put(byte[] data, int len) {
        if (closed) return;
        for (int off = 0; off < len; off += chunk) {
            int n = Math.min(chunk, len - off);
            q.addLast(Arrays.copyOfRange(data, off, off + n));
            queued += n;
        }
        while (queued > maxBytes && q.size() > 1) {
            byte[] old = q.pollFirst();
            queued -= old.length;
            dropped += old.length;
        }
        notifyAll();
    }

    /** Prochain morceau, ou null si la file est fermée ou si le délai est écoulé. */
    synchronized byte[] take(long timeoutMs) throws InterruptedException {
        long end = System.currentTimeMillis() + timeoutMs;
        while (q.isEmpty() && !closed) {
            long left = end - System.currentTimeMillis();
            if (left <= 0) return null;
            wait(left);
        }
        byte[] b = q.pollFirst();
        if (b != null) queued -= b.length;
        return b;
    }

    synchronized void close() { closed = true; q.clear(); queued = 0; notifyAll(); }
    synchronized int queuedBytes() { return queued; }
    synchronized long droppedBytes() { return dropped; }
}
