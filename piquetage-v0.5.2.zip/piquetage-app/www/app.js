/* ==================================================================
   Piquetage — écran principal (disposition C)

   Bandeau (projet, lieu, date, heure) · pastille de qualité · un instrument
   en gros chiffres (altitude NGF, points levés, cap de marche) · tracé en
   direct sur le plan Lambert-93 · profil altimétrique qui se dessine au fil
   de la marche · barre d'actions.

   S'appuie sur : window.PIQUETAGE.rtk (rtk-core.js, créé par diag.js),
   session.js (données), views.js (dessin). Aucun innerHTML.
   ================================================================== */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var rtk = window.PIQUETAGE.rtk;
  var GEO = window.GEO, Sess = window.PiqSession, V = window.PiqViews, X = window.PiqExport;

  var storage = null;
  try { storage = window.localStorage; } catch (e) { /* stockage indisponible */ }

  /* ---------------- Session ---------------- */

  var session = Sess.create(storage ? Sess.parse(storage.getItem(Sess.KEY)) : null);
  var saveTimer = null, saveWarned = false;

  function save() {
    if (!storage) return;
    try { storage.setItem(Sess.KEY, session.serialize()); saveWarned = false; }
    catch (e) { if (!saveWarned) { saveWarned = true; say('Sauvegarde impossible (stockage plein) — effacer des tracés'); } }
  }
  function scheduleSave() { if (saveTimer) return; saveTimer = setTimeout(function () { saveTimer = null; save(); }, 1000); }

  /* ---------------- Plan importé et cadrage ---------------- */

  var PP = window.PiqPlan;
  var plan = null;
  try { var pt = storage && storage.getItem(PP.KEY); plan = pt ? PP.parse(pt) : null; } catch (e) { plan = null; }
  var viewState = { showPlan: true, mode: 'all' };
  try { var vs = storage && JSON.parse(storage.getItem('piquetage.view') || 'null'); if (vs) { viewState.showPlan = vs.showPlan !== false; viewState.mode = vs.mode === 'here' ? 'here' : 'all'; } } catch (e) { /* réglages d'affichage par défaut */ }
  function saveView() { try { if (storage) storage.setItem('piquetage.view', JSON.stringify(viewState)); } catch (e) {} }

  /* ---------------- Messages ---------------- */

  var msgTimer = null;
  function say(text) {
    var el = $('m-msg');
    el.textContent = text; el.hidden = false;
    clearTimeout(msgTimer);
    msgTimer = setTimeout(function () { el.hidden = true; }, 4500);
  }
  rtk.on('message', say);

  /* ---------------- Formats ---------------- */

  function num(v, d) {
    return v.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d }).replace(/[\u202f\u00a0]/g, ' ');
  }

  /* ---------------- Position en direct ---------------- */

  var recent = [];            // positions récentes éligibles, pour le cap de marche
  var RECENT_MS = 20000, HEADING_MIN_M = 3;

  function eligible(ep) { return !rtk.settings.requireFix || ep.gga.quality === 4; }

  rtk.on('epoch', function (ep) {
    var S = rtk.settings;
    var sp = GEO.surveyPoint([{ gga: ep.gga, gst: null }], { poleHeight: S.pole, apcOffset: S.apc });
    if (!sp || !eligible(ep)) return;
    sp.t = new Date(ep.at).toISOString();
    recent.push({ x: sp.x93, y: sp.y93, at: ep.at });
    while (recent.length && ep.at - recent[0].at > RECENT_MS) recent.shift();
    if (session.isTracking() && session.addEpoch(sp) === 'added') scheduleSave();
  });

  /* ---------------- Onglets ---------------- */

  var tab = 'alt';
  Array.prototype.forEach.call(document.querySelectorAll('#tabs button'), function (b) {
    b.addEventListener('click', function () {
      tab = b.getAttribute('data-tab');
      Array.prototype.forEach.call(document.querySelectorAll('#tabs button'), function (x) {
        x.setAttribute('aria-selected', x === b ? 'true' : 'false');
      });
      paint();
    });
  });

  /* ---------------- Affichage ---------------- */

  function paintBanner() {
    var D = session.data, now = new Date();
    var pj = $('m-project'), pl = $('m-place');
    pj.textContent = D.project || 'Projet sans nom'; pj.className = D.project ? '' : 'ph muted';
    pl.textContent = D.place || 'Lieu à renseigner'; pl.className = D.place ? '' : 'ph';
    $('m-time').textContent = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    $('m-date').textContent = now.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
  }

  function paintInstrument(st) {
    var label = $('big-label'), value = $('big-value'), sub = $('big-sub');
    var p = st.point;
    if (tab === 'alt') {
      var ground = p && p.hNgfGround !== null;
      var h = p ? (ground ? p.hNgfGround : p.hNgfAntenna) : null;
      var warn = false;
      if (!p) label.textContent = 'Altitude NGF-IGN69';
      else if (ground && p.apcMissing) { label.textContent = 'Altitude NGF-IGN69 · sol, centre de phase non corrigé'; warn = true; }
      else if (ground) label.textContent = 'Altitude NGF-IGN69 · sol';
      else { label.textContent = 'Altitude NGF-IGN69 · ANTENNE (hauteur de canne non saisie)'; warn = true; }
      value.textContent = h !== null && h !== undefined ? num(h, 2) + ' m' : '—';
      if (!p) sub.textContent = '';
      else if (h === null) sub.textContent = 'Séparation géoïdale absente de la GGA ou position hors grille RAF20';
      else if (!ground) sub.textContent = 'Altitude de l’antenne, donc trop haute de la hauteur de canne : la saisir dans Canne › Réglages';
      else if (p.apcMissing) sub.textContent = 'h − N (RAF20) − hauteur de canne. Décalage du centre de phase non saisi : à renseigner dans Canne (0 pour l’ignorer)';
      else sub.textContent = 'h − N (RAF20) − hauteur de canne − centre de phase';
      label.className = warn ? 'warn' : '';
      sub.className = warn ? 'warn' : '';
    } else if (tab === 'pts') {
      var pts = session.data.points, lastP = pts[pts.length - 1];
      label.className = ''; sub.className = '';
      label.textContent = 'Points levés';
      value.textContent = String(pts.length);
      sub.textContent = lastP ? 'P' + lastP.n + ' · X ' + num(lastP.x, 2) + ' · Y ' + num(lastP.y, 2) : 'Aucun point levé';
    } else {
      var now = Date.now();
      var hd = st.fresh ? Sess.heading(recent.filter(function (r) { return now - r.at <= RECENT_MS; }), HEADING_MIN_M) : null;
      label.className = ''; sub.className = '';
      label.textContent = 'Cap de marche · nord du plan Lambert-93';
      value.textContent = hd === null ? '—' : String(Math.round(hd) % 360).padStart(3, '0') + '° ' + Sess.cardinal(hd);
      sub.textContent = hd === null ? 'À l’arrêt, ou moins de ' + HEADING_MIN_M + ' m parcourus'
        : 'Calculé sur la marche récente (≥ ' + HEADING_MIN_M + ' m) · pas le nord géographique';
    }
  }

  function paintInfo() {
    var s = session.stats();
    var tr = s.tracking ? 'Tracé en cours' : (s.vertices ? 'Dernier tracé' : 'Tracé');
    $('tr-info').textContent = tr + (s.vertices ? ' · ' + num(s.length, s.length < 100 ? 1 : 0) + ' m · ' + s.vertices + ' sommet' + (s.vertices > 1 ? 's' : '') : '') +
      (s.points ? ' · ' + s.points + ' pt' + (s.points > 1 ? 's' : '') : '');
    var pr = session.profile();
    $('pr-info').textContent = s.vertices > 1 && pr.some(function (q) { return q.h !== null; })
      ? 'Profil · D+ ' + num(s.up, 1) + ' m · D− ' + num(s.down, 1) + ' m' : 'Profil';
  }

  function liveOf(st) {
    return st.point && st.fresh ? { x: st.point.x93, y: st.point.y93, fix: st.code === 'FIX' } : null;
  }

  var raf = 0;
  function redraw() {
    if (raf) return;
    raf = requestAnimationFrame(function () {
      raf = 0;
      var st = rtk.status();
      V.drawTrack($('cv-track'), session, liveOf(st), { plan: plan, showPlan: viewState.showPlan, mode: viewState.mode });
      V.drawProfile($('cv-prof'), session);
    });
  }

  function paint() {
    var st = rtk.status();
    var pill = $('m-pill');
    pill.className = 'q-' + st.code;
    pill.textContent = st.label;

    var acc = [];
    if (st.fresh) {
      acc.push(st.gstAvailable ? '±' + rtk.cm(st.sdH) + ' H · ±' + rtk.cm(st.sdV) + ' V' : 'σ n.d.');
      if (st.sats !== null) acc.push(st.sats + ' sat.');
    }
    $('m-acc').textContent = acc.join(' · ');

    paintInstrument(st);
    $('m-xy').textContent = st.point ? 'X ' + num(st.point.x93, 2) + '   Y ' + num(st.point.y93, 2) : 'X —   Y —';

    var tracking = session.isTracking();
    var bt = $('b-track');
    bt.setAttribute('aria-pressed', tracking ? 'true' : 'false');
    bt.textContent = tracking ? 'Arrêter' : 'Tracé';
    $('b-point').disabled = !st.connected || capturing;

    paintBanner();
    paintInfo();
    redraw();
  }
  rtk.on('change', paint);

  /* ---------------- Actions ---------------- */

  var capturing = false;
  $('b-point').addEventListener('click', function () {
    if (capturing) return;
    capturing = true; paint();
    rtk.capture().then(function (p) {
      var pt = session.addPoint(p);
      if (pt) { save(); say('P' + pt.n + ' enregistré · ' + p.qualityLabel + (p.acc !== null ? ' · ±' + rtk.cm(p.acc) : '')); }
    }).catch(function (e) {
      say(e.message);
    }).then(function () { capturing = false; paint(); });
  });

  $('b-track').addEventListener('click', function () {
    if (session.isTracking()) { session.stopTrack(); save(); say('Tracé arrêté'); }
    else {
      session.startTrack(); save();
      var st = rtk.status();
      say(st.fresh ? 'Tracé démarré' : 'Tracé démarré — en attente de position');
    }
    paint();
  });

  function paintFit() { $('b-fit').textContent = viewState.mode === 'here' ? 'Vue : ici (60 m)' : 'Vue : tout'; }
  $('b-fit').addEventListener('click', function () { viewState.mode = viewState.mode === 'here' ? 'all' : 'here'; saveView(); paintFit(); redraw(); });

  /* ---------------- Panneaux ---------------- */

  var stack = [];
  function openSheet(id) {
    if (stack.indexOf(id) >= 0) return;
    $(id).hidden = false; stack.push(id);
    try { history.pushState({ sheet: id }, ''); } catch (e) { /* historique indisponible */ }
    $(id).scrollTop = 0;
  }
  function hideSheet() {
    var id = stack.pop();
    if (!id) return;
    $(id).hidden = true;
    paint();
  }
  function closeSheet() {
    if (!stack.length) return;
    if (history.state && history.state.sheet) history.back(); else hideSheet();
  }
  window.addEventListener('popstate', hideSheet);

  $('b-link').addEventListener('click', function () { openSheet('sheet-link'); });
  $('close-link').addEventListener('click', closeSheet);
  $('close-proj').addEventListener('click', closeSheet);

  function openProject() {
    var D = session.data;
    $('p-name').value = D.project; $('p-place').value = D.place;
    $('p-interval').value = String(D.interval); $('p-display').value = D.display; $('p-decimal').value = D.decimal; $('p-origin').value = D.origin;
    $('p-export-out').textContent = '';
    paintProjectStats();
    openSheet('sheet-proj');
  }
  $('b-proj').addEventListener('click', openProject);
  $('banner').addEventListener('click', openProject);
  $('banner').addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openProject(); } });

  function paintProjectStats() {
    var s = session.stats();
    $('p-stats').textContent = s.vertices || s.points
      ? s.points + ' point' + (s.points > 1 ? 's' : '') + ' levé' + (s.points > 1 ? 's' : '') + ' · ' + s.tracks + ' tracé' + (s.tracks > 1 ? 's' : '') +
        (s.vertices ? ' · dernier tracé ' + num(s.length, 1) + ' m sur le plan Lambert-93 (distance de grille, pas de terrain)' : '')
      : 'Aucune donnée dans cette session.';
  }

  $('p-name').addEventListener('input', function () { session.setMeta({ project: $('p-name').value }); save(); paintBanner(); });
  $('p-place').addEventListener('input', function () { session.setMeta({ place: $('p-place').value }); save(); paintBanner(); });
  $('p-interval').addEventListener('change', function () { session.setMeta({ interval: $('p-interval').value }); save(); });
  $('p-origin').addEventListener('change', function () { session.setMeta({ origin: $('p-origin').value }); save(); });
  $('p-decimal').addEventListener('change', function () { session.setMeta({ decimal: $('p-decimal').value }); save(); });
  $('p-display').addEventListener('change', function () { session.setMeta({ display: $('p-display').value }); save(); redraw(); });

  /* ---------------- Export CSV + DXF ---------------- */

  var CAP = window.Capacitor || null;
  function plug(name) {
    if (!CAP || !CAP.Plugins) return null;
    if (typeof CAP.isPluginAvailable === 'function' && !CAP.isPluginAvailable(name)) return null;
    return CAP.Plugins[name] || null;
  }

  function showExport(text) { $('p-export-out').textContent = text; }

  function browserDownload(files) {
    files.forEach(function (f, i) {
      setTimeout(function () {
        var blob = new Blob([f.content], { type: f.mime + ';charset=utf-8' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = f.name;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      }, i * 400);
    });
  }

  function exportSession() {
    var btn = $('p-export');
    var res = X.build(session.data, { decimal: session.data.decimal, origin: session.data.origin, now: new Date() });
    if (res.error) { showExport(res.error); say(res.error); return; }
    var names = res.files.map(function (f) { return f.name; });
    var warn = res.warnings.length ? '\nÀ vérifier :\n· ' + res.warnings.join('\n· ') : '';
    var F = plug('Filesystem'), S = plug('Share');

    if (!F) {                                    // navigateur : téléchargement direct
      browserDownload(res.files);
      showExport(res.files.length + ' fichiers téléchargés :\n' + names.join('\n') + warn);
      say('Export : ' + res.files.length + ' fichiers');
      return;
    }

    btn.disabled = true;
    var uris = [];
    // Un nom horodaté à la minute : jamais d'écrasement d'un fichier d'une session précédente (Android 11+).
    res.files.reduce(function (chain, f) {
      return chain.then(function () {
        return F.writeFile({ path: 'Piquetage/' + f.name, data: f.content, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true });
      }).then(function () {
        return F.getUri({ path: 'Piquetage/' + f.name, directory: 'DOCUMENTS' });
      }).then(function (r) { if (r && r.uri) uris.push(r.uri); });
    }, Promise.resolve()).then(function () {
      showExport(res.files.length + ' fichiers enregistrés dans Documents › Piquetage :\n' + names.join('\n') + warn);
      say('Export enregistré dans Documents › Piquetage');
      if (S && uris.length) {
        return S.share({ title: 'Piquetage — ' + (session.data.project || 'export'), files: uris, dialogTitle: 'Partager l’export' })
          .catch(function () { /* partage annulé : les fichiers sont écrits */ });
      }
    }).catch(function (e) {
      var m = 'Export impossible : ' + ((e && e.message) || 'erreur');
      showExport(m); say(m);
    }).then(function () { btn.disabled = false; });
  }
  $('p-export').addEventListener('click', exportSession);

  // Effacement en deux temps : un premier appui arme le bouton, le second confirme.
  function armed(btn, label, armedLabel, action) {
    var timer = null;
    btn.addEventListener('click', function () {
      if (btn.getAttribute('data-armed') === '1') {
        clearTimeout(timer); btn.removeAttribute('data-armed'); btn.className = ''; btn.textContent = label;
        action();
      } else {
        btn.setAttribute('data-armed', '1'); btn.className = 'danger'; btn.textContent = armedLabel;
        timer = setTimeout(function () { btn.removeAttribute('data-armed'); btn.className = ''; btn.textContent = label; }, 4000);
      }
    });
  }
  armed($('p-undo'), 'Annuler le dernier point', 'Confirmer : retirer le dernier point', function () {
    var p = session.removeLastPoint();
    save(); paintProjectStats(); paint();
    say(p ? 'P' + p.n + ' retiré' : 'Aucun point à retirer');
  });
  armed($('p-clear'), 'Effacer les tracés', 'Confirmer : effacer les tracés', function () {
    session.clearTracks(); save(); paintProjectStats(); paint(); say('Tracés effacés');
  });
  armed($('p-new'), 'Nouveau projet (efface tracés et points)', 'Confirmer : tout effacer', function () {
    session.reset({}); recent = []; save(); openProject(); paint(); say('Nouveau projet');
  });

  /* ---------------- Démarrage ---------------- */

  if (typeof ResizeObserver === 'function') {
    var ro = new ResizeObserver(redraw);
    ro.observe($('cv-track')); ro.observe($('cv-prof'));
  }
  window.addEventListener('resize', redraw);
  setInterval(paintBanner, 10000);
  document.addEventListener('visibilitychange', function () { if (document.hidden) save(); });
  window.addEventListener('pagehide', save);

  paintFit();
  paint();
  window.PIQUETAGE.session = session;      // inspection et tests
  window.PIQUETAGE.paint = paint;
  window.PIQUETAGE.api = {
    say: say, openSheet: openSheet, closeSheet: closeSheet, redraw: redraw, armed: armed, num: num,
    getPlan: function () { return plan; },
    getView: function () { return viewState; },
    setView: function (v) { viewState.showPlan = v.showPlan !== false; saveView(); redraw(); },
    setPlan: function (p) {
      plan = p;
      try {
        if (!storage) return;
        if (!p) { storage.removeItem(PP.KEY); return; }
        var txt = PP.serialize(p);
        if (txt.length > 3.5e6) { say('Plan trop volumineux pour l’enregistrement local : il ne sera pas conservé au redémarrage'); storage.removeItem(PP.KEY); }
        else storage.setItem(PP.KEY, txt);
      } catch (e) { say('Plan non enregistré (stockage plein) : il ne sera pas conservé au redémarrage'); }
      redraw();
    },
    savePlan: function () { try { if (storage && plan) storage.setItem(PP.KEY, PP.serialize(plan)); } catch (e) {} }
  };
})();
