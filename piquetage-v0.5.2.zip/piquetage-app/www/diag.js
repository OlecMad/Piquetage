/* Piquetage — panneau « Canne » : liaison Bluetooth, corrections NTRIP, hauteurs.
   Crée l'instance RtkCore unique de la page (window.PIQUETAGE.rtk) que l'écran
   principal (app.js) réutilise. Aucun innerHTML : tout passe par textContent. */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var CAP = window.Capacitor || null;
  var P = null;
  if (CAP && CAP.Plugins && CAP.Plugins.GnssBridge &&
      (typeof CAP.isPluginAvailable !== 'function' || CAP.isPluginAvailable('GnssBridge'))) {
    P = CAP.Plugins.GnssBridge;
  }

  var storage = null;
  try { storage = window.localStorage; } catch (e) { /* stockage indisponible */ }

  var rtk = window.RtkCore.create({ geo: window.GEO, plugin: P, storage: storage });
  var S = rtk.settings;

  function fmt(v, d, unit) { return (v === null || v === undefined || !isFinite(v)) ? '—' : v.toFixed(d) + (unit || ''); }

  /* ---------------- Messages ---------------- */

  var logEl = $('log');
  function log(text) {
    var li = document.createElement('li');
    var t = new Date();
    li.textContent = t.toTimeString().slice(0, 8) + '  ' + text;
    logEl.insertBefore(li, logEl.firstChild);
    while (logEl.children.length > 40) logEl.removeChild(logEl.lastChild);
  }
  rtk.on('message', log);

  /* ---------------- Affichage ---------------- */

  var NT = { stopped: 'Arrêté', connecting: 'Connexion…', connected: null, reconnecting: 'Nouvel essai', error: 'Erreur' };

  function paint(st) {
    var fix = $('fix');
    fix.className = 'fix q-' + st.code;
    fix.textContent = st.label;

    $('sats').textContent = st.fresh ? fmt(st.sats, 0) : '—';
    $('hdop').textContent = st.fresh ? fmt(st.hdop, 2) : '—';
    $('age').textContent = st.fresh && st.diffAge !== null ? fmt(st.diffAge, 1, ' s') : '—';
    $('sdh').textContent = st.gstAvailable ? (rtk.cm(st.sdH) || 'n.d.') : (st.fresh ? 'n.d.' : '—');
    $('sdv').textContent = st.gstAvailable ? (rtk.cm(st.sdV) || 'n.d.') : (st.fresh ? 'n.d.' : '—');

    var n = st.ntrip, nts;
    if (!n.enabled) nts = 'Désactivé';
    else if (n.state === 'connected') nts = 'Reçu ' + (n.bytes / 1024).toFixed(0) + ' Ko';
    else nts = NT[n.state] || n.state;
    $('ntrip').textContent = nts;
    $('ntrip').title = n.message || '';

    var c = $('coords');
    c.textContent = '';
    var p = st.point;
    function line(text, muted) {
      var s = document.createElement('span');
      s.textContent = text;
      if (muted) s.className = 'muted';
      c.appendChild(s);
      c.appendChild(document.createElement('br'));
    }
    if (p) {
      line('X ' + fmt(p.x93, 2) + ' m   Y ' + fmt(p.y93, 2) + ' m');
      line(p.hNgfGround !== null ? 'H sol ' + fmt(p.hNgfGround, 3, ' m') + (p.apcMissing ? ' (centre de phase non corrigé)' : '') : 'H ANTENNE ' + fmt(p.hNgfAntenna, 3, ' m') + ' (hauteur de canne non saisie)');
      if (p.hEll === null) line('séparation géoïdale absente de la GGA', true);
      else line('h ellipsoïdale ' + fmt(p.hEll, 3, ' m') + ' · N (RAF20) ' + fmt(p.geoidN, 3, ' m'), true);
    } else {
      line('X —   Y —'); line('H —');
    }

    var hn = $('hnote');
    if (st.heights.poleOnly) {
      hn.className = 'warn';
      hn.textContent = 'Altitude au sol = h ellipsoïdale − N (RAF20) − ' + (+S.pole).toFixed(3) + ' m (canne). Le décalage du centre de phase n’est pas saisi : il n’est pas soustrait. ' +
        'À relever dans le fichier de calibration NGS ANTCAL de l’antenne ; saisir 0 pour confirmer qu’on l’ignore.';
    } else if (st.heights.complete) {
      hn.className = 'note';
      hn.textContent = 'H sol = h ellipsoïdale − N (RAF20) − ' + (+S.pole).toFixed(3) + ' m (canne) − ' + (+S.apc).toFixed(4) + ' m (centre de phase).';
    } else {
      hn.className = 'warn';
      hn.textContent = 'Hauteur de canne non saisie : l’altitude affichée est celle de l’ANTENNE, trop haute de la hauteur de canne. ' +
        'La saisir ci-dessous (distance du sol au point de référence de l’antenne, ARP). Le décalage du centre de phase se relève dans le fichier de calibration NGS ANTCAL.';
    }

    var busy = st.connected || st.wantConnected;
    $('connect').textContent = busy ? 'Déconnecter' : 'Connecter';
    $('noplugin').hidden = st.available;
    ['refresh', 'dev', 'connect', 'baud', 'tr-ble', 'tr-usb', 'tr-classic'].forEach(function (id) { $(id).disabled = !st.available; });
    // pas de changement de mode ni de récepteur pendant une liaison
    ['dev', 'baud', 'tr-ble', 'tr-usb', 'tr-classic'].forEach(function (id) { if (busy) $(id).disabled = true; });
    $('refresh').disabled = !st.available || busy || st.scanning;

    ['ble', 'usb', 'classic'].forEach(function (t) { $('tr-' + t).setAttribute('aria-selected', t === st.transport ? 'true' : 'false'); });
    var hints = {
      ble: 'Allumer le récepteur puis « Rechercher » (6 s). Aucun appairage dans les paramètres d’Android n’est nécessaire.',
      usb: 'Brancher le câble USB-OTG au récepteur (alimenté), puis « Actualiser ». Android demande l’autorisation à la première connexion.',
      classic: 'Mode d’origine de Diagnostic Fluvial, conservé en secours : appairer d’abord le récepteur dans les paramètres Bluetooth d’Android, puis « Actualiser ».'
    };
    $('tr-hint').textContent = hints[st.transport];
    $('dev-label').textContent = st.transport === 'usb' ? 'Appareil USB' : (st.transport === 'ble' ? 'Récepteur Bluetooth LE' : 'Récepteur appairé (Bluetooth Classic)');
    $('baud-wrap').hidden = st.transport !== 'usb';
    var rb = $('refresh');
    if (st.transport === 'ble') { rb.textContent = st.scanning ? 'Recherche…' : 'Rechercher'; rb.setAttribute('aria-label', 'Rechercher les appareils BLE'); rb.style.minWidth = '110px'; }
    else { rb.textContent = '↻'; rb.setAttribute('aria-label', 'Actualiser la liste'); rb.style.minWidth = '52px'; }
    $('link-info').textContent = busy && st.linkInfo ? st.linkInfo : '';
    fillDevices();
  }
  rtk.on('change', paint);

  /* ---------------- Liste des appareils ---------------- */

  var lastSig = '';

  function option(v, text, disabled) {
    var o = document.createElement('option');
    o.value = v; o.textContent = text; if (disabled) o.disabled = true;
    return o;
  }

  /** Reconstruit la liste seulement si elle a changé : rebâtir un menu ouvert le refermerait. */
  function fillDevices() {
    var t = S.transport, cur = rtk.current();
    var live = rtk.live;
    var list = t === 'ble' ? live.bleDevices : (t === 'usb' ? live.usbDevices : live.devices);
    var chosen = t === 'usb' ? cur.id : cur.address;
    var sig = t + '|' + chosen + '|' + JSON.stringify(list);
    if (sig === lastSig) return;
    lastSig = sig;
    var sel = $('dev');
    sel.textContent = '';
    sel.appendChild(option('', t === 'ble' && !list.length ? '— lancer la recherche —' : '— choisir —'));
    var known = false;
    list.forEach(function (d) {
      var v = t === 'usb' ? d.id : d.address;
      if (v === chosen) known = true;
      var label;
      if (t === 'usb') label = d.name.replace(/[<>&"]/g, '') + ' (' + d.id + ') · ' + (d.supported ? d.chip : 'non reconnu') + (d.supported && !d.hasPermission ? ' · autorisation à demander' : '');
      else if (t === 'ble') label = d.name.replace(/[<>&"]/g, '') + ' — ' + d.address + (d.rssi !== null ? ' · ' + d.rssi + ' dBm' : '') + (d.rtk ? ' · récepteur ?' : '');
      else label = d.name.replace(/[<>&"]/g, '') + ' — ' + d.address + (d.ble ? ' (BLE : utiliser le mode Bluetooth LE)' : '');
      sel.appendChild(option(v, label, t === 'usb' ? !d.supported : (t === 'classic' && d.ble)));
    });
    // récepteur mémorisé mais pas (encore) dans la liste : on peut s'y connecter sans nouvelle recherche
    if (chosen && !known) sel.appendChild(option(chosen, (cur.name || chosen).replace(/[<>&"]/g, '') + ' (mémorisé)'));
    sel.value = chosen || '';
  }

  $('refresh').addEventListener('click', function () { rtk.refresh(); });
  $('dev').addEventListener('change', function () { rtk.select($('dev').value); });
  $('baud').addEventListener('change', function () { rtk.set('baud', $('baud').value); });
  ['ble', 'usb', 'classic'].forEach(function (t) {
    $('tr-' + t).addEventListener('click', function () {
      rtk.set('transport', t);
      if (t !== 'ble' && P) rtk.refresh();     // la recherche BLE est lancée à la demande : elle consomme l'énergie du récepteur et du téléphone
    });
  });
  $('connect').addEventListener('click', function () {
    var st = rtk.status();
    if (st.connected || st.wantConnected) rtk.disconnect();
    else rtk.connect().catch(function (e) { log(e.message); });
  });

  /* ---------------- Réglages ---------------- */

  function bind(id, key, read) {
    var el = $(id);
    var fn = function () { rtk.set(key, read(el)); };
    el.addEventListener('input', fn);
    el.addEventListener('change', fn);
  }
  var val = function (el) { return el.value; };
  var chk = function (el) { return el.checked; };

  window.RtkCore.BAUDS.forEach(function (b) { $('baud').appendChild(option(String(b), String(b))); });
  $('baud').value = String(S.baud);
  $('pole').value = S.pole;
  $('apc').value = S.apc;
  $('avg').value = String(S.avg);
  $('fixonly').checked = !!S.requireFix;
  $('nt-enabled').checked = !!S.ntrip.enabled;
  ['host', 'port', 'mount', 'gga', 'user', 'pass'].forEach(function (k) { $('nt-' + k).value = S.ntrip[k]; });

  bind('pole', 'pole', val); bind('apc', 'apc', val); bind('avg', 'avg', val);
  bind('fixonly', 'requireFix', chk); bind('nt-enabled', 'ntrip.enabled', chk);
  ['host', 'port', 'mount', 'gga', 'user', 'pass'].forEach(function (k) { bind('nt-' + k, 'ntrip.' + k, val); });

  /* ---------------- Démarrage ---------------- */

  paint(rtk.status());
  if (P && S.transport !== 'ble') rtk.refresh();
  window.PIQUETAGE = { rtk: rtk };   // inspection et tests
})();
